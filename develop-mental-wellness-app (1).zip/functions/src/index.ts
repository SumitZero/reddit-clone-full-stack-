import * as crypto from 'node:crypto';
import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { defineSecret } from 'firebase-functions/params';
import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import Razorpay from 'razorpay';

initializeApp();

const db = getFirestore();
const auth = getAuth();

const PAYPAL_CLIENT_ID = defineSecret('PAYPAL_CLIENT_ID');
const PAYPAL_CLIENT_SECRET = defineSecret('PAYPAL_CLIENT_SECRET');
const PAYPAL_PLAN_MONTHLY = defineSecret('PAYPAL_PLAN_MONTHLY');
const PAYPAL_PLAN_YEARLY = defineSecret('PAYPAL_PLAN_YEARLY');
const PAYPAL_PLAN_LIFETIME = defineSecret('PAYPAL_PLAN_LIFETIME');
const PAYPAL_BASE_URL = defineSecret('PAYPAL_BASE_URL');
const RAZORPAY_KEY_ID = defineSecret('RAZORPAY_KEY_ID');
const RAZORPAY_KEY_SECRET = defineSecret('RAZORPAY_KEY_SECRET');

const getPayPalAccessToken = async () => {
  const creds = Buffer.from(`${PAYPAL_CLIENT_ID.value()}:${PAYPAL_CLIENT_SECRET.value()}`).toString('base64');
  const res = await fetch(`${PAYPAL_BASE_URL.value()}/v1/oauth2/token`, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${creds}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });

  if (!res.ok) throw new HttpsError('internal', 'Unable to create PayPal access token');
  return res.json() as Promise<{ access_token: string }>;
};

const getPlanId = (plan: 'monthly' | 'yearly' | 'lifetime') => {
  if (plan === 'monthly') return PAYPAL_PLAN_MONTHLY.value();
  if (plan === 'yearly') return PAYPAL_PLAN_YEARLY.value();
  return PAYPAL_PLAN_LIFETIME.value();
};

const verifyUid = async (uid: string) => {
  if (!uid) throw new HttpsError('unauthenticated', 'Sign-in required');
  await auth.getUser(uid).catch(() => {
    throw new HttpsError('unauthenticated', 'Invalid user');
  });
};

export const createCheckoutIntent = onCall({
  secrets: [
    PAYPAL_CLIENT_ID,
    PAYPAL_CLIENT_SECRET,
    PAYPAL_PLAN_MONTHLY,
    PAYPAL_PLAN_YEARLY,
    PAYPAL_PLAN_LIFETIME,
    PAYPAL_BASE_URL,
    RAZORPAY_KEY_ID,
    RAZORPAY_KEY_SECRET,
  ],
}, async (request) => {
  const { uid, provider, plan, region, priceLabel } = request.data as {
    uid: string;
    provider: 'paypal' | 'razorpay';
    plan: 'monthly' | 'yearly' | 'lifetime';
    region: string;
    priceLabel: string;
  };

  await verifyUid(uid);
  const reference = `txn_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  await db.collection('users').doc(uid).collection('transactions').add({
    provider,
    plan,
    region,
    amountLabel: priceLabel,
    currency: 'mixed',
    status: 'pending',
    transactionReference: reference,
    createdAt: Date.now(),
    cancellationScheduled: false,
  });

  if (provider === 'paypal') {
    const { access_token } = await getPayPalAccessToken();
    return {
      provider,
      plan,
      reference,
      paypalClientId: PAYPAL_CLIENT_ID.value(),
      planId: getPlanId(plan),
      accessTokenPreview: !!access_token,
    };
  }

  return {
    provider,
    plan,
    reference,
    razorpayKeyId: RAZORPAY_KEY_ID.value(),
  };
});

export const verifyCheckout = onCall({
  secrets: [PAYPAL_CLIENT_ID, PAYPAL_CLIENT_SECRET, PAYPAL_BASE_URL, RAZORPAY_KEY_SECRET],
}, async (request) => {
  const { uid, provider, reference, paypalSubscriptionId, razorpayPaymentId, razorpaySignature, razorpaySubscriptionId } = request.data as {
    uid: string;
    provider: 'paypal' | 'razorpay';
    reference: string;
    paypalSubscriptionId?: string;
    razorpayPaymentId?: string;
    razorpaySignature?: string;
    razorpaySubscriptionId?: string;
  };

  await verifyUid(uid);

  let verified = false;
  let plan: 'monthly' | 'yearly' | 'lifetime' = 'monthly';
  let expiryDate: number | null = Date.now() + 30 * 24 * 60 * 60 * 1000;

  const txSnap = await db.collection('users').doc(uid).collection('transactions').where('transactionReference', '==', reference).limit(1).get();
  const txDoc = txSnap.docs[0];
  if (!txDoc) throw new HttpsError('not-found', 'Transaction not found');
  const tx = txDoc.data();
  plan = tx.plan;
  expiryDate = plan === 'monthly'
    ? Date.now() + 30 * 24 * 60 * 60 * 1000
    : plan === 'yearly'
      ? Date.now() + 365 * 24 * 60 * 60 * 1000
      : null;

  if (provider === 'paypal') {
    if (!paypalSubscriptionId) throw new HttpsError('invalid-argument', 'Missing PayPal subscription id');
    const { access_token } = await getPayPalAccessToken();
    const res = await fetch(`${PAYPAL_BASE_URL.value()}/v1/billing/subscriptions/${paypalSubscriptionId}`, {
      headers: { Authorization: `Bearer ${access_token}` },
    });
    if (!res.ok) throw new HttpsError('internal', 'Unable to verify PayPal subscription');
    const data = await res.json() as { status?: string };
    verified = data.status === 'ACTIVE' || data.status === 'APPROVAL_PENDING';
  } else {
    if (!razorpayPaymentId || !razorpaySignature || !razorpaySubscriptionId) {
      throw new HttpsError('invalid-argument', 'Missing Razorpay verification fields');
    }
    const expected = crypto
      .createHmac('sha256', RAZORPAY_KEY_SECRET.value())
      .update(`${razorpayPaymentId}|${razorpaySubscriptionId}`)
      .digest('hex');
    verified = expected === razorpaySignature;
  }

  if (!verified) {
    await txDoc.ref.update({ status: 'failed' });
    throw new HttpsError('permission-denied', 'Payment verification failed');
  }

  const purchaseDate = Date.now();
  await db.collection('subscriptions').doc(uid).set({
    status: 'active',
    plan,
    provider,
    transactionReference: reference,
    purchaseDate,
    expiryDate,
    cancelAtPeriodEnd: false,
    updatedAt: FieldValue.serverTimestamp(),
  }, { merge: true });

  await txDoc.ref.update({
    status: 'active',
    provider,
    purchaseDate,
    expiryDate,
  });

  return {
    verified: true,
    status: 'active',
    plan,
    region: tx.region || 'global',
    transactionReference: reference,
    expiryDate,
    purchaseDate,
    provider,
    cancelAtPeriodEnd: false,
  };
});

export const cancelSubscription = onCall(async (request) => {
  const { uid, cancelAtPeriodEnd } = request.data as { uid: string; cancelAtPeriodEnd: boolean };
  await verifyUid(uid);

  const subRef = db.collection('subscriptions').doc(uid);
  const subSnap = await subRef.get();
  if (!subSnap.exists) throw new HttpsError('not-found', 'No active subscription');
  const data = subSnap.data()!;

  await subRef.set({
    cancelAtPeriodEnd,
    status: cancelAtPeriodEnd ? 'cancelled' : data.status,
    refundPolicy: 'Refunds are reviewed by support based on billing date, plan type, and payment provider policy. Approved refunds are returned to the original payment method.',
    updatedAt: FieldValue.serverTimestamp(),
  }, { merge: true });

  const txSnap = await db.collection('users').doc(uid).collection('transactions')
    .where('transactionReference', '==', data.transactionReference)
    .limit(1)
    .get();
  if (!txSnap.empty) {
    await txSnap.docs[0].ref.update({ cancellationScheduled: cancelAtPeriodEnd, status: 'cancelled' });
  }

  return {
    ok: true,
    cancelAtPeriodEnd,
    expiryDate: data.expiryDate || null,
    refundPolicy: 'Refunds are reviewed by support based on billing date, plan type, and payment provider policy. Approved refunds are returned to the original payment method.',
  };
});

export const requestRefund = onCall(async (request) => {
  const { uid, reference, reason } = request.data as { uid: string; reference: string; reason: string };
  await verifyUid(uid);

  if (!reference || !reason?.trim()) {
    throw new HttpsError('invalid-argument', 'Reference and refund reason are required');
  }

  const txSnap = await db.collection('users').doc(uid).collection('transactions')
    .where('transactionReference', '==', reference)
    .limit(1)
    .get();

  if (txSnap.empty) throw new HttpsError('not-found', 'Transaction not found');

  const txRef = txSnap.docs[0].ref;
  const txData = txSnap.docs[0].data();

  if (!['active', 'cancelled'].includes(txData.status)) {
    throw new HttpsError('failed-precondition', 'Only paid subscriptions can request refunds');
  }

  await txRef.update({
    refundStatus: 'requested',
    refundReason: reason.trim(),
    refundRequestedAt: Date.now(),
  });

  await db.collection('refundRequests').add({
    uid,
    reference,
    provider: txData.provider,
    plan: txData.plan,
    amountLabel: txData.amountLabel,
    reason: reason.trim(),
    status: 'requested',
    createdAt: Date.now(),
  });

  return {
    ok: true,
    refundStatus: 'requested',
    message: 'Refund request submitted. Our team will review eligibility based on provider rules and billing date, then return approved refunds to the original payment method.',
  };
});
