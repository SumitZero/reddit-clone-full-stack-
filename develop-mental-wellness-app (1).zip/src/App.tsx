import { useEffect, useMemo, useState } from 'react';
import { getRedirectResult, onAuthStateChanged } from 'firebase/auth';
import { useAppStore } from './store/appStore';
import { firebaseAuth } from './lib/firebase';
import { upsertUserProfile } from './lib/backend';
import { attachPendingReferralToCurrentUser, registerReferralClickFromUrl, setupReferralProfile } from './lib/referral';
import OnboardingScreen from './components/OnboardingScreen';
import BottomNav from './components/BottomNav';
import AuthModal from './components/AuthModal';
import TopActions from './components/TopActions';
import HomePage from './pages/HomePage';
import BreathePage from './pages/BreathePage';
import SoundsPage from './pages/SoundsPage';
import JournalPage from './pages/JournalPage';
import ProfilePage from './pages/ProfilePage';
import MoodCheckIn from './pages/MoodCheckIn';
import ProgressPage from './pages/ProgressPage';
import PremiumPage from './pages/PremiumPage';
import BreathingSession from './pages/BreathingSession';
import TransactionHistoryPage from './pages/TransactionHistoryPage';
import DownloadPage from './pages/DownloadPage';
import {
  AboutPage,
  CrisisPage,
  FavoritesPage,
  HelpPage,
  MoodHistoryPage,
  PrivacyPage,
  QuickSessionPage,
  RemindersPage,
  TermsPage,
} from './pages/SubPages';

function SplashScreen() {
  return (
    <div className="fixed inset-0 z-[120] overflow-hidden bg-[radial-gradient(circle_at_top,_rgba(52,211,153,0.22),_transparent_35%),radial-gradient(circle_at_bottom_right,_rgba(59,130,246,0.22),_transparent_35%),linear-gradient(180deg,#04111f_0%,#0b1728_45%,#101827_100%)]">
      <div className="absolute inset-0 opacity-30">
        <div className="absolute -left-12 top-24 h-40 w-40 rounded-full bg-emerald-400/20 blur-3xl" />
        <div className="absolute right-0 top-1/3 h-52 w-52 rounded-full bg-sky-400/20 blur-3xl" />
        <div className="absolute bottom-10 left-1/2 h-48 w-48 -translate-x-1/2 rounded-full bg-violet-400/15 blur-3xl" />
      </div>

      <div className="relative mx-auto flex min-h-screen max-w-lg flex-col items-center justify-center px-6 text-center">
        <div className="animate-float mb-8 rounded-[2rem] bg-white/10 p-6 shadow-2xl shadow-cyan-500/10 backdrop-blur-xl">
          <div className="flex h-24 w-24 items-center justify-center rounded-[1.5rem] bg-gradient-to-br from-cyan-300/80 via-sky-400/80 to-blue-500/80 shadow-lg shadow-cyan-500/20">
            <svg className="h-12 w-12 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20.42 4.58a5.4 5.4 0 0 0-7.64 0L12 5.36l-.78-.78a5.4 5.4 0 0 0-7.64 7.64l.78.78L12 20.64l7.64-7.64.78-.78a5.4 5.4 0 0 0 0-7.64Z" />
              <path d="M3.5 12h4l2-3 3 6 2-3h6" />
            </svg>
          </div>
        </div>

        <h1 className="text-5xl font-bold tracking-tight text-white">MindReset</h1>
        <p className="mt-4 text-lg text-slate-300">Find your calm in minutes</p>
        <p className="mt-2 max-w-xs text-sm leading-relaxed text-slate-400">
          Micro-resets for pressure, overthinking, work stress, study stress, and mental tiredness.
        </p>

        <div className="mt-10 flex items-center gap-2">
          <span className="h-2.5 w-2.5 animate-pulse rounded-full bg-emerald-400" />
          <span className="text-xs uppercase tracking-[0.24em] text-slate-500">Preparing your calm space</span>
        </div>
      </div>
    </div>
  );
}

function AppShell() {
  const activeTab = useAppStore((s) => s.activeTab);
  const activeScreen = useAppStore((s) => s.activeScreen);

  const mainPage = useMemo(() => {
    switch (activeTab) {
      case 'breathe':
        return <BreathePage />;
      case 'sounds':
        return <SoundsPage />;
      case 'journal':
        return <JournalPage />;
      case 'profile':
        return <ProfilePage />;
      case 'home':
      default:
        return <HomePage />;
    }
  }, [activeTab]);

  const overlay = useMemo(() => {
    if (activeScreen === 'main') return null;
    if (activeScreen === 'mood') return <MoodCheckIn />;
    if (activeScreen === 'progress') return <ProgressPage />;
    if (activeScreen === 'premium') return <PremiumPage />;
    if (activeScreen === 'transaction-history') return <TransactionHistoryPage />;
    if (activeScreen === 'download') return <DownloadPage />;
    if (activeScreen === 'crisis') return <CrisisPage />;
    if (activeScreen === 'help') return <HelpPage />;
    if (activeScreen === 'privacy') return <PrivacyPage />;
    if (activeScreen === 'terms') return <TermsPage />;
    if (activeScreen === 'about') return <AboutPage />;
    if (activeScreen === 'favorites') return <FavoritesPage />;
    if (activeScreen === 'reminders') return <RemindersPage />;
    if (activeScreen === 'mood-history') return <MoodHistoryPage />;
    if (activeScreen.startsWith('breathing-active-')) {
      return <BreathingSession patternId={activeScreen.replace('breathing-active-', '')} />;
    }
    if (activeScreen.startsWith('session-')) {
      return <QuickSessionPage sessionId={activeScreen} />;
    }
    return null;
  }, [activeScreen]);

  return (
    <div className="min-h-screen bg-[#0b1220] text-white">
      <div className="mx-auto min-h-screen max-w-lg overflow-hidden bg-[radial-gradient(circle_at_top,_rgba(52,211,153,0.08),_transparent_28%),radial-gradient(circle_at_bottom_right,_rgba(59,130,246,0.10),_transparent_32%),linear-gradient(180deg,#08111f_0%,#0d1726_55%,#111827_100%)] shadow-2xl shadow-black/30">
        <div className="relative min-h-screen">
          <TopActions />
          {mainPage}
          <BottomNav />
          {overlay}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const hasSeenOnboarding = useAppStore((s) => s.hasSeenOnboarding);
  const login = useAppStore((s) => s.login);
  const logout = useAppStore((s) => s.logout);
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = window.setTimeout(() => setShowSplash(false), 1800);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.location.pathname === '/download') {
      useAppStore.getState().setActiveScreen('download');
    }
    registerReferralClickFromUrl().catch(() => undefined);
    getRedirectResult(firebaseAuth).catch(() => undefined);

    const unsubscribe = onAuthStateChanged(firebaseAuth, async (user) => {
      if (!user) {
        logout();
        return;
      }

      await user.reload().catch(() => undefined);
      const refreshedUser = firebaseAuth.currentUser ?? user;
      const resolvedName = refreshedUser.displayName?.trim() || refreshedUser.email?.split('@')[0] || 'MindReset User';
      const resolvedProvider = refreshedUser.providerData.some((provider) => provider.providerId === 'google.com') ? 'google' : 'email';

      login(
        resolvedName,
        refreshedUser.email || '',
        resolvedProvider,
        refreshedUser.photoURL || ''
      );

      await upsertUserProfile({
        uid: refreshedUser.uid,
        name: resolvedName,
        email: refreshedUser.email || '',
        photoURL: refreshedUser.photoURL || '',
        provider: resolvedProvider,
      }).catch(() => undefined);

      await setupReferralProfile({
        uid: refreshedUser.uid,
        email: refreshedUser.email || '',
        name: resolvedName,
      }).catch(() => undefined);

      await attachPendingReferralToCurrentUser().catch(() => undefined);
    });

    return () => unsubscribe();
  }, [login, logout]);

  return (
    <>
      <AppShell />
      {!hasSeenOnboarding && !showSplash && <OnboardingScreen />}
      <AuthModal />
      {showSplash && <SplashScreen />}
    </>
  );
}
