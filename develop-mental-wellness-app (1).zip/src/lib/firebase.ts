import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  setPersistence,
  browserLocalPersistence,
} from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getFunctions } from 'firebase/functions';

const firebaseConfig = {
  apiKey: 'AIzaSyDJiKkt1zNzg4BoTQYDDbzM6r5VCK6nJIk',
  authDomain: 'unique-1bfee.firebaseapp.com',
  projectId: 'unique-1bfee',
  storageBucket: 'unique-1bfee.firebasestorage.app',
  messagingSenderId: '258209941798',
  appId: '1:258209941798:web:6aad5ef803b362c09519e7',
  measurementId: 'G-371DGWNQHV',
};

export const firebaseApp = initializeApp(firebaseConfig);
export const firebaseAuth = getAuth(firebaseApp);
export const firestoreDb = getFirestore(firebaseApp);
export const firebaseFunctions = getFunctions(firebaseApp);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

setPersistence(firebaseAuth, browserLocalPersistence).catch(() => undefined);
