import { jsPDF } from 'jspdf';
import type { TransactionItem } from './backend';

const COMPANY = {
  name: 'MindReset Wellness Labs',
  address1: '502 Serenity Avenue',
  address2: 'Bengaluru, Karnataka 560001, India',
  supportEmail: 'billing@mindreset.app',
  gstin: '29ABCDE1234F1Z5',
  vatId: 'EU-MR-204884',
};

export function getInvoiceNumber(transaction: TransactionItem) {
  const base = (transaction.purchaseDate ?? transaction.createdAt ?? Date.now()).toString().slice(-8);
  const ref = transaction.transactionReference.replace(/[^A-Za-z0-9]/g, '').slice(-6).toUpperCase();
  return `MR-${base}-${ref || 'INV'}`;
}

export function getReceiptNumber(transaction: TransactionItem) {
  const base = (transaction.createdAt ?? Date.now()).toString().slice(-6);
  return `RCPT-${base}-${transaction.id.slice(0, 4).toUpperCase()}`;
}

function drawLabelValue(doc: jsPDF, label: string, value: string, y: number) {
  doc.setFont('helvetica', 'bold');
  doc.text(label, 48, y);
  doc.setFont('helvetica', 'normal');
  doc.text(value || '—', 210, y);
}

function drawBrandHeader(doc: jsPDF) {
  doc.setFillColor(20, 184, 166);
  doc.roundedRect(48, 36, 46, 46, 14, 14, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(22);
  doc.text('MR', 60, 65);
  doc.setFontSize(24);
  doc.text('MindReset', 108, 58);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor(148, 163, 184);
  doc.text('Wellness Labs • Calm, sleep, focus', 108, 76);
}

export function exportTransactionsCsv(transactions: TransactionItem[]) {
  const headers = [
    'invoice_number',
    'receipt_number',
    'plan',
    'amount',
    'provider',
    'status',
    'transaction_reference',
    'purchase_date',
    'expiry_date',
    'cancellation_scheduled',
    'refund_status',
  ];

  const rows = transactions.map((item) => [
    getInvoiceNumber(item),
    getReceiptNumber(item),
    item.plan,
    item.amountLabel,
    item.provider,
    item.status,
    item.transactionReference,
    item.purchaseDate ? new Date(item.purchaseDate).toISOString() : '',
    item.expiryDate ? new Date(item.expiryDate).toISOString() : '',
    item.cancellationScheduled ? 'yes' : 'no',
    item.refundStatus || 'none',
  ]);

  const csv = [headers, ...rows]
    .map((row) => row.map((value) => `"${String(value ?? '').replace(/"/g, '""')}"`).join(','))
    .join('\n');

  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `mindreset-transactions-${Date.now()}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

export function buildInvoiceHtml(transaction: TransactionItem, customerEmail: string) {
  return `
  <html>
    <head>
      <title>MindReset Invoice - ${transaction.transactionReference}</title>
      <style>
        body { font-family: Inter, Arial, sans-serif; background:#0b1220; color:#e5eefc; padding:32px; }
        .card { max-width:760px; margin:0 auto; background:#121a2f; border:1px solid rgba(255,255,255,.08); border-radius:24px; padding:28px; }
        .muted { color:#94a3b8; }
        .row { display:flex; justify-content:space-between; gap:16px; padding:10px 0; border-bottom:1px solid rgba(255,255,255,.06); }
        .chip { display:inline-block; margin-right:8px; padding:8px 12px; border-radius:999px; background:#142033; border:1px solid rgba(255,255,255,.08); color:#cbd5e1; font-size:12px; }
        h1,h2,h3,p { margin:0; }
        .grid { display:grid; grid-template-columns:1fr 1fr; gap:18px; margin:20px 0; }
      </style>
    </head>
    <body>
      <div class="card">
        <h1>MindReset Invoice / Receipt</h1>
        <p class="muted" style="margin-top:8px;">Verified Pro subscription transaction</p>
        <div style="margin-top:16px;">
          <span class="chip">Invoice ${getInvoiceNumber(transaction)}</span>
          <span class="chip">Receipt ${getReceiptNumber(transaction)}</span>
        </div>
        <div class="grid">
          <div>
            <h3>Bill From</h3>
            <p class="muted" style="margin-top:8px;">${COMPANY.name}<br/>${COMPANY.address1}<br/>${COMPANY.address2}<br/>Support: ${COMPANY.supportEmail}</p>
          </div>
          <div>
            <h3>Tax Details</h3>
            <p class="muted" style="margin-top:8px;">GSTIN: ${COMPANY.gstin}<br/>VAT ID: ${COMPANY.vatId}<br/>Customer: ${customerEmail || 'Signed-in user'}</p>
          </div>
        </div>
        <div class="row"><strong>Plan</strong><span>${transaction.plan}</span></div>
        <div class="row"><strong>Amount</strong><span>${transaction.amountLabel}</span></div>
        <div class="row"><strong>Provider</strong><span>${transaction.provider}</span></div>
        <div class="row"><strong>Status</strong><span>${transaction.status}</span></div>
        <div class="row"><strong>Reference</strong><span>${transaction.transactionReference}</span></div>
        <div class="row"><strong>Purchased</strong><span>${new Date(transaction.purchaseDate ?? transaction.createdAt ?? Date.now()).toLocaleString()}</span></div>
        <div class="row"><strong>Access until</strong><span>${transaction.expiryDate ? new Date(transaction.expiryDate).toLocaleString() : '—'}</span></div>
        <div class="row"><strong>Cancellation</strong><span>${transaction.cancellationScheduled ? 'Scheduled at period end' : 'Auto-renew active / not scheduled'}</span></div>
        <div class="row"><strong>Refund status</strong><span>${transaction.refundStatus || 'none'}</span></div>
        <p class="muted" style="margin-top:18px; line-height:1.7;">This document reflects a verified MindReset transaction record. Subscription access remains active until the billing period ends if cancellation has been scheduled. Approved refunds are sent back to the original payment method.</p>
      </div>
    </body>
  </html>`;
}

export function exportTransactionPdf(transaction: TransactionItem, customerEmail: string) {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const invoiceNumber = getInvoiceNumber(transaction);
  const receiptNumber = getReceiptNumber(transaction);

  doc.setFillColor(11, 18, 32);
  doc.rect(0, 0, 595, 842, 'F');

  drawBrandHeader(doc);

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(24);
  doc.text('Invoice / Receipt', 48, 116);

  doc.setFontSize(11);
  doc.setTextColor(148, 163, 184);
  doc.text('Verified Pro subscription transaction', 48, 138);

  doc.setDrawColor(36, 48, 67);
  doc.setLineWidth(1);
  doc.line(48, 102, 547, 102);

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(12);
  drawLabelValue(doc, 'Invoice number', invoiceNumber, 138);
  drawLabelValue(doc, 'Receipt number', receiptNumber, 162);
  drawLabelValue(doc, 'Customer email', customerEmail || 'Signed-in user', 186);
  drawLabelValue(doc, 'Plan', transaction.plan, 210);
  drawLabelValue(doc, 'Amount', transaction.amountLabel, 234);
  drawLabelValue(doc, 'Provider', transaction.provider, 258);
  drawLabelValue(doc, 'Status', transaction.status, 282);
  drawLabelValue(doc, 'Reference', transaction.transactionReference, 306);
  drawLabelValue(doc, 'Purchased', new Date(transaction.purchaseDate ?? transaction.createdAt ?? Date.now()).toLocaleString(), 330);
  drawLabelValue(doc, 'Access until', transaction.expiryDate ? new Date(transaction.expiryDate).toLocaleString() : '—', 354);
  drawLabelValue(doc, 'Cancellation', transaction.cancellationScheduled ? 'Scheduled at period end' : 'Auto-renew active / not scheduled', 378);
  drawLabelValue(doc, 'Refund status', transaction.refundStatus || 'none', 402);

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('Bill From', 48, 462);
  doc.text('Tax Details', 320, 462);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text(`${COMPANY.name}\n${COMPANY.address1}\n${COMPANY.address2}\n${COMPANY.supportEmail}`, 48, 486);
  doc.text(`GSTIN: ${COMPANY.gstin}\nVAT ID: ${COMPANY.vatId}`, 320, 486);

  doc.text(
    'This document reflects a verified MindReset transaction record. Subscription access remains active until the billing period ends if cancellation has been scheduled. Approved refunds are sent back to the original payment method.',
    48,
    580,
    { maxWidth: 500 }
  );

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.text('MindReset Wellness Labs', 48, 760);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text(`Support: ${COMPANY.supportEmail}`, 48, 780);

  doc.save(`${invoiceNumber}.pdf`);
}

export async function shareTransactionInvoice(transaction: TransactionItem, customerEmail: string) {
  const text = `MindReset invoice ${getInvoiceNumber(transaction)} for ${transaction.amountLabel} (${transaction.plan})\nReference: ${transaction.transactionReference}\nCustomer: ${customerEmail || 'Signed-in user'}`;

  if (typeof navigator !== 'undefined' && navigator.share) {
    await navigator.share({
      title: `MindReset Invoice ${getInvoiceNumber(transaction)}`,
      text,
    });
    return true;
  }

  if (typeof navigator !== 'undefined' && navigator.clipboard) {
    await navigator.clipboard.writeText(text);
    return false;
  }

  return false;
}

export async function downloadAllInvoices(transactions: TransactionItem[], customerEmail: string) {
  for (const transaction of transactions) {
    exportTransactionPdf(transaction, customerEmail);
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
}
