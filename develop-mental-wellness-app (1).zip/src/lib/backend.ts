import {
  addDoc,
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  type DocumentData,
} from 'firebase/firestore';
import { httpsCallable } from 'firebase/functions';
import { firebaseAuth, firestoreDb, firebaseFunctions } from './firebase';

export type BillingProvider = 'paypal' | 'razorpay';
export type BillingPlan = 'monthly' | 'yearly' | 'lifetime';
export type BillingStatus = 'pending' | 'active' | 'cancelled' | 'expired' | 'failed';

export interface TransactionItem {
  id: string;
  provider: BillingProvider;
  plan: BillingPlan;
  amountLabel: string;
  currency: string;
  status: BillingStatus;
  transactionReference: string;
  createdAt?: number;
  purchaseDate?: number | null;
  expiryDate?: number | null;
  cancellationScheduled?: boolean;
  refundStatus?: 'none' | 'requested' | 'processing' | 'approved' | 'rejected' | 'refunded';
  refundReason?: string;
  refundRequestedAt?: number | null;
  refundCompletedAt?: number | null;
}

export interface SubscriptionSnapshot {
  status: BillingStatus;
  plan: BillingPlan | 'free';
  provider?: BillingProvider;
  region?: string;
  transactionReference?: string;
  purchaseDate?: number | null;
  expiryDate?: number | null;
  cancelAtPeriodEnd?: boolean;
  refundPolicy?: string;
}

const requireUid = () => {
  const uid = firebaseAuth.currentUser?.uid;
  if (!uid) throw new Error('Please sign in first.');
  return uid;
};

const userDoc = (uid: string) => doc(firestoreDb, 'users', uid);
const subscriptionDoc = (uid: string) => doc(firestoreDb, 'subscriptions', uid);
const transactionsCol = (uid: string) => collection(firestoreDb, 'users', uid, 'transactions');

export async function upsertUserProfile(profile: { uid: string; name: string; email: string; photoURL?: string; provider?: string | null; }) {
  await setDoc(userDoc(profile.uid), {
    uid: profile.uid,
    name: profile.name,
    email: profile.email,
    photoURL: profile.photoURL || '',
    provider: profile.provider || 'email',
    updatedAt: serverTimestamp(),
    createdAt: serverTimestamp(),
  }, { merge: true });
}

export async function getSubscriptionSnapshot(): Promise<SubscriptionSnapshot | null> {
  const uid = requireUid();
  const snap = await getDoc(subscriptionDoc(uid));
  if (!snap.exists()) return null;
  return snap.data() as SubscriptionSnapshot;
}

export async function listTransactions(): Promise<TransactionItem[]> {
  const uid = requireUid();
  const q = query(transactionsCol(uid), orderBy('createdAt', 'desc'), limit(20));
  const snap = await getDocs(q);
  return snap.docs.map((item) => ({ id: item.id, ...(item.data() as DocumentData) })) as TransactionItem[];
}

export async function createCheckoutIntent(input: { provider: BillingProvider; plan: BillingPlan; region: string; priceLabel: string; }) {
  const uid = requireUid();
  const callable = httpsCallable(firebaseFunctions, 'createCheckoutIntent');
  const result = await callable({ uid, ...input });
  return result.data as {
    checkoutUrl?: string;
    approvalUrl?: string;
    orderId?: string;
    subscriptionId?: string;
    reference: string;
    provider: BillingProvider;
    plan: BillingPlan;
  };
}

export async function verifyCheckout(input: { provider: BillingProvider; reference: string; paypalSubscriptionId?: string; razorpayPaymentId?: string; razorpaySignature?: string; razorpaySubscriptionId?: string; }) {
  const uid = requireUid();
  const callable = httpsCallable(firebaseFunctions, 'verifyCheckout');
  const result = await callable({ uid, ...input });
  return result.data as {
    verified: boolean;
    status: BillingStatus;
    plan: BillingPlan;
    region: string;
    transactionReference: string;
    expiryDate?: number | null;
    purchaseDate?: number | null;
    provider: BillingProvider;
    cancelAtPeriodEnd?: boolean;
  };
}

export async function cancelSubscriptionNow() {
  const uid = requireUid();
  const callable = httpsCallable(firebaseFunctions, 'cancelSubscription');
  const result = await callable({ uid, cancelAtPeriodEnd: true });
  return result.data as {
    ok: boolean;
    cancelAtPeriodEnd: boolean;
    expiryDate?: number | null;
    refundPolicy?: string;
  };
}

export async function requestSubscriptionRefund(input: { reference: string; reason: string }) {
  const uid = requireUid();
  const callable = httpsCallable(firebaseFunctions, 'requestRefund');
  const result = await callable({ uid, ...input });
  return result.data as {
    ok: boolean;
    refundStatus: 'requested' | 'processing';
    message: string;
  };
}

export async function seedPendingTransaction(input: { provider: BillingProvider; plan: BillingPlan; amountLabel: string; currency: string; reference: string; region: string; }) {
  const uid = requireUid();
  await addDoc(transactionsCol(uid), {
    provider: input.provider,
    plan: input.plan,
    amountLabel: input.amountLabel,
    currency: input.currency,
    status: 'pending',
    transactionReference: input.reference,
    region: input.region,
    createdAt: Date.now(),
    cancellationScheduled: false,
  });
}

export async function markTransactionStatus(reference: string, status: BillingStatus, extra?: Partial<TransactionItem>) {
  const uid = requireUid();
  const q = query(transactionsCol(uid), where('transactionReference', '==', reference), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return;
  await updateDoc(snap.docs[0].ref, {
    status,
    ...extra,
  });
}

export interface ReferralStatsSnapshot {
  referralCode: string;
  totalShares: number;
  clicks: number;
  successfulInvites: number;
}

export async function ensureReferralProfile(input: { uid: string; email?: string | null; name?: string | null; referralCode: string }) {
  await setDoc(doc(firestoreDb, 'referrals', input.uid), {
    uid: input.uid,
    email: input.email || '',
    name: input.name || '',
    referralCode: input.referralCode,
    totalShares: 0,
    clicks: 0,
    successfulInvites: 0,
    updatedAt: serverTimestamp(),
    createdAt: serverTimestamp(),
  }, { merge: true });
}

export async function getReferralStats(uid: string): Promise<ReferralStatsSnapshot | null> {
  const snap = await getDoc(doc(firestoreDb, 'referrals', uid));
  if (!snap.exists()) return null;
  const data = snap.data() as DocumentData;
  return {
    referralCode: data.referralCode || '',
    totalShares: Number(data.totalShares || 0),
    clicks: Number(data.clicks || 0),
    successfulInvites: Number(data.successfulInvites || 0),
  };
}

export async function incrementReferralShare(uid: string) {
  const ref = doc(firestoreDb, 'referrals', uid);
  const snap = await getDoc(ref);
  const current = snap.exists() ? Number((snap.data() as DocumentData).totalShares || 0) : 0;
  await setDoc(ref, { totalShares: current + 1, updatedAt: serverTimestamp() }, { merge: true });
}

export async function trackReferralClick(input: { referralCode: string; source?: string | null }) {
  const q = query(collection(firestoreDb, 'referrals'), where('referralCode', '==', input.referralCode), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return;
  const ownerRef = snap.docs[0].ref;
  const ownerData = snap.docs[0].data() as DocumentData;
  await updateDoc(ownerRef, {
    clicks: Number(ownerData.clicks || 0) + 1,
    updatedAt: serverTimestamp(),
  });
  await addDoc(collection(firestoreDb, 'referralClicks'), {
    referralCode: input.referralCode,
    source: input.source || 'referral',
    createdAt: Date.now(),
  });
}

export async function connectReferralForCurrentUser(input: { referralCode: string }) {
  const uid = requireUid();
  const referralQuery = query(collection(firestoreDb, 'referrals'), where('referralCode', '==', input.referralCode), limit(1));
  const referralSnap = await getDocs(referralQuery);
  if (referralSnap.empty) return { connected: false, reason: 'missing_referrer' as const };

  const ownerDoc = referralSnap.docs[0];
  const ownerUid = ownerDoc.id;
  if (ownerUid === uid) return { connected: false, reason: 'self_referral' as const };

  const linkDocRef = doc(firestoreDb, 'users', uid, 'meta', 'referralAttribution');
  const linkSnap = await getDoc(linkDocRef);
  if (linkSnap.exists()) return { connected: false, reason: 'already_connected' as const };

  await setDoc(linkDocRef, {
    referredByUid: ownerUid,
    referralCode: input.referralCode,
    createdAt: serverTimestamp(),
  });

  await updateDoc(ownerDoc.ref, {
    successfulInvites: Number((ownerDoc.data() as DocumentData).successfulInvites || 0) + 1,
    updatedAt: serverTimestamp(),
  });

  return { connected: true, reason: 'connected' as const };
}
