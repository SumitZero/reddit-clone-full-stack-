import {
  connectReferralForCurrentUser,
  ensureReferralProfile,
  getReferralStats as getReferralStatsFromDb,
  incrementReferralShare,
  trackReferralClick,
  type ReferralStatsSnapshot,
} from './backend';

export function getReferralCode(uid?: string | null, email?: string | null) {
  const seed = (uid || email || 'mindreset-user').replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  return `MR-${seed.slice(0, 10) || 'CALM2026'}`;
}

export function getReferralLink(uid?: string | null, email?: string | null) {
  const code = getReferralCode(uid, email);
  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://mindreset.app';
  return `${origin}/download?ref=${encodeURIComponent(code)}&source=referral`;
}

export function getReferralMessage(uid?: string | null, email?: string | null) {
  const link = getReferralLink(uid, email);
  return `I’ve been using MindReset to calm stress, reset my focus, and build a daily wellness habit. Download it here: ${link}`;
}

export async function loadReferralStats(uid?: string | null, email?: string | null): Promise<ReferralStatsSnapshot> {
  const code = getReferralCode(uid, email);
  if (!uid) {
    return {
      referralCode: code,
      totalShares: 0,
      clicks: 0,
      successfulInvites: 0,
    };
  }

  const dbStats = await getReferralStatsFromDb(uid);
  return dbStats ?? {
    referralCode: code,
    totalShares: 0,
    clicks: 0,
    successfulInvites: 0,
  };
}

export async function setupReferralProfile(input: { uid?: string | null; email?: string | null; name?: string | null }) {
  if (!input.uid) return;
  await ensureReferralProfile({
    uid: input.uid,
    email: input.email,
    name: input.name,
    referralCode: getReferralCode(input.uid, input.email),
  });
}

export async function registerReferralClickFromUrl() {
  if (typeof window === 'undefined') return null;
  const params = new URLSearchParams(window.location.search);
  const referralCode = params.get('ref');
  if (!referralCode) return null;
  const source = params.get('source');
  const trackedKey = `mindreset-ref-click-${referralCode}`;
  if (window.sessionStorage.getItem(trackedKey)) return referralCode;
  await trackReferralClick({ referralCode, source });
  window.sessionStorage.setItem(trackedKey, '1');
  window.localStorage.setItem('mindreset-pending-referral', referralCode);
  return referralCode;
}

export async function attachPendingReferralToCurrentUser() {
  if (typeof window === 'undefined') return null;
  const referralCode = window.localStorage.getItem('mindreset-pending-referral');
  if (!referralCode) return null;
  const result = await connectReferralForCurrentUser({ referralCode });
  if (result.connected) {
    window.localStorage.removeItem('mindreset-pending-referral');
  }
  return result;
}

export async function shareReferralLink(uid?: string | null, email?: string | null) {
  const message = getReferralMessage(uid, email);
  const link = getReferralLink(uid, email);

  if (uid) {
    await incrementReferralShare(uid).catch(() => undefined);
  }

  if (typeof navigator !== 'undefined' && navigator.share) {
    await navigator.share({
      title: 'Try MindReset',
      text: message,
      url: link,
    });
    return true;
  }

  if (typeof navigator !== 'undefined' && navigator.clipboard) {
    await navigator.clipboard.writeText(message);
    return false;
  }

  return false;
}
