export type RegionGroup = 'price-sensitive' | 'mid-income' | 'high-income' | 'global';
export type PlanId = 'monthly' | 'yearly' | 'lifetime';

export interface PlanOption {
  id: PlanId;
  label: string;
  price: string;
  sublabel: string;
  badge?: string;
  savings?: string;
}

export interface PricingRegion {
  region: RegionGroup;
  currencyNote: string;
  exampleCountries: string[];
  monthly: PlanOption;
  yearly: PlanOption;
  lifetime: PlanOption;
}

const pricingMap: Record<RegionGroup, PricingRegion> = {
  'price-sensitive': {
    region: 'price-sensitive',
    currencyNote: 'Estimated local pricing',
    exampleCountries: ['India', 'Pakistan', 'Bangladesh', 'Indonesia', 'Philippines', 'Vietnam', 'Nigeria'],
    monthly: { id: 'monthly', label: 'Pro Monthly', price: '₹199/mo', sublabel: 'Flexible, cancel anytime' },
    yearly: { id: 'yearly', label: 'Pro Yearly', price: '₹999/yr', sublabel: 'Best value for daily calm', badge: 'Best Value', savings: 'Save about 58%' },
    lifetime: { id: 'lifetime', label: 'Lifetime', price: '₹2,999', sublabel: 'One-time purchase' },
  },
  'mid-income': {
    region: 'mid-income',
    currencyNote: 'Localized estimate shown',
    exampleCountries: ['Brazil', 'Mexico', 'Turkey', 'South Africa', 'Thailand'],
    monthly: { id: 'monthly', label: 'Pro Monthly', price: '$4.99/mo', sublabel: 'Flexible, cancel anytime' },
    yearly: { id: 'yearly', label: 'Pro Yearly', price: '$29.99/yr', sublabel: 'Best value for better habits', badge: 'Best Value', savings: 'Save about 50%' },
    lifetime: { id: 'lifetime', label: 'Lifetime', price: '$79.99', sublabel: 'One-time purchase' },
  },
  'high-income': {
    region: 'high-income',
    currencyNote: 'Standard premium pricing',
    exampleCountries: ['US', 'UK', 'Canada', 'Australia', 'Europe', 'UAE', 'Singapore'],
    monthly: { id: 'monthly', label: 'Pro Monthly', price: '$9.99/mo', sublabel: 'Flexible, cancel anytime' },
    yearly: { id: 'yearly', label: 'Pro Yearly', price: '$59.99/yr', sublabel: 'Best value for full access', badge: 'Best Value', savings: 'Save about 50%' },
    lifetime: { id: 'lifetime', label: 'Lifetime', price: '$149.99', sublabel: 'One-time purchase' },
  },
  global: {
    region: 'global',
    currencyNote: 'Default global pricing',
    exampleCountries: ['Global'],
    monthly: { id: 'monthly', label: 'Pro Monthly', price: '$5.99/mo', sublabel: 'Flexible, cancel anytime' },
    yearly: { id: 'yearly', label: 'Pro Yearly', price: '$39.99/yr', sublabel: 'Best value for consistent calm', badge: 'Best Value', savings: 'Save about 44%' },
    lifetime: { id: 'lifetime', label: 'Lifetime', price: '$99.99', sublabel: 'One-time purchase' },
  },
};

const includes = (value: string, list: string[]) => list.some((country) => value.includes(country.toLowerCase()));

export function detectPricingRegion(locale?: string, timezone?: string): PricingRegion {
  const source = `${locale ?? ''} ${timezone ?? ''}`.toLowerCase();

  if (includes(source, ['india', 'pakistan', 'bangladesh', 'indonesia', 'philippines', 'vietnam', 'nigeria', 'asia/kolkata', 'asia/dhaka', 'asia/jakarta', 'africa/lagos', 'asia/manila', 'asia/karachi'])) {
    return pricingMap['price-sensitive'];
  }

  if (includes(source, ['brazil', 'mexico', 'turkey', 'south africa', 'thailand', 'america/sao_paulo', 'america/mexico_city', 'europe/istanbul', 'africa/johannesburg', 'asia/bangkok'])) {
    return pricingMap['mid-income'];
  }

  if (includes(source, ['united states', 'us', 'uk', 'canada', 'australia', 'europe', 'uae', 'singapore', 'america/new_york', 'america/los_angeles', 'europe/london', 'europe/paris', 'asia/dubai', 'asia/singapore'])) {
    return pricingMap['high-income'];
  }

  return pricingMap.global;
}
