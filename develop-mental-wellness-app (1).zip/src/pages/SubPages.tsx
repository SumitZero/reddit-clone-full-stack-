import { useState, useEffect, useRef } from 'react';
import { useAppStore } from '../store/appStore';
import { crisisResources, calmingQuotes, groundingSteps, affirmations } from '../data/content';
import { ArrowLeft, Phone, Heart, Bell, ChevronRight, CheckCircle2, Shield, Volume2 } from 'lucide-react';

// Crisis Support Page
export function CrisisPage() {
  const { setActiveScreen } = useAppStore();
  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Crisis Support</h1>
        </div>

        <div className="p-5 rounded-2xl bg-red-500/10 border border-red-500/20 mb-6 animate-fade-in">
          <p className="text-white font-semibold text-sm mb-2">If you are in immediate danger</p>
          <p className="text-slate-300 text-sm leading-relaxed">
            Please call your local emergency services immediately. You are not alone, and help is available.
          </p>
        </div>

        <p className="text-slate-400 text-sm mb-4">
          MindReset is a wellness app and is <strong className="text-white">not a substitute for professional mental health treatment</strong>. If you are experiencing a mental health crisis, please reach out to one of these resources:
        </p>

        <div className="space-y-3 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          {crisisResources.map((r, i) => (
            <div key={i} className="p-4 rounded-2xl glass-light border border-white/5">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-slate-500 mb-0.5">{r.country}</p>
                  <p className="text-white font-medium text-sm">{r.name}</p>
                  <p className="text-emerald-400 font-medium text-sm mt-1">{r.number}</p>
                  <p className="text-slate-400 text-xs mt-1">{r.description}</p>
                </div>
                <Phone size={18} className="text-emerald-400 flex-shrink-0 mt-1" />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 rounded-2xl glass-light border border-white/5">
          <p className="text-slate-300 text-xs leading-relaxed">
            <strong className="text-white">Disclaimer:</strong> MindReset provides general wellness content for relaxation and stress management. It is not a medical device, not a diagnostic tool, and not a substitute for professional therapy, counseling, or medical treatment. Always consult with a qualified healthcare provider for mental health concerns.
          </p>
        </div>
      </div>
    </div>
  );
}

// Help & FAQ
export function HelpPage() {
  const { setActiveScreen } = useAppStore();
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const faqs = [
    { q: 'What is MindReset?', a: 'MindReset is a wellness app designed to help you manage stress and build daily calm habits through breathing exercises, calming sounds, mood tracking, and journaling.' },
    { q: 'Is MindReset a therapy replacement?', a: 'No. MindReset is a wellness tool, not a medical device or therapy substitute. Please seek professional help for mental health concerns.' },
    { q: 'How do breathing exercises work?', a: 'Our breathing exercises use scientifically-backed patterns that activate your parasympathetic nervous system, naturally reducing stress and anxiety.' },
    { q: 'Is my journal data private?', a: 'Yes. All journal entries are stored locally on your device and are completely private. We do not read or share your journal content.' },
    { q: 'How do streaks work?', a: 'Complete at least one session per day to maintain your streak. Missing a day resets your streak to zero.' },
    { q: 'What does Premium include?', a: 'Premium unlocks all breathing patterns, the full sound library, advanced analytics, custom reminders, themes, and offline access.' },
    { q: 'How do I cancel my subscription?', a: 'You can manage and cancel your subscription through your app store account settings.' },
    { q: 'How do I contact support?', a: 'Email us at support@mindreset.app for any questions or feedback.' },
  ];

  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Help & FAQ</h1>
        </div>

        <div className="space-y-2 animate-fade-in">
          {faqs.map((faq, i) => (
            <div key={i} className="rounded-2xl glass-light border border-white/5 overflow-hidden">
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full flex items-center justify-between p-4 text-left"
              >
                <span className="text-white text-sm font-medium pr-4">{faq.q}</span>
                <ChevronRight size={16} className={`text-slate-500 transition-transform ${openFaq === i ? 'rotate-90' : ''}`} />
              </button>
              {openFaq === i && (
                <div className="px-4 pb-4 animate-fade-in">
                  <p className="text-slate-400 text-sm leading-relaxed">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-6 p-4 rounded-2xl glass-light border border-white/5 text-center">
          <p className="text-slate-400 text-sm mb-2">Still need help?</p>
          <p className="text-emerald-400 text-sm font-medium">support@mindreset.app</p>
        </div>
      </div>
    </div>
  );
}

// Privacy Policy
export function PrivacyPage() {
  const { setActiveScreen } = useAppStore();
  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Privacy Policy</h1>
        </div>
        <div className="prose prose-sm prose-invert animate-fade-in space-y-4">
          <p className="text-slate-400 text-sm">Last updated: January 2025</p>
          <div className="space-y-4 text-slate-300 text-sm leading-relaxed">
            <section>
              <h3 className="text-white font-semibold text-base mb-2">1. Information We Collect</h3>
              <p>We collect minimal data necessary to provide our services: account information (email, name) if you sign up, app usage data (sessions completed, preferences), and mood/journal entries which are stored privately.</p>
            </section>
            <section>
              <h3 className="text-white font-semibold text-base mb-2">2. How We Use Your Data</h3>
              <p>Your data is used solely to provide and improve MindReset services, track your wellness progress, personalize your experience, and send reminders you opt into.</p>
            </section>
            <section>
              <h3 className="text-white font-semibold text-base mb-2">3. Data Privacy</h3>
              <p>Journal entries are stored locally and/or encrypted. We never read, sell, or share your personal journal content. Mood data is used only for your personal analytics.</p>
            </section>
            <section>
              <h3 className="text-white font-semibold text-base mb-2">4. Third-Party Services</h3>
              <p>We may use Firebase for authentication and data storage, which has its own privacy policies. We do not sell your data to advertisers or third parties.</p>
            </section>
            <section>
              <h3 className="text-white font-semibold text-base mb-2">5. Your Rights</h3>
              <p>You can request to delete your account and all associated data at any time by contacting support@mindreset.app.</p>
            </section>
            <section>
              <h3 className="text-white font-semibold text-base mb-2">6. Contact</h3>
              <p>For privacy concerns, contact us at privacy@mindreset.app</p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

// Terms
export function TermsPage() {
  const { setActiveScreen } = useAppStore();
  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Terms of Service</h1>
        </div>
        <div className="animate-fade-in space-y-4 text-slate-300 text-sm leading-relaxed">
          <p className="text-slate-400">Last updated: January 2025</p>
          <section>
            <h3 className="text-white font-semibold text-base mb-2">1. Acceptance</h3>
            <p>By using MindReset, you agree to these terms. If you do not agree, please discontinue use.</p>
          </section>
          <section>
            <h3 className="text-white font-semibold text-base mb-2">2. Wellness Disclaimer</h3>
            <p>MindReset is a wellness app designed for relaxation and stress management. It is NOT a medical device, NOT a diagnostic tool, and NOT a substitute for professional therapy, counseling, or medical treatment. Always consult a qualified healthcare provider.</p>
          </section>
          <section>
            <h3 className="text-white font-semibold text-base mb-2">3. Subscriptions</h3>
            <p>Premium features require a paid subscription. Subscriptions auto-renew unless cancelled. Manage via your app store settings. Refunds are subject to app store policies.</p>
          </section>
          <section>
            <h3 className="text-white font-semibold text-base mb-2">4. User Conduct</h3>
            <p>You agree to use MindReset responsibly and not misuse the service. You are responsible for your account security.</p>
          </section>
          <section>
            <h3 className="text-white font-semibold text-base mb-2">5. Limitation of Liability</h3>
            <p>MindReset is provided "as is" without warranties. We are not liable for any health outcomes from using the app.</p>
          </section>
          <section>
            <h3 className="text-white font-semibold text-base mb-2">6. Contact</h3>
            <p>Contact us at legal@mindreset.app for any questions about these terms.</p>
          </section>
        </div>
      </div>
    </div>
  );
}

// About
export function AboutPage() {
  const { setActiveScreen } = useAppStore();
  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">About MindReset</h1>
        </div>
        <div className="animate-fade-in text-center mt-8">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-emerald-500/20">
            <span className="text-3xl">🧠</span>
          </div>
          <h2 className="text-2xl font-bold text-white font-display mb-2">MindReset</h2>
          <p className="text-slate-400 text-sm mb-1">Version 1.0.0</p>
          <p className="text-emerald-400 text-sm mb-6">Calm Your Mind in Minutes</p>

          <div className="text-left p-5 rounded-2xl glass-light border border-white/5 mb-4">
            <h3 className="text-white font-semibold text-sm mb-2">Our Mission</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              MindReset was created to help people deal with everyday stress, mental overload, and emotional fatigue. We believe everyone deserves a moment of calm, and it shouldn't take more than a minute or two to find it.
            </p>
          </div>

          <div className="text-left p-5 rounded-2xl glass-light border border-white/5 mb-4">
            <h3 className="text-white font-semibold text-sm mb-2">What We're Not</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              MindReset is not a medical app, not a therapy tool, and not a substitute for professional mental health treatment. We're a wellness companion that supports your daily calm habits.
            </p>
          </div>

          <p className="text-slate-500 text-xs mt-6">
            Made with 💚 for your mental wellness
          </p>
          <p className="text-slate-600 text-xs mt-1">
            support@mindreset.app
          </p>
        </div>
      </div>
    </div>
  );
}

// Favorites
export function FavoritesPage() {
  const { setActiveScreen, favoriteBreathing, favoriteSounds, favoriteQuotes } = useAppStore();
  const favQuotes = calmingQuotes.filter(q => favoriteQuotes.includes(q.id));

  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Favorites</h1>
        </div>

        {favoriteBreathing.length === 0 && favoriteSounds.length === 0 && favQuotes.length === 0 ? (
          <div className="mt-20 text-center animate-fade-in">
            <Heart size={40} className="text-slate-600 mx-auto mb-4" />
            <p className="text-white font-semibold text-lg mb-2">No Favorites Yet</p>
            <p className="text-slate-400 text-sm">
              Tap the heart icon on any exercise, sound,<br />or quote to add it here.
            </p>
          </div>
        ) : (
          <div className="space-y-6 animate-fade-in">
            {favoriteBreathing.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-slate-400 mb-2">Breathing Exercises ({favoriteBreathing.length})</h3>
                <div className="space-y-2">
                  {favoriteBreathing.map(id => (
                    <div key={id} className="p-3 rounded-xl glass-light border border-white/5 text-white text-sm capitalize">
                      {id.replace(/-/g, ' ')}
                    </div>
                  ))}
                </div>
              </div>
            )}
            {favoriteSounds.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-slate-400 mb-2">Sounds ({favoriteSounds.length})</h3>
                <div className="space-y-2">
                  {favoriteSounds.map(id => (
                    <div key={id} className="p-3 rounded-xl glass-light border border-white/5 text-white text-sm capitalize">
                      {id.replace(/-/g, ' ')}
                    </div>
                  ))}
                </div>
              </div>
            )}
            {favQuotes.length > 0 && (
              <div>
                <h3 className="text-sm font-semibold text-slate-400 mb-2">Quotes ({favQuotes.length})</h3>
                <div className="space-y-2">
                  {favQuotes.map(q => (
                    <div key={q.id} className="p-3 rounded-xl glass-light border border-white/5">
                      <p className="text-white text-sm italic">"{q.text}"</p>
                      <p className="text-slate-500 text-xs mt-1">— {q.author}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Reminders
export function RemindersPage() {
  const {
    setActiveScreen,
    reminders,
    alarms,
    toggleReminder,
    addReminder,
    updateReminder,
    toggleAlarm,
    addAlarm,
    clockFormat,
    setClockFormat,
    ringingAlarmId,
    dismissAlarm,
    snoozeAlarm,
  } = useAppStore();
  const [showReminderForm, setShowReminderForm] = useState(false);
  const [showAlarmForm, setShowAlarmForm] = useState(false);
  const [permission, setPermission] = useState(typeof Notification !== 'undefined' ? Notification.permission : 'default');
  const [toast, setToast] = useState('');
  const [reminderTitle, setReminderTitle] = useState('');
  const [reminderTime, setReminderTime] = useState('12:00');
  const [alarmTitle, setAlarmTitle] = useState('Wake Up Calm');
  const [alarmTime, setAlarmTime] = useState('07:00');
  const [reminderDays, setReminderDays] = useState<Array<'Sun' | 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat'>>(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']);
  const [alarmDays, setAlarmDays] = useState<Array<'Sun' | 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat'>>(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']);
  const [reminderSoundType, setReminderSoundType] = useState<'default' | 'url' | 'file'>('default');
  const [reminderSoundUrl, setReminderSoundUrl] = useState('');
  const [reminderSoundLabel, setReminderSoundLabel] = useState('MindReset Bell');
  const [ringtoneType, setRingtoneType] = useState<'default' | 'url' | 'file'>('default');
  const [ringtoneUrl, setRingtoneUrl] = useState('');
  const [ringtoneLabel, setRingtoneLabel] = useState('MindReset Bell');
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const weekdayOptions: Array<'Sun' | 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat'> = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const formatTime = (time: string) => {
    const [h, m] = time.split(':').map(Number);
    if (clockFormat === '24h') return time;
    const period = h >= 12 ? 'PM' : 'AM';
    const hour12 = h % 12 || 12;
    return `${hour12}:${String(m).padStart(2, '0')} ${period}`;
  };

  const playAlarmTone = async (src?: string) => {
    try {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0;
      }
      const fallback = 'https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg';
      const audio = new Audio(src || fallback);
      audio.loop = true;
      audio.volume = 1;
      audioRef.current = audio;
      await audio.play();
    } catch {
      setToast('Alarm triggered. Tap the page once if your browser blocks autoplay.');
    }
  };

  const stopAlarmTone = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  useEffect(() => {
    const interval = window.setInterval(() => {
      const state = useAppStore.getState();
      const now = Date.now();

      state.reminders.forEach((item) => {
        if (item.enabled && item.nextTriggerAt && now >= item.nextTriggerAt && (!item.lastTriggeredAt || now - item.lastTriggeredAt > 60000)) {
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification(item.title, { body: `It's time for your calm break • ${formatTime(item.time)}` });
          }
          state.updateReminder(item.id, { lastTriggeredAt: now, nextTriggerAt: now + 24 * 60 * 60 * 1000 });
        }
      });

      state.alarms.forEach((item) => {
        if (item.enabled && item.nextTriggerAt && now >= item.nextTriggerAt && (!item.lastTriggeredAt || now - item.lastTriggeredAt > 60000)) {
          state.updateAlarm(item.id, { lastTriggeredAt: now, nextTriggerAt: now + 24 * 60 * 60 * 1000 });
          useAppStore.setState({ ringingAlarmId: item.id });
          if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
            new Notification(item.title, { body: `Alarm ringing now • ${formatTime(item.time)}` });
          }
          playAlarmTone(item.ringtoneUrl);
        }
      });
    }, 1000);

    return () => window.clearInterval(interval);
  }, [clockFormat]);

  useEffect(() => {
    return () => stopAlarmTone();
  }, []);

  const requestNotificationPermission = async () => {
    if (!('Notification' in window)) {
      setToast('Notifications are not supported in this browser preview.');
      return;
    }
    const result = await Notification.requestPermission();
    setPermission(result);
    setToast(result === 'granted' ? 'Notifications enabled for reminders and alarms.' : 'Notification permission was not granted.');
  };

  const showPermissionWhy = () => {
    setToast('We ask for notification permission so your reminders and alarms can appear on your phone at the scheduled time.');
  };

  const toggleReminderDay = (day: 'Sun' | 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat') => {
    setReminderDays((current) => current.includes(day) ? current.filter((d) => d !== day) : [...current, day]);
  };

  const toggleAlarmDay = (day: 'Sun' | 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat') => {
    setAlarmDays((current) => current.includes(day) ? current.filter((d) => d !== day) : [...current, day]);
  };

  const handleAddReminder = () => {
    if (!reminderTitle.trim() || !reminderDays.length) {
      setToast('Please add a reminder name and choose at least one day.');
      return;
    }
    addReminder(reminderTitle.trim(), reminderTime, reminderDays);
    const latestReminder = useAppStore.getState().reminders[0];
    if (latestReminder) {
      updateReminder(latestReminder.id, {
        ringtoneType: reminderSoundType as never,
        ringtoneUrl: reminderSoundType === 'default' ? undefined : reminderSoundUrl,
        ringtoneLabel: reminderSoundLabel,
      } as never);
    }
    setReminderTitle('');
    setReminderTime('12:00');
    setReminderDays(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']);
    setReminderSoundType('default');
    setReminderSoundUrl('');
    setReminderSoundLabel('MindReset Bell');
    setShowReminderForm(false);
    setToast('Reminder added successfully and scheduling is active.');
  };

  const handleAddAlarm = () => {
    if (!alarmTitle.trim() || !alarmDays.length) {
      setToast('Please add an alarm name and choose at least one day.');
      return;
    }
    addAlarm({
      title: alarmTitle.trim(),
      time: alarmTime,
      enabled: true,
      days: alarmDays,
      ringtoneType,
      ringtoneLabel,
      ringtoneUrl: ringtoneType === 'default' ? undefined : ringtoneUrl,
    });
    setAlarmTitle('Wake Up Calm');
    setAlarmTime('07:00');
    setAlarmDays(['Mon', 'Tue', 'Wed', 'Thu', 'Fri']);
    setRingtoneType('default');
    setRingtoneUrl('');
    setRingtoneLabel('MindReset Bell');
    setShowAlarmForm(false);
    setToast('Alarm added successfully. It will ring at the exact scheduled time while the app is active.');
  };

  const ringingAlarm = alarms.find((a) => a.id === ringingAlarmId);

  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-10 max-w-lg mx-auto">
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Reminders & Alarms</h1>
        </div>

        <div className="p-4 rounded-2xl glass-light border border-white/5 mb-4 space-y-3">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-white text-sm font-medium">Time format</p>
              <p className="text-slate-400 text-xs">Choose 12-hour or 24-hour clock for reminders and alarms</p>
            </div>
            <div className="flex rounded-xl bg-white/5 p-1 border border-white/5">
              {(['12h', '24h'] as const).map((format) => (
                <button
                  key={format}
                  onClick={() => setClockFormat(format)}
                  className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${clockFormat === format ? 'bg-emerald-500 text-white' : 'text-slate-400'}`}
                >
                  {format}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button onClick={requestNotificationPermission} className="py-2.5 rounded-xl border border-emerald-500/20 bg-emerald-500/10 text-emerald-300 text-sm font-medium flex items-center justify-center gap-2">
              <Shield size={16} />
              {permission === 'granted' ? 'Notifications enabled' : 'Enable notifications'}
            </button>
            <button onClick={showPermissionWhy} className="py-2.5 rounded-xl border border-white/10 bg-white/5 text-slate-300 text-sm font-medium">
              Why we ask permission
            </button>
          </div>
          <div className="rounded-2xl bg-white/5 border border-white/5 p-3">
            <p className="text-white text-xs font-medium mb-1">Permissions needed for mobile app publishing</p>
            <p className="text-slate-400 text-xs leading-relaxed">Notifications are needed so your reminders and alarms can alert you on time. Audio/file access is needed only when you choose a custom ringtone from your device gallery.</p>
          </div>
          {toast && (
            <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-3 flex items-start gap-2 animate-fade-in">
              <CheckCircle2 size={16} className="text-emerald-300 mt-0.5" />
              <p className="text-emerald-100 text-xs leading-relaxed">{toast}</p>
            </div>
          )}
        </div>

        {ringingAlarm && (
          <div className="mb-4 p-4 rounded-3xl border border-amber-400/30 bg-amber-500/10 animate-fade-in">
            <p className="text-amber-300 text-xs uppercase tracking-[0.2em] mb-1">Alarm ringing</p>
            <p className="text-white font-semibold text-lg">{ringingAlarm.title}</p>
            <p className="text-slate-300 text-sm mt-1">{formatTime(ringingAlarm.time)} • {ringingAlarm.ringtoneLabel}</p>
            <div className="flex gap-3 mt-4">
              <button onClick={() => snoozeAlarm(10)} className="flex-1 py-3 rounded-2xl border border-white/10 text-white text-sm">Snooze 10 min</button>
              <button onClick={dismissAlarm} className="flex-1 py-3 rounded-2xl bg-emerald-500 text-white text-sm font-semibold">Dismiss</button>
            </div>
          </div>
        )}

        <div className="space-y-3 animate-fade-in">
          {reminders.map((r) => (
            <div key={r.id} className="p-4 rounded-2xl glass-light border border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell size={18} className={r.enabled ? 'text-emerald-400' : 'text-slate-600'} />
                <div>
                  <p className="text-white text-sm font-medium">{r.title}</p>
                  <p className="text-slate-400 text-xs">{formatTime(r.time)} · {r.days.join(', ')}</p>
                </div>
              </div>
              <button onClick={() => toggleReminder(r.id)} className={`w-11 h-6 rounded-full transition-all ${r.enabled ? 'bg-emerald-500' : 'bg-slate-700'}`}>
                <div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${r.enabled ? 'translate-x-5.5' : 'translate-x-0.5'}`} />
              </button>
            </div>
          ))}
        </div>

        {showReminderForm && (
          <div className="mt-4 p-4 rounded-2xl glass-light border border-emerald-500/20 animate-fade-in space-y-3">
            <input type="text" placeholder="Reminder name" value={reminderTitle} onChange={(e) => setReminderTitle(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-emerald-500/30" />
            <div>
              <p className="text-slate-400 text-xs mb-2">Reminder time ({clockFormat === '12h' ? '12-hour' : '24-hour'} view)</p>
              <input type="time" value={reminderTime} onChange={(e) => setReminderTime(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500/30" />
            </div>
            <div className="flex flex-wrap gap-2">
              {weekdayOptions.map((day) => (
                <button key={day} onClick={() => toggleReminderDay(day)} className={`px-3 py-2 rounded-xl text-xs border ${reminderDays.includes(day) ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                  {day}
                </button>
              ))}
            </div>
            <div>
              <p className="text-slate-400 text-xs mb-2">Reminder sound</p>
              <div className="grid grid-cols-3 gap-2 mb-2">
                {(['default', 'url', 'file'] as const).map((type) => (
                  <button key={`reminder-${type}`} onClick={() => setReminderSoundType(type)} className={`py-2 rounded-xl text-xs border ${reminderSoundType === type ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                    {type === 'default' ? 'Default' : type === 'url' ? 'Sound URL' : 'Gallery file'}
                  </button>
                ))}
              </div>
              {reminderSoundType === 'url' && <input type="url" placeholder="Paste reminder sound URL" value={reminderSoundUrl} onChange={(e) => { setReminderSoundUrl(e.target.value); setReminderSoundLabel('Custom reminder URL'); }} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-emerald-500/30" />}
              {reminderSoundType === 'file' && <input type="file" accept="audio/*" onChange={(e) => { const file = e.target.files?.[0]; if (file) { setReminderSoundLabel(file.name); setReminderSoundUrl(URL.createObjectURL(file)); setToast('Custom reminder file selected.'); } }} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm file:text-white file:bg-transparent file:border-0" />}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowReminderForm(false)} className="flex-1 py-2 rounded-xl border border-slate-700 text-slate-400 text-sm">Cancel</button>
              <button onClick={handleAddReminder} className="flex-1 py-2 rounded-xl bg-emerald-500 text-white text-sm font-medium">Add Reminder</button>
            </div>
          </div>
        )}

        <button onClick={() => setShowReminderForm(true)} className="w-full mt-4 py-3 rounded-xl border border-dashed border-slate-700 text-slate-400 text-sm hover:bg-white/5 transition-all">+ Add Custom Reminder</button>

        <div className="mt-8 mb-3 flex items-center justify-between">
          <h2 className="text-white font-semibold">Alarms</h2>
          <span className="text-xs text-slate-500">Real browser logic</span>
        </div>

        <div className="space-y-3 animate-fade-in">
          {alarms.map((a) => (
            <div key={a.id} className="p-4 rounded-2xl glass-light border border-white/5 flex items-center justify-between">
              <div>
                <p className="text-white text-sm font-medium">{a.title}</p>
                <p className="text-slate-400 text-xs">{formatTime(a.time)} · {a.days.join(', ')}</p>
                <p className="text-slate-500 text-[11px] mt-1">{a.ringtoneLabel}</p>
              </div>
              <button onClick={() => toggleAlarm(a.id)} className={`w-11 h-6 rounded-full transition-all ${a.enabled ? 'bg-emerald-500' : 'bg-slate-700'}`}>
                <div className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${a.enabled ? 'translate-x-5.5' : 'translate-x-0.5'}`} />
              </button>
            </div>
          ))}
        </div>

        {showAlarmForm && (
          <div className="mt-4 p-4 rounded-2xl glass-light border border-cyan-500/20 animate-fade-in space-y-3">
            <input type="text" placeholder="Alarm name" value={alarmTitle} onChange={(e) => setAlarmTitle(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500/30" />
            <div>
              <p className="text-slate-400 text-xs mb-2">Alarm time ({clockFormat === '12h' ? '12-hour' : '24-hour'} view)</p>
              <input type="time" value={alarmTime} onChange={(e) => setAlarmTime(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-cyan-500/30" />
            </div>
            <div className="flex flex-wrap gap-2">
              {weekdayOptions.map((day) => (
                <button key={`alarm-${day}`} onClick={() => toggleAlarmDay(day)} className={`px-3 py-2 rounded-xl text-xs border ${alarmDays.includes(day) ? 'bg-cyan-500/20 border-cyan-500/30 text-cyan-300' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                  {day}
                </button>
              ))}
            </div>
            <div>
              <p className="text-slate-400 text-xs mb-2 flex items-center gap-2"><Volume2 size={14} /> Alarm ringtone</p>
              <div className="grid grid-cols-3 gap-2 mb-2">
                {(['default', 'url', 'file'] as const).map((type) => (
                  <button key={type} onClick={() => setRingtoneType(type)} className={`py-2 rounded-xl text-xs border ${ringtoneType === type ? 'bg-cyan-500/20 border-cyan-500/30 text-cyan-300' : 'bg-white/5 border-white/10 text-slate-400'}`}>
                    {type === 'default' ? 'Default' : type === 'url' ? 'Music URL' : 'Gallery file'}
                  </button>
                ))}
              </div>
              {ringtoneType === 'url' && <input type="url" placeholder="Paste ringtone / song URL" value={ringtoneUrl} onChange={(e) => { setRingtoneUrl(e.target.value); setRingtoneLabel('Custom URL ringtone'); }} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-cyan-500/30" />}
              {ringtoneType === 'file' && <input type="file" accept="audio/*" onChange={(e) => { const file = e.target.files?.[0]; if (file) { setRingtoneLabel(file.name); setRingtoneUrl(URL.createObjectURL(file)); setToast('Custom alarm file selected.'); } }} className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm file:text-white file:bg-transparent file:border-0" />}
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowAlarmForm(false)} className="flex-1 py-2 rounded-xl border border-slate-700 text-slate-400 text-sm">Cancel</button>
              <button onClick={handleAddAlarm} className="flex-1 py-2 rounded-xl bg-cyan-500 text-white text-sm font-medium">Add Alarm</button>
            </div>
          </div>
        )}

        <button onClick={() => setShowAlarmForm(true)} className="w-full mt-4 py-3 rounded-xl border border-dashed border-slate-700 text-slate-400 text-sm hover:bg-white/5 transition-all">+ Add Custom Alarm</button>

        <p className="text-slate-500 text-xs mt-5 text-center">
          On web, reminders and alarms use browser notification logic while the app is open. File and URL ringtones are stored locally in this session and are ready to connect to native mobile alarm logic later.
        </p>
      </div>
    </div>
  );
}

// Mood History
export function MoodHistoryPage() {
  const { setActiveScreen, moodEntries } = useAppStore();
  const moodEmojis: Record<string, string> = { stressed: '😫', tired: '😴', anxious: '😰', okay: '😐', calm: '😌', overwhelmed: '🤯', distracted: '🤔' };

  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Mood History</h1>
        </div>

        {moodEntries.length === 0 ? (
          <div className="mt-20 text-center animate-fade-in">
            <span className="text-5xl block mb-4">📊</span>
            <p className="text-white font-semibold text-lg mb-2">No mood data yet</p>
            <p className="text-slate-400 text-sm">Check in with your mood to see trends over time.</p>
          </div>
        ) : (
          <div className="space-y-2 animate-fade-in">
            {moodEntries.map(entry => {
              const d = new Date(entry.timestamp);
              return (
                <div key={entry.id} className="p-3 rounded-xl glass-light border border-white/5 flex items-center gap-3">
                  <span className="text-2xl">{moodEmojis[entry.mood] || '😐'}</span>
                  <div className="flex-1">
                    <p className="text-white text-sm font-medium capitalize">{entry.mood}</p>
                    <p className="text-slate-500 text-xs">
                      {d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} · {d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// Quick Session
export function QuickSessionPage({ sessionId }: { sessionId: string }) {
  const { setActiveScreen, addSession } = useAppStore();
  const [step, setStep] = useState(0);
  const [complete, setComplete] = useState(false);
  const [isRunning, setIsRunning] = useState(false);

  const sessionType = sessionId.replace('session-', '');

  const getSessionContent = () => {
    switch (sessionType) {
      case 'pause-30s':
        return {
          title: '30-Second Pause',
          steps: [
            { text: 'Close your eyes gently', duration: 5 },
            { text: 'Take a slow, deep breath in...', duration: 5 },
            { text: 'Hold it gently...', duration: 3 },
            { text: 'Now breathe out slowly...', duration: 7 },
            { text: 'Let your shoulders drop', duration: 5 },
            { text: 'You are here. You are safe.', duration: 5 },
          ],
        };
      case 'breath-1min':
        return {
          title: '1-Minute Breathing Reset',
          steps: [
            { text: 'Find a comfortable position', duration: 5 },
            { text: 'Breathe in deeply... 1... 2... 3... 4...', duration: 8 },
            { text: 'Hold... 1... 2... 3... 4...', duration: 6 },
            { text: 'Breathe out slowly... 1... 2... 3... 4... 5... 6...', duration: 10 },
            { text: 'Again. Breathe in... 1... 2... 3... 4...', duration: 8 },
            { text: 'Hold... 1... 2... 3... 4...', duration: 6 },
            { text: 'Breathe out... let everything go...', duration: 10 },
            { text: 'Notice the calm.', duration: 7 },
          ],
        };
      case 'ground-2min':
        return {
          title: '2-Minute Grounding',
          steps: groundingSteps.map(s => ({
            text: `${s.icon} ${s.sense}: ${s.instruction}`,
            duration: 20,
          })),
        };
      case 'affirmation':
        const aff = affirmations[Math.floor(Math.random() * affirmations.length)];
        return {
          title: 'Quick Affirmation',
          steps: [
            { text: 'Take a breath...', duration: 5 },
            { text: aff, duration: 15 },
            { text: 'Repeat it to yourself...', duration: 5 },
            { text: 'Believe it. You are enough.', duration: 5 },
          ],
        };
      case 'focus-reset':
        return {
          title: 'Focus Reset',
          steps: [
            { text: 'Look away from your screen', duration: 5 },
            { text: 'Focus on something far away for 10 seconds', duration: 12 },
            { text: 'Now close your eyes', duration: 5 },
            { text: 'Take 3 deep breaths', duration: 18 },
            { text: 'Set one clear intention for the next hour', duration: 15 },
            { text: 'Open your eyes. You are refreshed.', duration: 5 },
          ],
        };
      case 'body-scan':
        return {
          title: 'Quick Body Scan',
          steps: [
            { text: 'Close your eyes. Start at the top of your head.', duration: 10 },
            { text: 'Notice your forehead. Relax it.', duration: 10 },
            { text: 'Relax your jaw. Unclench your teeth.', duration: 10 },
            { text: 'Drop your shoulders away from your ears.', duration: 10 },
            { text: 'Feel your hands. Let them soften.', duration: 10 },
            { text: 'Notice your breathing. Let it flow naturally.', duration: 10 },
            { text: 'Relax your legs and feet.', duration: 10 },
            { text: 'Your whole body is calm now.', duration: 10 },
          ],
        };
      default:
        return { title: 'Session', steps: [{ text: 'Breathe and relax', duration: 30 }] };
    }
  };

  const session = getSessionContent();
  const totalSteps = session.steps.length;

  useEffect(() => {
    if (!isRunning || complete) return;
    const currentStep = session.steps[step];
    if (!currentStep) return;

    const timeout = setTimeout(() => {
      if (step < totalSteps - 1) {
        setStep(step + 1);
      } else {
        setComplete(true);
        setIsRunning(false);
        addSession(1);
      }
    }, currentStep.duration * 1000);

    return () => clearTimeout(timeout);
  }, [isRunning, step, complete, totalSteps]);

  return (
    <div className="fixed inset-0 bg-surface z-50 flex flex-col">
      <div className="flex items-center justify-between px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-2">
        <button onClick={() => setActiveScreen('main')} className="p-2 rounded-xl hover:bg-white/5">
          <ArrowLeft size={22} className="text-slate-400" />
        </button>
        <p className="text-white font-medium text-sm">{session.title}</p>
        <div className="w-10" />
      </div>

      {/* Progress */}
      <div className="px-4 mt-2">
        <div className="flex gap-1">
          {session.steps.map((_, i) => (
            <div key={i} className={`flex-1 h-1 rounded-full ${i <= step ? 'bg-emerald-500' : 'bg-slate-800'} transition-all`} />
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center px-8">
        {!isRunning && !complete && (
          <div className="text-center animate-fade-in">
            <div className="w-24 h-24 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-6 animate-float">
              <span className="text-4xl">🌿</span>
            </div>
            <h2 className="text-xl font-bold text-white font-display mb-3">{session.title}</h2>
            <p className="text-slate-400 text-sm mb-8">Find a quiet moment and let's begin.</p>
            <button
              onClick={() => { setIsRunning(true); setStep(0); }}
              className="px-12 py-4 rounded-2xl bg-emerald-500 text-white font-semibold text-lg shadow-lg shadow-emerald-500/20 active:scale-[0.97] transition-all"
            >
              Start
            </button>
          </div>
        )}

        {isRunning && !complete && (
          <div className="text-center animate-fade-in" key={step}>
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center mx-auto mb-8 animate-pulse-ring">
              <div className="w-24 h-24 rounded-full bg-surface flex items-center justify-center">
                <span className="text-3xl">🌿</span>
              </div>
            </div>
            <p className="text-white text-lg font-medium leading-relaxed animate-fade-in max-w-xs">
              {session.steps[step]?.text}
            </p>
            <p className="text-slate-500 text-xs mt-4">
              Step {step + 1} of {totalSteps}
            </p>
          </div>
        )}

        {complete && (
          <div className="text-center animate-slide-up">
            <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">✨</span>
            </div>
            <h2 className="text-2xl font-bold text-white font-display mb-2">Well Done</h2>
            <p className="text-slate-400 text-sm mb-8">
              You took a moment for yourself. That matters.
            </p>
            <button
              onClick={() => setActiveScreen('main')}
              className="px-8 py-3 rounded-xl bg-emerald-500 text-white font-medium text-sm"
            >
              Back to Home
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
