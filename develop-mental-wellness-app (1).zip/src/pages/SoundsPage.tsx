import { useEffect, useMemo, useRef, useState } from 'react';
import { useAppStore } from '../store/appStore';
import { soundTracks } from '../data/content';
import { Heart, Lock, Star, Pause, Play, Timer, Volume2, AlertCircle, Download, CheckCircle2 } from 'lucide-react';

export default function SoundsPage() {
  const {
    playingSound,
    setPlayingSound,
    favoriteSounds,
    toggleFavoriteSound,
    isPremium,
    setActiveScreen,
    soundTimer,
    setSoundTimer,
    downloadedSounds,
    saveDownloadedSound,
  } = useAppStore();

  const [activeCategory, setActiveCategory] = useState('all');
  const [showTimer, setShowTimer] = useState(false);
  const [volume, setVolume] = useState(0.75);
  const [isLoading, setIsLoading] = useState(false);
  const [audioError, setAudioError] = useState('');
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<number | null>(null);

  const categories = [
    { id: 'all', label: 'All', icon: '🎵' },
    { id: 'nature', label: 'Nature', icon: '🌿' },
    { id: 'birds', label: 'Birds', icon: '🐦' },
    { id: 'water', label: 'Water', icon: '💧' },
    { id: 'sleep', label: 'Sleep', icon: '🌙' },
    { id: 'focus', label: 'Focus', icon: '🎯' },
    { id: 'ambient', label: 'Ambient', icon: '🔮' },
    { id: 'music', label: 'Music', icon: '🎹' },
  ];

  const filtered = activeCategory === 'all'
    ? soundTracks
    : soundTracks.filter((t) => t.category === activeCategory);

  const currentTrack = useMemo(
    () => soundTracks.find((track) => track.id === playingSound) ?? null,
    [playingSound]
  );

  const timerOptions = [5, 10, 15, 30, 60];

  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.loop = true;
      audioRef.current.preload = 'auto';
    }

    const audio = audioRef.current;
    audio.volume = volume;

    return () => {
      audio.pause();
      audio.src = '';
      if (timerRef.current) {
        window.clearTimeout(timerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (!currentTrack) {
      audio.pause();
      audio.src = '';
      setIsLoading(false);
      return;
    }

    let cancelled = false;
    setAudioError('');
    setIsLoading(true);

    const playTrack = async () => {
      try {
        const preferredSrc = downloadedSounds[currentTrack.id] || currentTrack.src;
        if (audio.src !== preferredSrc) {
          audio.src = preferredSrc;
        }
        await audio.play();
        if (!cancelled) {
          setIsLoading(false);
        }
      } catch {
        if (!cancelled) {
          setAudioError('Sound could not start. Tap again to retry.');
          setIsLoading(false);
          setPlayingSound(null);
        }
      }
    };

    playTrack();

    return () => {
      cancelled = true;
    };
  }, [currentTrack, setPlayingSound]);

  useEffect(() => {
    if (timerRef.current) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }

    if (playingSound && soundTimer) {
      timerRef.current = window.setTimeout(() => {
        setPlayingSound(null);
        setSoundTimer(null);
      }, soundTimer * 60 * 1000);
    }

    return () => {
      if (timerRef.current) {
        window.clearTimeout(timerRef.current);
      }
    };
  }, [playingSound, soundTimer, setPlayingSound, setSoundTimer]);

  const handleTrackPress = (trackId: string, locked: boolean) => {
    if (locked) {
      setActiveScreen('premium');
      return;
    }

    if (playingSound === trackId) {
      setPlayingSound(null);
      return;
    }

    setPlayingSound(trackId);
  };

  const handleDownload = async (trackId: string, src: string) => {
    if (!isPremium) {
      setActiveScreen('premium');
      return;
    }

    try {
      setAudioError('');
      const response = await fetch(src);
      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          saveDownloadedSound(trackId, reader.result);
        }
      };
      reader.readAsDataURL(blob);
    } catch {
      setAudioError('Download failed. This sound source may block offline saving from the browser.');
    }
  };

  return (
    <div className="pb-24 px-4 pt-[max(1rem,env(safe-area-inset-top))]">
      <div className="pt-4 pb-2 animate-fade-in">
        <h1 className="text-2xl font-bold text-white font-display">Calming Sounds</h1>
        <p className="text-slate-400 text-sm mt-1">Birds, rain, sleep, focus, and nature sounds that actually play</p>
      </div>

      {currentTrack && (
        <div className="mt-4 p-4 rounded-3xl bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/20 animate-fade-in">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((i) => (
                <div
                  key={i}
                  className="w-1 bg-emerald-400 rounded-full animate-pulse"
                  style={{ height: `${12 + i * 3}px`, opacity: 0.55 + i * 0.08 }}
                />
              ))}
            </div>

            <div className="flex-1 min-w-0">
              <p className="text-white font-medium text-sm truncate">{currentTrack.name}</p>
              <p className="text-slate-400 text-xs truncate">
                {isLoading ? 'Starting sound…' : 'Now playing'} {soundTimer ? `• stops in ${soundTimer} min` : ''}
              </p>
            </div>

            <button
              onClick={() => setShowTimer(!showTimer)}
              className="p-2 rounded-lg hover:bg-white/5 transition-colors"
            >
              <Timer size={18} className={soundTimer ? 'text-emerald-400' : 'text-slate-400'} />
            </button>

            <button
              onClick={() => {
                setPlayingSound(null);
                setSoundTimer(null);
              }}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors"
            >
              <Pause size={18} className="text-white" />
            </button>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <Volume2 size={16} className="text-slate-400" />
            <input
              type="range"
              min="0"
              max="1"
              step="0.01"
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              className="w-full accent-emerald-400"
            />
          </div>

          {showTimer && (
            <div className="mt-3 flex gap-2 flex-wrap">
              {timerOptions.map((t) => (
                <button
                  key={t}
                  onClick={() => {
                    setSoundTimer(t);
                    setShowTimer(false);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    soundTimer === t
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-white/5 text-slate-400 border border-white/5'
                  }`}
                >
                  {t}min
                </button>
              ))}
              <button
                onClick={() => {
                  setSoundTimer(null);
                  setShowTimer(false);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-white/5 text-slate-400 border border-white/5"
              >
                Off
              </button>
            </div>
          )}
        </div>
      )}

      {audioError && (
        <div className="mt-4 rounded-2xl border border-rose-500/20 bg-rose-500/10 p-3 flex items-start gap-2 text-sm text-rose-200">
          <AlertCircle size={16} className="mt-0.5" />
          <p>{audioError}</p>
        </div>
      )}

      <div className="flex gap-2 mt-4 overflow-x-auto no-scrollbar animate-fade-in" style={{ animationDelay: '0.1s' }}>
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`flex-shrink-0 px-4 py-2 rounded-xl text-sm font-medium transition-all flex items-center gap-1.5 ${
              activeCategory === cat.id
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-white/5 text-slate-400 border border-white/5 hover:bg-white/10'
            }`}
          >
            <span>{cat.icon}</span>
            {cat.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3 mt-5 animate-fade-in" style={{ animationDelay: '0.15s' }}>
        {filtered.map((track) => {
          const isPlaying = playingSound === track.id;
          const isFav = favoriteSounds.includes(track.id);
          const locked = track.isPremium && !isPremium;
          const isDownloaded = Boolean(downloadedSounds[track.id]);

          return (
            <div
              key={track.id}
              className={`relative p-4 rounded-2xl border transition-all ${
                isPlaying
                  ? 'bg-emerald-500/10 border-emerald-500/30 shadow-lg shadow-emerald-500/5'
                  : 'glass-light border-white/5 hover:border-white/10'
              } ${locked ? 'opacity-70' : 'cursor-pointer active:scale-[0.97]'}`}
              onClick={() => handleTrackPress(track.id, locked)}
            >
              {!locked && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavoriteSound(track.id);
                  }}
                  className="absolute top-3 right-3 p-1"
                >
                  <Heart size={14} className={isFav ? 'text-rose-400 fill-rose-400' : 'text-slate-600'} />
                </button>
              )}

              {locked && (
                <div className="absolute top-3 right-3">
                  <Lock size={14} className="text-amber-400" />
                </div>
              )}

              <div className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3 text-2xl" style={{ backgroundColor: `${track.color}15` }}>
                {track.icon}
              </div>

              <p className="text-white font-medium text-sm">{track.name}</p>
              <p className="text-slate-500 text-[11px] mt-1 leading-relaxed line-clamp-2">{track.description}</p>
              <div className="flex items-center gap-1.5 mt-2">
                <span className="text-[10px] text-slate-500 capitalize">{track.category}</span>
                {track.isPremium && <Star size={10} className="text-amber-400" />}
              </div>

              <div className="mt-3 flex items-center justify-between gap-2">
                <span className="text-xs text-slate-400">{locked ? 'Pro sound' : isDownloaded ? 'Offline ready' : isPlaying ? 'Tap to pause' : 'Tap to play'}</span>
                <div className="flex items-center gap-2">
                  {!locked && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDownload(track.id, track.src);
                      }}
                      className={`w-8 h-8 rounded-full flex items-center justify-center ${isDownloaded ? 'bg-emerald-500/15' : 'bg-white/5'}`}
                      title={isPremium ? 'Download for offline' : 'Pro required for offline download'}
                    >
                      {isDownloaded ? <CheckCircle2 size={15} className="text-emerald-400" /> : <Download size={15} className="text-white" />}
                    </button>
                  )}
                  <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center">
                    {isPlaying ? <Pause size={15} className="text-white" /> : <Play size={15} className="text-white ml-0.5" />}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
