import { useState, useEffect } from 'react';
import { useAppStore } from '../store/appStore';
import { quickSessions, calmingQuotes } from '../data/content';
import { Flame, Clock, Zap, ChevronRight, Heart, AlertTriangle, Star } from 'lucide-react';

export default function HomePage() {
  const {
    totalSessions,
    totalMinutes,
    currentStreak,
    setActiveTab,
    setActiveScreen,
    isPremium,
    isLoggedIn,
    openAuthModal,
    userName,
  } = useAppStore();
  const [dailyQuote, setDailyQuote] = useState(calmingQuotes[0]);

  useEffect(() => {
    const dayOfYear = Math.floor((Date.now() - new Date(new Date().getFullYear(), 0, 0).getTime()) / 86400000);
    setDailyQuote(calmingQuotes[dayOfYear % calmingQuotes.length]);
  }, []);

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    if (hour < 21) return 'Good evening';
    return 'Good night';
  };

  return (
    <div className="pb-24 px-4 pt-[max(1rem,env(safe-area-inset-top))]">
      {/* Header */}
      <div className="pt-4 pb-2 animate-fade-in">
        <p className="text-slate-400 text-sm">{getGreeting()} 🌿</p>
        <h1 className="text-2xl font-bold text-white mt-1 font-display">How are you feeling?</h1>
      </div>

      {!isLoggedIn ? (
        <div className="mt-4 animate-fade-in" style={{ animationDelay: '0.08s' }}>
          <button
            onClick={() => openAuthModal('signin')}
            className="w-full rounded-2xl border border-sky-400/20 bg-gradient-to-r from-sky-500/10 to-cyan-500/10 p-4 text-left transition-all hover:border-sky-400/40"
          >
            <p className="text-sm font-semibold text-white">Sign in to save your data</p>
            <p className="mt-1 text-xs text-slate-400">Save moods, journal entries, streaks, reminders, and Pro status.</p>
          </button>
        </div>
      ) : (
        <div className="mt-4 animate-fade-in" style={{ animationDelay: '0.08s' }}>
          <div className="w-full rounded-2xl border border-emerald-400/15 bg-gradient-to-r from-emerald-500/10 to-teal-500/10 p-4">
            <p className="text-sm font-semibold text-white">Welcome back, {userName || 'friend'} 🌿</p>
            <p className="mt-1 text-xs text-slate-400">Your calm progress is being saved to your account.</p>
          </div>
        </div>
      )}

      {/* Mood Quick Select */}
      <div className="mt-4 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        <button
          onClick={() => setActiveScreen('mood')}
          className="w-full p-4 rounded-2xl bg-gradient-to-r from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 flex items-center justify-between group hover:border-emerald-500/40 transition-all"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
              <Heart size={20} className="text-emerald-400" />
            </div>
            <div className="text-left">
              <p className="text-white font-medium text-sm">Mood Check-In</p>
              <p className="text-slate-400 text-xs">How do you feel right now?</p>
            </div>
          </div>
          <ChevronRight size={18} className="text-slate-500 group-hover:text-emerald-400 transition-colors" />
        </button>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-3 mt-5 animate-fade-in" style={{ animationDelay: '0.15s' }}>
        <div className="glass-light rounded-2xl p-3 text-center">
          <Flame size={18} className="text-orange-400 mx-auto mb-1" />
          <p className="text-lg font-bold text-white">{currentStreak}</p>
          <p className="text-[10px] text-slate-400">Day Streak</p>
        </div>
        <div className="glass-light rounded-2xl p-3 text-center">
          <Zap size={18} className="text-emerald-400 mx-auto mb-1" />
          <p className="text-lg font-bold text-white">{totalSessions}</p>
          <p className="text-[10px] text-slate-400">Sessions</p>
        </div>
        <div className="glass-light rounded-2xl p-3 text-center">
          <Clock size={18} className="text-blue-400 mx-auto mb-1" />
          <p className="text-lg font-bold text-white">{totalMinutes}</p>
          <p className="text-[10px] text-slate-400">Minutes</p>
        </div>
      </div>

      {/* Quick Calm Sessions */}
      <div className="mt-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-white">Quick Calm</h2>
          <span className="text-xs text-slate-400">Tap to start</span>
        </div>

        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 -mx-4 px-4">
          {quickSessions.map((session) => (
            <button
              key={session.id}
              onClick={() => setActiveScreen(`session-${session.id}`)}
              className={`flex-shrink-0 w-36 p-4 rounded-2xl bg-gradient-to-br ${session.color} border border-white/5 hover:border-white/10 transition-all active:scale-[0.97]`}
            >
              <span className="text-2xl block mb-2">{session.icon}</span>
              <p className="text-white font-medium text-sm text-left">{session.name}</p>
              <p className="text-slate-400 text-xs text-left mt-1">{session.duration}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Daily Quote */}
      <div className="mt-6 animate-fade-in" style={{ animationDelay: '0.25s' }}>
        <div className="p-5 rounded-2xl bg-gradient-to-br from-violet-500/10 to-purple-500/10 border border-violet-500/10">
          <div className="flex items-start gap-3">
            <span className="text-2xl">✨</span>
            <div>
              <p className="text-white/90 text-sm leading-relaxed italic">"{dailyQuote.text}"</p>
              <p className="text-slate-400 text-xs mt-2">— {dailyQuote.author}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Actions */}
      <div className="mt-6 animate-fade-in" style={{ animationDelay: '0.3s' }}>
        <h2 className="text-lg font-semibold text-white mb-3">Start Here</h2>
        <div className="space-y-3">
          <button
            onClick={() => setActiveTab('breathe')}
            className="w-full p-4 rounded-2xl bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border border-blue-500/10 flex items-center gap-4 hover:border-blue-500/30 transition-all active:scale-[0.99]"
          >
            <div className="w-12 h-12 rounded-2xl bg-blue-500/20 flex items-center justify-center">
              <span className="text-2xl">🌬️</span>
            </div>
            <div className="text-left flex-1">
              <p className="text-white font-medium">Breathing Coach</p>
              <p className="text-slate-400 text-xs">Guided breathing exercises</p>
            </div>
            <ChevronRight size={18} className="text-slate-500" />
          </button>

          <button
            onClick={() => setActiveTab('sounds')}
            className="w-full p-4 rounded-2xl bg-gradient-to-r from-purple-500/10 to-violet-500/10 border border-purple-500/10 flex items-center gap-4 hover:border-purple-500/30 transition-all active:scale-[0.99]"
          >
            <div className="w-12 h-12 rounded-2xl bg-purple-500/20 flex items-center justify-center">
              <span className="text-2xl">🎵</span>
            </div>
            <div className="text-left flex-1">
              <p className="text-white font-medium">Calming Sounds</p>
              <p className="text-slate-400 text-xs">Nature, ambient & music</p>
            </div>
            <ChevronRight size={18} className="text-slate-500" />
          </button>

          <button
            onClick={() => setActiveScreen('progress')}
            className="w-full p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/10 flex items-center gap-4 hover:border-amber-500/30 transition-all active:scale-[0.99]"
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 flex items-center justify-center">
              <span className="text-2xl">📊</span>
            </div>
            <div className="text-left flex-1">
              <p className="text-white font-medium">Your Progress</p>
              <p className="text-slate-400 text-xs">Streaks, badges & stats</p>
            </div>
            <ChevronRight size={18} className="text-slate-500" />
          </button>
        </div>
      </div>

      {/* Premium Banner */}
      {!isPremium && (
        <div className="mt-6 animate-fade-in" style={{ animationDelay: '0.35s' }}>
          <button
            onClick={() => setActiveScreen('premium')}
            className="w-full p-5 rounded-2xl bg-gradient-to-r from-amber-500/15 to-yellow-500/15 border border-amber-500/20 flex items-center gap-4 hover:border-amber-500/40 transition-all"
          >
            <Star size={24} className="text-amber-400" />
            <div className="text-left flex-1">
              <p className="text-white font-semibold">Unlock MindReset Pro</p>
              <p className="text-slate-400 text-xs">Premium breathing, sounds & more</p>
            </div>
            <ChevronRight size={18} className="text-amber-400" />
          </button>
        </div>
      )}

      {/* Crisis Support Link */}
      <div className="mt-6 mb-4 animate-fade-in" style={{ animationDelay: '0.4s' }}>
        <button
          onClick={() => setActiveScreen('crisis')}
          className="w-full p-3 rounded-xl border border-slate-700/50 flex items-center justify-center gap-2 text-slate-400 text-sm hover:text-white hover:border-slate-600 transition-all"
        >
          <AlertTriangle size={14} />
          Need immediate help? Crisis support resources
        </button>
      </div>
    </div>
  );
}
