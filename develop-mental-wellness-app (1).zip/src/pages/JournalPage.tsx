import { useState } from 'react';
import { useAppStore } from '../store/appStore';
import { Plus, X, Trash2, ChevronDown, ChevronUp, Send } from 'lucide-react';

export default function JournalPage() {
  const { journalEntries, addJournalEntry, deleteJournalEntry } = useAppStore();
  const [showNew, setShowNew] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const handleSubmit = () => {
    if (!content.trim()) return;
    addJournalEntry(title.trim() || 'Untitled', content.trim());
    setTitle('');
    setContent('');
    setShowNew(false);
  };

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="pb-24 px-4 pt-[max(1rem,env(safe-area-inset-top))]">
      <div className="pt-4 pb-2 animate-fade-in flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white font-display">Thought Journal</h1>
          <p className="text-slate-400 text-sm mt-1">Your private space to unload</p>
        </div>
        <button
          onClick={() => setShowNew(true)}
          className="w-10 h-10 rounded-xl bg-emerald-500 flex items-center justify-center hover:bg-emerald-600 transition-colors active:scale-95"
        >
          <Plus size={20} className="text-white" />
        </button>
      </div>

      {/* New Entry Form */}
      {showNew && (
        <div className="mt-4 p-4 rounded-2xl glass-light border border-emerald-500/20 animate-fade-in">
          <div className="flex items-center justify-between mb-3">
            <p className="text-white font-medium text-sm">What's on your mind?</p>
            <button onClick={() => setShowNew(false)} className="p-1 rounded-lg hover:bg-white/5">
              <X size={18} className="text-slate-400" />
            </button>
          </div>
          <input
            type="text"
            placeholder="Title (optional)"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-emerald-500/30 mb-3"
          />
          <textarea
            placeholder="Write freely. This is your private space..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={5}
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm placeholder-slate-500 focus:outline-none focus:border-emerald-500/30 resize-none"
          />
          <div className="flex justify-between items-center mt-3">
            <p className="text-slate-500 text-xs">{content.length} characters</p>
            <button
              onClick={handleSubmit}
              disabled={!content.trim()}
              className="px-5 py-2 rounded-xl bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600 disabled:opacity-30 disabled:cursor-not-allowed transition-all flex items-center gap-2"
            >
              <Send size={14} />
              Save
            </button>
          </div>
        </div>
      )}

      {/* Empty State */}
      {journalEntries.length === 0 && !showNew && (
        <div className="mt-20 text-center animate-fade-in">
          <span className="text-5xl block mb-4">📝</span>
          <h3 className="text-white font-semibold text-lg mb-2">Your journal is empty</h3>
          <p className="text-slate-400 text-sm mb-6">
            Writing down your thoughts can help reduce stress<br />and bring clarity to your mind.
          </p>
          <button
            onClick={() => setShowNew(true)}
            className="px-6 py-3 rounded-xl bg-emerald-500 text-white font-medium text-sm hover:bg-emerald-600 transition-all"
          >
            Write Your First Entry
          </button>
        </div>
      )}

      {/* Entries */}
      <div className="mt-4 space-y-3 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        {journalEntries.map(entry => {
          const isExpanded = expandedId === entry.id;
          return (
            <div
              key={entry.id}
              className="p-4 rounded-2xl glass-light border border-white/5 transition-all"
            >
              <div
                className="flex items-start justify-between cursor-pointer"
                onClick={() => setExpandedId(isExpanded ? null : entry.id)}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-white font-medium text-sm truncate">{entry.title || 'Untitled'}</p>
                  <p className="text-slate-500 text-xs mt-0.5">
                    {formatDate(entry.timestamp)} · {formatTime(entry.timestamp)}
                  </p>
                  {!isExpanded && (
                    <p className="text-slate-400 text-xs mt-2 line-clamp-2">{entry.content}</p>
                  )}
                </div>
                {isExpanded ? (
                  <ChevronUp size={16} className="text-slate-500 flex-shrink-0 mt-1" />
                ) : (
                  <ChevronDown size={16} className="text-slate-500 flex-shrink-0 mt-1" />
                )}
              </div>

              {isExpanded && (
                <div className="mt-3 animate-fade-in">
                  <p className="text-slate-300 text-sm whitespace-pre-wrap leading-relaxed">
                    {entry.content}
                  </p>
                  <div className="mt-3 flex justify-end">
                    {confirmDelete === entry.id ? (
                      <div className="flex gap-2">
                        <button
                          onClick={() => setConfirmDelete(null)}
                          className="px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:bg-white/5"
                        >
                          Cancel
                        </button>
                        <button
                          onClick={() => {
                            deleteJournalEntry(entry.id);
                            setConfirmDelete(null);
                          }}
                          className="px-3 py-1.5 rounded-lg text-xs text-red-400 bg-red-500/10 hover:bg-red-500/20"
                        >
                          Confirm Delete
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setConfirmDelete(entry.id)}
                        className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                      >
                        <Trash2 size={14} className="text-slate-500" />
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
