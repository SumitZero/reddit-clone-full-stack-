import { useEffect, useMemo, useState } from 'react';
import { signOut } from 'firebase/auth';
import { useAppStore } from '../store/appStore';
import { firebaseAuth } from '../lib/firebase';
import { cancelSubscriptionNow, getSubscriptionSnapshot, listTransactions, requestSubscriptionRefund, type TransactionItem } from '../lib/backend';
import { exportTransactionPdf, shareTransactionInvoice } from '../lib/invoice';
import { getReferralLink, getReferralMessage, loadReferralStats, shareReferralLink } from '../lib/referral';
import {
  User, Bell, HelpCircle, Heart, BarChart3,
  ChevronRight, LogIn, LogOut, Star, AlertTriangle, FileText, Info, Moon, ReceiptText, Ban, RotateCcw, ShieldCheck, Download, Share2, Gift, Send, Mail, MessageCircle
} from 'lucide-react';

export default function ProfilePage() {
  const {
    isLoggedIn, userName, userEmail, logout,
    isPremium, setActiveScreen, totalSessions, totalMinutes,
    currentStreak, openAuthModal
  } = useAppStore();

  const [transactions, setTransactions] = useState<TransactionItem[]>([]);
  const [subscription, setSubscription] = useState<Awaited<ReturnType<typeof getSubscriptionSnapshot>>>(null);
  const [billingMessage, setBillingMessage] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [selectedRefundReference, setSelectedRefundReference] = useState<string | null>(null);
  const [referralStats, setReferralStats] = useState({
    referralCode: '',
    totalShares: 0,
    clicks: 0,
    successfulInvites: 0,
  });
  const [showReferralCard, setShowReferralCard] = useState(false);
  const [showReferralModal, setShowReferralModal] = useState(false);

  useEffect(() => {
    if (!isLoggedIn) {
      setTransactions([]);
      setSubscription(null);
      return;
    }

    listTransactions().then(setTransactions).catch(() => undefined);
    getSubscriptionSnapshot().then(setSubscription).catch(() => undefined);
    loadReferralStats(firebaseAuth.currentUser?.uid || null, userEmail || null)
      .then(setReferralStats)
      .catch(() => undefined);
  }, [isLoggedIn, userEmail]);

  const activeTransaction = useMemo(
    () => transactions.find((item) => item.transactionReference === subscription?.transactionReference) ?? transactions[0],
    [transactions, subscription]
  );

  const referralLink = getReferralLink(firebaseAuth.currentUser?.uid || null, userEmail || null);
  const referralMessage = getReferralMessage(firebaseAuth.currentUser?.uid || null, userEmail || null);
  const whatsappShare = `https://wa.me/?text=${encodeURIComponent(referralMessage)}`;
  const telegramShare = `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent('Try MindReset for calm, sleep, and focus.')}`;
  const gmailShare = `mailto:?subject=${encodeURIComponent('Try MindReset')}&body=${encodeURIComponent(referralMessage)}`;

  const menuSections = [
    {
      title: 'Wellness',
      items: [
        { icon: BarChart3, label: 'Progress & Stats', action: () => setActiveScreen('progress'), color: 'text-emerald-400' },
        { icon: Heart, label: 'Favorites', action: () => setActiveScreen('favorites'), color: 'text-rose-400' },
        { icon: Bell, label: 'Reminders', action: () => setActiveScreen('reminders'), color: 'text-blue-400' },
        { icon: Moon, label: 'Mood History', action: () => setActiveScreen('mood-history'), color: 'text-purple-400' },
        {
          icon: Gift,
          label: 'Refer Friends',
          action: async () => {
            setShowReferralCard(true);
            setShowReferralModal(true);
            const shared = await shareReferralLink(firebaseAuth.currentUser?.uid || null, userEmail || null).catch(() => false);
            setBillingMessage(
              shared
                ? 'Share options opened. You can also copy your referral link below.'
                : 'Your referral link is ready. Copy it or share it anywhere you like.'
            );
          },
          color: 'text-emerald-300'
        },
      ]
    },
    {
      title: 'Premium',
      items: [
        { icon: Star, label: isPremium ? 'Pro Member' : 'Upgrade to Pro', action: () => setActiveScreen('premium'), color: 'text-amber-400' },
        { icon: ReceiptText, label: 'Transaction History', action: () => setActiveScreen('transaction-history'), color: 'text-cyan-300' },
      ]
    },
    {
      title: 'Support',
      items: [
        { icon: AlertTriangle, label: 'Crisis Support', action: () => setActiveScreen('crisis'), color: 'text-red-400' },
        { icon: HelpCircle, label: 'Help & FAQ', action: () => setActiveScreen('help'), color: 'text-cyan-400' },
        { icon: FileText, label: 'Privacy Policy', action: () => setActiveScreen('privacy'), color: 'text-slate-400' },
        { icon: FileText, label: 'Terms of Service', action: () => setActiveScreen('terms'), color: 'text-slate-400' },
        { icon: Info, label: 'About MindReset', action: () => setActiveScreen('about'), color: 'text-slate-400' },
      ]
    },
  ];

  return (
    <div className="pb-24 px-4 pt-[max(1rem,env(safe-area-inset-top))]">
      {/* Profile Header */}
      <div className="pt-4 pb-2 animate-fade-in">
        {isLoggedIn ? (
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-2xl font-bold">
              {userName.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">{userName}</h1>
              <p className="text-slate-400 text-sm">{userEmail}</p>
              {isPremium && (
                <span className="inline-flex items-center gap-1 mt-1 px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 text-xs font-medium">
                  <Star size={10} /> Pro Member
                </span>
              )}
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-slate-800 flex items-center justify-center">
              <User size={28} className="text-slate-500" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Guest User</h1>
              <button
                onClick={() => openAuthModal('welcome')}
                className="text-emerald-400 text-sm font-medium mt-1 flex items-center gap-1"
              >
                <LogIn size={14} /> Sign in to save your data
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-3 gap-3 mt-5 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        <div className="glass-light rounded-2xl p-3 text-center">
          <p className="text-lg font-bold text-white">{currentStreak}</p>
          <p className="text-[10px] text-slate-400">Day Streak</p>
        </div>
        <div className="glass-light rounded-2xl p-3 text-center">
          <p className="text-lg font-bold text-white">{totalSessions}</p>
          <p className="text-[10px] text-slate-400">Sessions</p>
        </div>
        <div className="glass-light rounded-2xl p-3 text-center">
          <p className="text-lg font-bold text-white">{totalMinutes}</p>
          <p className="text-[10px] text-slate-400">Minutes</p>
        </div>
      </div>


      {/* Menu Sections */}
      {menuSections.map((section, si) => (
        <div key={section.title} className="mt-6 animate-fade-in" style={{ animationDelay: `${0.15 + si * 0.05}s` }}>
          <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-1">
            {section.title}
          </h3>
          <div className="glass-light rounded-2xl overflow-hidden border border-white/5">
            {section.items.map((item, i) => (
              <button
                key={item.label}
                onClick={item.action}
                className={`w-full flex items-center gap-3 px-4 py-3.5 hover:bg-white/5 transition-colors ${
                  i < section.items.length - 1 ? 'border-b border-white/5' : ''
                }`}
              >
                <item.icon size={18} className={item.color} />
                <span className="text-white text-sm flex-1 text-left">{item.label}</span>
                <ChevronRight size={16} className="text-slate-600" />
              </button>
            ))}
          </div>
        </div>
      ))}

      {isLoggedIn && (
        <div className="mt-6 animate-fade-in space-y-6">
          <div>
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-1">
              Refer Friends
            </h3>
            <div className={`glass-light rounded-2xl border border-white/5 p-4 space-y-3 ${showReferralCard ? '' : 'hidden'}`}>
              <div className="flex items-start gap-3">
                <div className="rounded-2xl bg-emerald-500/10 p-2 text-emerald-300">
                  <Gift size={18} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">Share MindReset with friends</p>
                  <p className="mt-1 text-xs leading-relaxed text-slate-400">
                    Invite friends with your personal link so they can discover calm sessions, breathing resets, sleep sounds, and daily wellness tools.
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-3 text-center">
                  <p className="text-lg font-bold text-white">{referralStats.totalShares}</p>
                  <p className="text-[10px] uppercase tracking-wide text-slate-400">Shares</p>
                </div>
                <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-3 text-center">
                  <p className="text-lg font-bold text-white">{referralStats.clicks}</p>
                  <p className="text-[10px] uppercase tracking-wide text-slate-400">Clicks</p>
                </div>
                <div className="rounded-2xl border border-white/8 bg-white/5 px-3 py-3 text-center">
                  <p className="text-lg font-bold text-white">{referralStats.successfulInvites}</p>
                  <p className="text-[10px] uppercase tracking-wide text-slate-400">Invites</p>
                </div>
              </div>
              <div className="rounded-2xl border border-white/8 bg-white/5 px-4 py-3 text-xs text-slate-300 break-all">
                <div className="mb-1 text-[10px] uppercase tracking-[0.2em] text-slate-500">Referral ID</div>
                <div className="font-medium text-white">{referralStats.referralCode}</div>
                <div className="mt-2 break-all">{referralLink}</div>
              </div>
              <div className="rounded-2xl border border-white/8 bg-white/5 px-4 py-3 text-[11px] leading-relaxed text-slate-400">
                {referralMessage}
              </div>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
                <a href={whatsappShare} target="_blank" rel="noreferrer" className="rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white inline-flex items-center justify-center gap-2">
                  <MessageCircle size={15} /> WhatsApp
                </a>
                <a href={telegramShare} target="_blank" rel="noreferrer" className="rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white inline-flex items-center justify-center gap-2">
                  <Send size={15} /> Telegram
                </a>
                <a href={gmailShare} className="rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white inline-flex items-center justify-center gap-2">
                  <Mail size={15} /> Gmail
                </a>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={async () => {
                    await navigator.clipboard.writeText(referralLink).catch(() => undefined);
                    setBillingMessage('Referral link copied. Share it with your friends.');
                  }}
                  className="flex-1 rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white"
                >
                  Copy link
                </button>
                <button
                  onClick={async () => {
                    const shared = await shareReferralLink(null, userEmail || null).catch(() => false);
                    setBillingMessage(shared ? 'Referral sheet opened.' : 'Referral message copied to clipboard.');
                  }}
                  className="flex-1 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 py-3 text-sm font-semibold text-white inline-flex items-center justify-center gap-2"
                >
                  <Share2 size={15} /> Share now
                </button>
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-1">
              Billing Management
            </h3>
            <div className="glass-light rounded-2xl border border-white/5 p-4 space-y-4">
              <div className="rounded-2xl border border-white/8 bg-white/5 p-4">
                <div className="flex items-start gap-3">
                  <div className="rounded-2xl bg-emerald-500/10 p-2 text-emerald-300">
                    <ShieldCheck size={18} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white">
                      {subscription?.status === 'active' || subscription?.status === 'cancelled' ? 'Subscription management' : 'No active subscription'}
                    </p>
                    <p className="mt-1 text-xs leading-relaxed text-slate-400">
                      {subscription?.status === 'active' || subscription?.status === 'cancelled'
                        ? `Provider: ${subscription.provider || '—'} • Plan: ${subscription.plan} • Access continues until ${subscription.expiryDate ? new Date(subscription.expiryDate).toLocaleDateString() : 'lifetime'}.`
                        : 'Choose PayPal or Razorpay from the Pro Member page. Pro unlocks only after successful verification.'}
                    </p>
                    {(subscription?.status === 'active' || subscription?.status === 'cancelled') && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        <button
                          onClick={async () => {
                            const result = await cancelSubscriptionNow().catch(() => null);
                            if (!result) {
                              setBillingMessage('Unable to cancel right now.');
                              return;
                            }
                            setBillingMessage(`Cancellation scheduled. Your Pro access stays active until ${result.expiryDate ? new Date(result.expiryDate).toLocaleDateString() : 'the current period end'}.`);
                            setSubscription((prev) => prev ? ({ ...prev, cancelAtPeriodEnd: true, status: 'cancelled', expiryDate: result.expiryDate ?? prev.expiryDate, refundPolicy: result.refundPolicy ?? prev.refundPolicy }) : prev);
                            const refreshed = await listTransactions().catch(() => []);
                            setTransactions(refreshed);
                          }}
                          className="inline-flex items-center gap-2 rounded-xl border border-amber-400/20 bg-amber-400/10 px-3 py-2 text-xs font-medium text-amber-200"
                        >
                          <Ban size={14} /> Cancel at period end
                        </button>
                        <button
                          onClick={() => activeTransaction && setSelectedRefundReference(activeTransaction.transactionReference)}
                          className="inline-flex items-center gap-2 rounded-xl border border-cyan-400/20 bg-cyan-400/10 px-3 py-2 text-xs font-medium text-cyan-200"
                        >
                          <RotateCcw size={14} /> Request refund
                        </button>
                      </div>
                    )}
                    {subscription?.cancelAtPeriodEnd && (
                      <p className="mt-3 text-xs text-amber-300">
                        Renewal is cancelled. Your Pro benefits remain active until the billing period ends.
                      </p>
                    )}
                    {subscription?.refundPolicy && (
                      <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
                        Refund policy: {subscription.refundPolicy}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              {selectedRefundReference && (
                <div className="rounded-2xl border border-cyan-400/15 bg-cyan-400/5 p-4 space-y-3">
                  <div className="flex items-center gap-2 text-cyan-200 text-sm font-semibold">
                    <RotateCcw size={16} /> Refund request
                  </div>
                  <textarea
                    value={refundReason}
                    onChange={(e) => setRefundReason(e.target.value)}
                    rows={3}
                    placeholder="Tell us why you want a refund"
                    className="w-full rounded-2xl border border-white/10 bg-slate-900/70 px-3 py-3 text-sm text-white outline-none placeholder:text-slate-500"
                  />
                  <div className="flex gap-3">
                    <button
                      onClick={() => {
                        setSelectedRefundReference(null);
                        setRefundReason('');
                      }}
                      className="flex-1 rounded-2xl border border-white/10 py-3 text-sm text-slate-300"
                    >
                      Not now
                    </button>
                    <button
                      onClick={async () => {
                        if (!refundReason.trim()) {
                          setBillingMessage('Please enter a reason for the refund request.');
                          return;
                        }
                        const response = await requestSubscriptionRefund({
                          reference: selectedRefundReference,
                          reason: refundReason,
                        }).catch(() => null);
                        if (!response) {
                          setBillingMessage('Unable to submit refund request right now.');
                          return;
                        }
                        setBillingMessage(response.message);
                        setSelectedRefundReference(null);
                        setRefundReason('');
                        const refreshed = await listTransactions().catch(() => []);
                        setTransactions(refreshed);
                      }}
                      className="flex-1 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 py-3 text-sm font-semibold text-white"
                    >
                      Submit refund request
                    </button>
                  </div>
                </div>
              )}

              {billingMessage && (
                <div className="rounded-2xl border border-white/8 bg-white/5 px-4 py-3 text-xs leading-relaxed text-slate-300">
                  {billingMessage}
                </div>
              )}
            </div>
          </div>

          <div>
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2 px-1">
              Transaction History
            </h3>
            <div className="glass-light rounded-2xl border border-white/5 p-4">
              <button
                onClick={() => setActiveScreen('transaction-history')}
                className="mb-3 flex w-full items-center justify-between rounded-2xl border border-white/8 bg-white/5 px-4 py-3 text-left"
              >
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <ReceiptText size={16} className="text-cyan-300" />
                  <span>Open full transaction history</span>
                </div>
                <ChevronRight size={16} className="text-slate-500" />
              </button>
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                <ReceiptText size={16} className="text-cyan-300" /> Pro member payments
              </div>
              {transactions.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-white/10 px-4 py-6 text-center text-xs text-slate-500">
                  No transactions yet. After you subscribe with PayPal or Razorpay, your billing history will appear here.
                </div>
              ) : (
                <div className="space-y-3">
                  {transactions.map((item) => (
                    <div key={item.id} className="rounded-2xl border border-white/8 bg-white/5 p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="text-sm font-semibold text-white">{item.plan} • {item.amountLabel}</p>
                          <p className="mt-1 text-xs text-slate-400">
                            {item.provider} • {item.transactionReference}
                          </p>
                        </div>
                        <span className={`rounded-full px-2.5 py-1 text-[11px] font-medium ${
                          item.status === 'active'
                            ? 'bg-emerald-500/15 text-emerald-300'
                            : item.status === 'cancelled'
                              ? 'bg-amber-500/15 text-amber-300'
                              : item.status === 'failed'
                                ? 'bg-rose-500/15 text-rose-300'
                                : 'bg-slate-700/60 text-slate-300'
                        }`}>
                          {item.status}
                        </span>
                      </div>
                      <div className="mt-3 grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                        <p>Purchased: {item.purchaseDate ? new Date(item.purchaseDate).toLocaleDateString() : item.createdAt ? new Date(item.createdAt).toLocaleDateString() : '—'}</p>
                        <p>Access until: {item.expiryDate ? new Date(item.expiryDate).toLocaleDateString() : 'Lifetime / pending'}</p>
                        <p>Cancellation: {item.cancellationScheduled ? 'Scheduled' : 'Active renewal'}</p>
                        <p>Refund: {item.refundStatus || 'none'}</p>
                      </div>
                      <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
                        Refunds, when approved, are sent back to the original PayPal or Razorpay payment method after provider review and billing validation.
                      </p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <button
                          onClick={() => exportTransactionPdf(item, userEmail)}
                          className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-white inline-flex items-center gap-2"
                        >
                          <Download size={14} /> Invoice / receipt
                        </button>
                        <button
                          onClick={() => shareTransactionInvoice(item, userEmail)}
                          className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-white inline-flex items-center gap-2"
                        >
                          <Share2 size={14} /> Share invoice
                        </button>
                        {(item.status === 'active' || item.status === 'cancelled') && item.refundStatus !== 'requested' && item.refundStatus !== 'processing' && (
                          <button
                            onClick={() => {
                              setSelectedRefundReference(item.transactionReference);
                              setRefundReason('');
                            }}
                            className="rounded-xl border border-cyan-400/20 bg-cyan-400/10 px-3 py-2 text-xs font-medium text-cyan-200"
                          >
                            Request refund for this payment
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Logout */}
      {isLoggedIn && (
        <button
          onClick={async () => {
            await signOut(firebaseAuth).catch(() => undefined);
            logout();
          }}
          className="w-full mt-6 py-3 rounded-2xl border border-red-500/20 text-red-400 text-sm font-medium flex items-center justify-center gap-2 hover:bg-red-500/5 transition-all animate-fade-in"
        >
          <LogOut size={16} />
          Sign Out
        </button>
      )}

      {showReferralModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 backdrop-blur-sm px-4" onClick={() => setShowReferralModal(false)}>
          <div
            className="w-full max-w-md rounded-t-3xl sm:rounded-3xl border border-white/10 bg-slate-900 p-5 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-4 h-1.5 w-14 rounded-full bg-white/10 sm:hidden" />
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-500/10 px-3 py-1 text-xs font-medium text-emerald-300">
                  <Gift size={14} /> Refer Friends
                </p>
                <h3 className="mt-3 text-2xl font-bold text-white">Share MindReset</h3>
                <p className="mt-2 text-sm leading-relaxed text-slate-400">
                  Share your personal app link with friends or on social media so more people can discover calm sessions, breathing resets, and wellness support.
                </p>
              </div>
              <button
                onClick={() => setShowReferralModal(false)}
                className="rounded-full border border-white/10 bg-white/5 p-3 text-slate-300"
              >
                <ChevronRight size={18} className="rotate-45" />
              </button>
            </div>

            <div className="mt-4 rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
              <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500">Your link</div>
              <div className="mt-2 break-all text-sm text-white">{referralLink}</div>
            </div>

            <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
              <a href={whatsappShare} target="_blank" rel="noreferrer" className="rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white inline-flex items-center justify-center gap-2">
                <MessageCircle size={15} /> WhatsApp
              </a>
              <a href={telegramShare} target="_blank" rel="noreferrer" className="rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white inline-flex items-center justify-center gap-2">
                <Send size={15} /> Telegram
              </a>
              <a href={gmailShare} className="rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white inline-flex items-center justify-center gap-2">
                <Mail size={15} /> Gmail
              </a>
            </div>

            <div className="mt-4 flex gap-3">
              <button
                onClick={async () => {
                  await navigator.clipboard.writeText(referralLink).catch(() => undefined);
                  setBillingMessage('Referral link copied. Share it anywhere you want.');
                }}
                className="flex-1 rounded-2xl border border-white/10 bg-white/5 py-3 text-sm font-medium text-white"
              >
                Copy link
              </button>
              <button
                onClick={async () => {
                  const shared = await shareReferralLink(firebaseAuth.currentUser?.uid || null, userEmail || null).catch(() => false);
                  setBillingMessage(shared ? 'Share options opened.' : 'Referral link is ready to copy and share.');
                }}
                className="flex-1 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 py-3 text-sm font-semibold text-white inline-flex items-center justify-center gap-2"
              >
                <Share2 size={15} /> Share now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Version */}
      <p className="text-center text-slate-600 text-xs mt-6 mb-4">
        MindReset v1.0.0
      </p>
    </div>
  );
}
