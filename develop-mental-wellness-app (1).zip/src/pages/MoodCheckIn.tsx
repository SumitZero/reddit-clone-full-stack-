import { useState } from 'react';
import { useAppStore, type MoodType } from '../store/appStore';
import { moodSuggestions } from '../data/content';
import { ArrowLeft, ChevronRight } from 'lucide-react';

const moods: { type: MoodType; emoji: string; label: string; color: string }[] = [
  { type: 'stressed', emoji: '😫', label: 'Stressed', color: 'from-red-500/20 to-orange-500/20 border-red-500/20' },
  { type: 'tired', emoji: '😴', label: 'Tired', color: 'from-indigo-500/20 to-blue-500/20 border-indigo-500/20' },
  { type: 'anxious', emoji: '😰', label: 'Anxious', color: 'from-yellow-500/20 to-amber-500/20 border-yellow-500/20' },
  { type: 'overwhelmed', emoji: '🤯', label: 'Overwhelmed', color: 'from-purple-500/20 to-violet-500/20 border-purple-500/20' },
  { type: 'distracted', emoji: '🤔', label: 'Distracted', color: 'from-cyan-500/20 to-sky-500/20 border-cyan-500/20' },
  { type: 'okay', emoji: '😐', label: 'Okay', color: 'from-slate-500/20 to-gray-500/20 border-slate-500/20' },
  { type: 'calm', emoji: '😌', label: 'Calm', color: 'from-emerald-500/20 to-teal-500/20 border-emerald-500/20' },
];

export default function MoodCheckIn() {
  const { setActiveScreen, addMoodEntry } = useAppStore();
  const [selected, setSelected] = useState<MoodType | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleSelect = (mood: MoodType) => {
    setSelected(mood);
    addMoodEntry(mood);
    setTimeout(() => setShowResult(true), 300);
  };

  const suggestion = selected ? moodSuggestions[selected] : null;

  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button
            onClick={() => setActiveScreen('main')}
            className="p-2 rounded-xl hover:bg-white/5 transition-colors"
          >
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Mood Check-In</h1>
        </div>

        {!showResult ? (
          <div className="animate-fade-in">
            <p className="text-slate-400 text-sm mb-6 px-2">
              How are you feeling right now? Be honest — there are no wrong answers.
            </p>

            <div className="grid grid-cols-2 gap-3">
              {moods.map(mood => (
                <button
                  key={mood.type}
                  onClick={() => handleSelect(mood.type)}
                  className={`p-4 rounded-2xl bg-gradient-to-br ${mood.color} border flex items-center gap-3 hover:scale-[1.02] transition-all active:scale-[0.98] ${
                    selected === mood.type ? 'ring-2 ring-emerald-400' : ''
                  }`}
                >
                  <span className="text-2xl">{mood.emoji}</span>
                  <span className="text-white font-medium text-sm">{mood.label}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="animate-slide-up mt-8">
            {/* Selected mood */}
            <div className="text-center mb-8">
              <span className="text-5xl block mb-3">
                {moods.find(m => m.type === selected)?.emoji}
              </span>
              <p className="text-white font-medium text-lg">
                Feeling {moods.find(m => m.type === selected)?.label}
              </p>
            </div>

            {/* Suggestion */}
            {suggestion && (
              <div className="p-5 rounded-2xl glass-light border border-emerald-500/20">
                <p className="text-white/90 text-sm leading-relaxed mb-3">
                  {suggestion.message}
                </p>
                <p className="text-slate-400 text-sm leading-relaxed mb-4">
                  {suggestion.suggestion}
                </p>
                <button
                  onClick={() => {
                    setActiveScreen(`breathing-active-${suggestion.breathingId}`);
                  }}
                  className="w-full py-3 rounded-xl bg-emerald-500/20 text-emerald-400 font-medium text-sm flex items-center justify-center gap-2 hover:bg-emerald-500/30 transition-all"
                >
                  Start Suggested Exercise
                  <ChevronRight size={16} />
                </button>
              </div>
            )}

            {/* Back */}
            <button
              onClick={() => setActiveScreen('main')}
              className="w-full mt-4 py-3 rounded-xl border border-slate-700/50 text-slate-400 text-sm hover:bg-white/5 transition-all"
            >
              Back to Home
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
