import { useAppStore } from '../store/appStore';
import { breathingPatterns } from '../data/content';
import { Heart } from 'lucide-react';

export default function BreathePage() {
  const { setActiveScreen, favoriteBreathing, toggleFavoriteBreathing } = useAppStore();



  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'calm': return 'from-blue-500/20 to-cyan-500/20 border-blue-500/20';
      case 'stress': return 'from-red-500/20 to-orange-500/20 border-red-500/20';
      case 'focus': return 'from-amber-500/20 to-yellow-500/20 border-amber-500/20';
      case 'sleep': return 'from-indigo-500/20 to-purple-500/20 border-indigo-500/20';
      default: return 'from-emerald-500/20 to-teal-500/20 border-emerald-500/20';
    }
  };

  return (
    <div className="pb-24 px-4 pt-[max(1rem,env(safe-area-inset-top))]">
      <div className="pt-4 pb-2 animate-fade-in">
        <h1 className="text-2xl font-bold text-white font-display">Breathing Coach</h1>
        <p className="text-slate-400 text-sm mt-1">Choose a pattern, set your own timer, and finish with a calming tone</p>
      </div>

      {/* Quick Start */}
      <button
        onClick={() => setActiveScreen('breathing-active-box-breathing')}
        className="w-full mt-4 p-5 rounded-2xl bg-gradient-to-r from-emerald-500/15 to-teal-500/15 border border-emerald-500/20 flex items-center gap-4 hover:border-emerald-500/40 transition-all animate-fade-in active:scale-[0.99]"
      >
        <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 flex items-center justify-center">
          <span className="text-3xl">🌬️</span>
        </div>
        <div className="text-left flex-1">
          <p className="text-white font-semibold text-lg">Start Breathing</p>
          <p className="text-slate-400 text-sm">Quick 1-minute box breathing</p>
        </div>
        <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center">
          <span className="text-white text-lg">▶</span>
        </div>
      </button>

      {/* Patterns List */}
      <div className="mt-6 animate-fade-in" style={{ animationDelay: '0.15s' }}>
        <h2 className="text-lg font-semibold text-white mb-3">All Patterns</h2>
        <div className="space-y-3">
          {breathingPatterns.map((pattern) => {
            const isFav = favoriteBreathing.includes(pattern.id);
            const totalTime = (pattern.inhale + pattern.hold + pattern.exhale + (pattern.holdAfter || 0)) * pattern.rounds;

            return (
              <div
                key={pattern.id}
                className={`p-4 rounded-2xl bg-gradient-to-r ${getCategoryColor(pattern.category)} border flex items-center gap-4 transition-all hover:scale-[1.01] cursor-pointer active:scale-[0.99]`}
                onClick={() => setActiveScreen(`breathing-active-${pattern.id}`)}
              >
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center text-2xl">
                  {pattern.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-white font-medium text-sm">{pattern.name}</p>
                  </div>
                  <p className="text-slate-400 text-xs mt-0.5 line-clamp-1">{pattern.description}</p>
                  <div className="flex items-center gap-3 mt-1.5">
                    <span className="text-[10px] text-slate-500">{pattern.inhale}-{pattern.hold}-{pattern.exhale}{pattern.holdAfter ? `-${pattern.holdAfter}` : ''}</span>
                    <span className="text-[10px] text-slate-500">{pattern.rounds} rounds</span>
                    <span className="text-[10px] text-slate-500">~{Math.ceil(totalTime / 60)}min</span>
                  </div>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavoriteBreathing(pattern.id);
                  }}
                  className="p-2 rounded-lg hover:bg-white/5 transition-colors"
                >
                  <Heart
                    size={18}
                    className={isFav ? 'text-rose-400 fill-rose-400' : 'text-slate-600'}
                  />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
