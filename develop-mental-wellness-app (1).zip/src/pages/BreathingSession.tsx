import { useState, useEffect, useRef, useCallback } from 'react';
import { useAppStore } from '../store/appStore';
import { breathingPatterns, soundTracks } from '../data/content';
import { Crown, RotateCcw, Upload, X } from 'lucide-react';

type Phase = 'inhale' | 'hold' | 'exhale' | 'holdAfter' | 'complete';

interface BreathingSessionProps {
  patternId: string;
}

export default function BreathingSession({ patternId }: BreathingSessionProps) {
  const {
    setActiveScreen,
    addSession,
    isPremium,
    downloadedSounds,
    setPlayingSound,
  } = useAppStore();
  const pattern = breathingPatterns.find(p => p.id === patternId);

  const [phase, setPhase] = useState<Phase>('inhale');
  const [currentRound, setCurrentRound] = useState(1);
  const [countdown, setCountdown] = useState(0);
  const [isActive, setIsActive] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [totalElapsed, setTotalElapsed] = useState(0);
  const [customMinutes, setCustomMinutes] = useState('2');
  const [useCustomTimer, setUseCustomTimer] = useState(false);
  const [playEndTone, setPlayEndTone] = useState(true);
  const [endToneSource, setEndToneSource] = useState<'default' | 'library' | 'downloaded' | 'url' | 'file'>('default');
  const [selectedSoundId, setSelectedSoundId] = useState(soundTracks[0]?.id || 'rain');
  const [customToneUrl, setCustomToneUrl] = useState('');
  const [customToneFileName, setCustomToneFileName] = useState('');
  const [customToneFileData, setCustomToneFileData] = useState('');
  const [sessionNotice, setSessionNotice] = useState('');
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const endToneAudioRef = useRef<HTMLAudioElement | null>(null);

  if (!pattern) return null;

  const getPhaseTime = useCallback((p: Phase) => {
    switch (p) {
      case 'inhale': return pattern.inhale;
      case 'hold': return pattern.hold;
      case 'exhale': return pattern.exhale;
      case 'holdAfter': return pattern.holdAfter || 0;
      default: return 0;
    }
  }, [pattern]);

  const cycleSeconds = pattern.inhale + pattern.hold + pattern.exhale + (pattern.holdAfter || 0);
  const baseTotalTime = cycleSeconds * pattern.rounds;
  const customTotalSeconds = Math.max(1, Number(customMinutes || '0')) * 60;
  const effectiveTotalTime = useCustomTimer ? customTotalSeconds : baseTotalTime;
  const effectiveRounds = Math.max(1, Math.ceil(effectiveTotalTime / Math.max(1, cycleSeconds)));
  const downloadedTrackEntries = Object.entries(downloadedSounds);

  const resolveEndToneSrc = useCallback(() => {
    if (endToneSource === 'default') return 'https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3';
    if (endToneSource === 'library') {
      return soundTracks.find((track) => track.id === selectedSoundId)?.src || '';
    }
    if (endToneSource === 'downloaded') {
      const firstDownloaded = downloadedSounds[selectedSoundId] || downloadedTrackEntries[0]?.[1] || '';
      return firstDownloaded;
    }
    if (endToneSource === 'url') return customToneUrl.trim();
    if (endToneSource === 'file') return customToneFileData;
    return '';
  }, [endToneSource, selectedSoundId, downloadedSounds, downloadedTrackEntries, customToneUrl, customToneFileData]);

  const playCompletionTone = useCallback(async () => {
    if (!playEndTone) return;
    const src = resolveEndToneSrc();
    if (!src) {
      setSessionNotice('Finish tone could not play. Please choose a valid sound source.');
      return;
    }

    try {
      if (endToneAudioRef.current) {
        endToneAudioRef.current.pause();
      }
      const audio = new Audio(src);
      audio.volume = 0.9;
      endToneAudioRef.current = audio;
      setPlayingSound('breathing-end-tone');
      await audio.play();
      window.setTimeout(() => {
        audio.pause();
        audio.currentTime = 0;
        setPlayingSound(null);
      }, 4500);
    } catch {
      setSessionNotice('Your browser blocked the finish tone. Tap start first, then try again.');
      setPlayingSound(null);
    }
  }, [playEndTone, resolveEndToneSrc, setPlayingSound]);

  const getNextPhase = useCallback((current: Phase, round: number): { phase: Phase; round: number } => {
    switch (current) {
      case 'inhale': return { phase: 'hold', round };
      case 'hold': return { phase: 'exhale', round };
      case 'exhale':
        if (pattern.holdAfter && pattern.holdAfter > 0) return { phase: 'holdAfter', round };
        if (round >= pattern.rounds) return { phase: 'complete', round };
        return { phase: 'inhale', round: round + 1 };
      case 'holdAfter':
        if (round >= pattern.rounds) return { phase: 'complete', round };
        return { phase: 'inhale', round: round + 1 };
      default: return { phase: 'complete', round };
    }
  }, [pattern]);

  const startSession = useCallback(() => {
    setIsActive(true);
    setPhase('inhale');
    setCurrentRound(1);
    setCountdown(pattern.inhale);
    setIsComplete(false);
    setTotalElapsed(0);
    setSessionNotice('');
  }, [pattern]);

  useEffect(() => {
    if (!isActive || isComplete) return;

    timerRef.current = setInterval(() => {
      setCountdown(prev => {
        const nextElapsed = totalElapsed + 1;
        if (nextElapsed >= effectiveTotalTime) {
          setIsComplete(true);
          setIsActive(false);
          addSession(Math.max(1, Math.ceil(effectiveTotalTime / 60)));
          void playCompletionTone();
          return 0;
        }

        if (prev <= 1) {
          const next = getNextPhase(phase, currentRound);
          if (next.phase === 'complete') {
            setIsComplete(true);
            setIsActive(false);
            addSession(Math.max(1, Math.ceil(effectiveTotalTime / 60)));
            void playCompletionTone();
            return 0;
          }
          setPhase(next.phase);
          setCurrentRound(next.round > effectiveRounds ? effectiveRounds : next.round);
          return getPhaseTime(next.phase);
        }
        return prev - 1;
      });
      setTotalElapsed(prev => prev + 1);
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, isComplete, phase, currentRound, getNextPhase, getPhaseTime, addSession, totalElapsed, effectiveTotalTime, effectiveRounds, playCompletionTone]);

  const getPhaseLabel = () => {
    switch (phase) {
      case 'inhale': return 'Breathe In';
      case 'hold': return 'Hold';
      case 'exhale': return 'Breathe Out';
      case 'holdAfter': return 'Hold';
      default: return '';
    }
  };

  const getPhaseColor = () => {
    switch (phase) {
      case 'inhale': return 'text-emerald-400';
      case 'hold': return 'text-amber-400';
      case 'exhale': return 'text-blue-400';
      case 'holdAfter': return 'text-purple-400';
      default: return 'text-white';
    }
  };

  const getCircleScale = () => {
    const phaseTime = getPhaseTime(phase);
    const progress = phaseTime > 0 ? (phaseTime - countdown) / phaseTime : 0;
    switch (phase) {
      case 'inhale': return 0.5 + progress * 0.5;
      case 'hold': return 1;
      case 'exhale': return 1 - progress * 0.5;
      case 'holdAfter': return 0.5;
      default: return 0.7;
    }
  };

  const getGlowColor = () => {
    switch (phase) {
      case 'inhale': return 'rgba(52, 211, 153, 0.3)';
      case 'hold': return 'rgba(251, 191, 36, 0.3)';
      case 'exhale': return 'rgba(96, 165, 250, 0.3)';
      case 'holdAfter': return 'rgba(192, 132, 252, 0.3)';
      default: return 'rgba(52, 211, 153, 0.2)';
    }
  };

  const totalTime = effectiveTotalTime;
  const progress = totalTime > 0 ? (totalElapsed / totalTime) * 100 : 0;
  const timeLeft = Math.max(0, effectiveTotalTime - totalElapsed);
  const minutesLeft = Math.floor(timeLeft / 60);
  const secondsLeft = timeLeft % 60;

  return (
    <div className="fixed inset-0 bg-surface z-50 flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-2">
        <button
          onClick={() => setActiveScreen('main')}
          className="p-2 rounded-xl hover:bg-white/5 transition-colors"
        >
          <X size={24} className="text-slate-400" />
        </button>
        <div className="text-center">
          <p className="text-white font-medium text-sm">{pattern.name}</p>
          <p className="text-slate-500 text-xs">Round {currentRound} of {pattern.rounds}</p>
        </div>
        <button
          onClick={startSession}
          className="p-2 rounded-xl hover:bg-white/5 transition-colors"
        >
          <RotateCcw size={20} className="text-slate-400" />
        </button>
      </div>

      {/* Progress bar */}
      <div className="px-4 mt-2">
        <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-emerald-500 rounded-full transition-all duration-1000 ease-linear"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Main breathing area */}
      <div className="flex-1 overflow-y-auto overscroll-contain pb-[calc(7rem+env(safe-area-inset-bottom))]">
        {!isActive && !isComplete && (
          <div className="text-center animate-fade-in w-full px-4 max-w-md mx-auto pt-6">
            <p className="text-slate-400 text-sm mb-2">{pattern.description}</p>
            <p className="text-slate-500 text-xs mb-5">
              Pattern: {pattern.inhale}-{pattern.hold}-{pattern.exhale}{pattern.holdAfter ? `-${pattern.holdAfter}` : ''} × {pattern.rounds} rounds
            </p>

            <div className="rounded-3xl border border-white/10 bg-white/5 p-4 text-left mb-6">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-white text-sm font-semibold">Custom session timer</p>
                    <span className="inline-flex items-center gap-1 rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-medium text-amber-200">
                      <Crown size={10} /> Pro
                    </span>
                  </div>
                  <p className="text-slate-400 text-xs">All breathing exercises are free. Custom timer and finish tone are Pro features.</p>
                </div>
                <button
                  onClick={() => isPremium ? setUseCustomTimer(!useCustomTimer) : setActiveScreen('premium')}
                  className={`w-14 h-8 rounded-full transition-all ${useCustomTimer ? 'bg-emerald-500' : 'bg-slate-700'}`}
                >
                  <div className={`w-6 h-6 bg-white rounded-full transition-transform ${useCustomTimer ? 'translate-x-7' : 'translate-x-1'}`} />
                </button>
              </div>

              <div className={`mt-4 ${!isPremium ? 'opacity-55' : ''}`}>
                <p className="text-slate-400 text-xs mb-2">Duration</p>
                <div className="grid grid-cols-4 gap-2 mb-3">
                  {['1', '2', '3', '5'].map((minute) => (
                    <button
                      key={minute}
                      disabled={!isPremium}
                      onClick={() => { setCustomMinutes(minute); setUseCustomTimer(true); }}
                      className={`py-2 rounded-xl text-sm font-medium transition-all ${customMinutes === minute ? 'bg-emerald-500 text-white' : 'bg-white/5 text-slate-300'} ${!isPremium ? 'cursor-not-allowed' : ''}`}
                    >
                      {minute}m
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  min="1"
                  max="60"
                  disabled={!isPremium}
                  value={customMinutes}
                  onChange={(e) => setCustomMinutes(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-emerald-500/30 disabled:opacity-60"
                  placeholder="Custom minutes"
                />
              </div>

              <div className={`mt-4 rounded-2xl border border-white/10 bg-slate-950/40 p-3 ${!isPremium ? 'opacity-55' : ''}`}>
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-white text-sm font-semibold">Play finish tone</p>
                    <p className="text-slate-400 text-xs">Optional short tone when your breathing time ends.</p>
                  </div>
                  <button
                    onClick={() => isPremium ? setPlayEndTone(!playEndTone) : setActiveScreen('premium')}
                    className={`w-14 h-8 rounded-full transition-all ${playEndTone ? 'bg-cyan-500' : 'bg-slate-700'}`}
                  >
                    <div className={`w-6 h-6 bg-white rounded-full transition-transform ${playEndTone ? 'translate-x-7' : 'translate-x-1'}`} />
                  </button>
                </div>

                {playEndTone && isPremium && (
                  <div className="mt-4 space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <button onClick={() => setEndToneSource('default')} className={`px-3 py-2 rounded-xl text-xs font-medium ${endToneSource === 'default' ? 'bg-cyan-500 text-white' : 'bg-white/5 text-slate-300'}`}>Default tone</button>
                      <button onClick={() => setEndToneSource('library')} className={`px-3 py-2 rounded-xl text-xs font-medium ${endToneSource === 'library' ? 'bg-cyan-500 text-white' : 'bg-white/5 text-slate-300'}`}>From sounds</button>
                      <button onClick={() => setEndToneSource('downloaded')} className={`px-3 py-2 rounded-xl text-xs font-medium ${endToneSource === 'downloaded' ? 'bg-cyan-500 text-white' : 'bg-white/5 text-slate-300'}`}>Downloaded</button>
                      <button onClick={() => setEndToneSource('url')} className={`px-3 py-2 rounded-xl text-xs font-medium ${endToneSource === 'url' ? 'bg-cyan-500 text-white' : 'bg-white/5 text-slate-300'}`}>Music URL</button>
                    </div>
                    <button onClick={() => setEndToneSource('file')} className={`w-full px-3 py-2 rounded-xl text-xs font-medium border ${endToneSource === 'file' ? 'bg-cyan-500/20 border-cyan-400/40 text-cyan-200' : 'border-white/10 text-slate-300'}`}>
                      <span className="inline-flex items-center gap-2"><Upload size={14} /> Gallery file</span>
                    </button>

                    {(endToneSource === 'library' || endToneSource === 'downloaded') && (
                      <select
                        value={selectedSoundId}
                        onChange={(e) => setSelectedSoundId(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none"
                      >
                        {(endToneSource === 'library' ? soundTracks : soundTracks.filter((track) => downloadedSounds[track.id])).map((track) => (
                          <option key={track.id} value={track.id}>{track.name}</option>
                        ))}
                      </select>
                    )}

                    {endToneSource === 'url' && (
                      <input
                        type="url"
                        value={customToneUrl}
                        onChange={(e) => setCustomToneUrl(e.target.value)}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none"
                        placeholder="Paste ringtone or music URL"
                      />
                    )}

                    {endToneSource === 'file' && (
                      <div>
                        <label className="block w-full bg-white/5 border border-dashed border-white/15 rounded-xl px-4 py-3 text-slate-300 text-sm cursor-pointer">
                          {customToneFileName || 'Choose audio from gallery'}
                          <input
                            type="file"
                            accept="audio/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (!file) return;
                              setCustomToneFileName(file.name);
                              const reader = new FileReader();
                              reader.onload = () => setCustomToneFileData(String(reader.result || ''));
                              reader.readAsDataURL(file);
                            }}
                          />
                        </label>
                      </div>
                    )}
                  </div>
                )}

                {!isPremium && (
                  <div className="mt-4 flex items-start gap-2 rounded-2xl bg-amber-500/10 border border-amber-400/20 p-3">
                    <Crown size={16} className="text-amber-300 mt-0.5" />
                    <p className="text-amber-100 text-xs leading-relaxed">Begin any breathing exercise for free. Upgrade to Pro if you want a custom session timer and a finish tone from sounds, downloads, URL, or gallery.</p>
                  </div>
                )}
              </div>

              <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
                <span>Total session</span>
                <span className="text-white font-medium">~{Math.ceil(effectiveTotalTime / 60)} min</span>
              </div>
            </div>

            {sessionNotice && <p className="text-xs text-cyan-300 mb-4">{sessionNotice}</p>}

            <button
              onClick={startSession}
              className="w-full px-12 py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg transition-all active:scale-[0.97] shadow-lg shadow-emerald-500/20"
            >
              Begin Session
            </button>
          </div>
        )}

        {isActive && (
          <div className="flex flex-col items-center animate-fade-in px-4 pt-6 pb-10 min-h-full justify-center">
            <div className="mb-4 text-center">
              <p className="text-cyan-300 text-xs uppercase tracking-[0.2em]">Time left</p>
              <p className="text-white text-2xl font-semibold">{minutesLeft}:{String(secondsLeft).padStart(2, '0')}</p>
            </div>
            {/* Breathing circle */}
            <div className="relative w-64 h-64 flex items-center justify-center">
              {/* Outer glow */}
              <div
                className="absolute inset-0 rounded-full transition-all duration-1000 ease-in-out"
                style={{
                  transform: `scale(${getCircleScale()})`,
                  boxShadow: `0 0 60px 20px ${getGlowColor()}`,
                }}
              />
              {/* Outer ring */}
              <div
                className="absolute inset-2 rounded-full border-2 transition-all duration-1000 ease-in-out opacity-30"
                style={{
                  transform: `scale(${getCircleScale()})`,
                  borderColor: getGlowColor(),
                }}
              />
              {/* Main circle */}
              <div
                className="w-48 h-48 rounded-full bg-gradient-to-br from-slate-800 to-slate-900 border border-white/10 flex flex-col items-center justify-center transition-all duration-1000 ease-in-out shadow-2xl"
                style={{ transform: `scale(${getCircleScale()})` }}
              >
                <p className={`text-4xl font-light ${getPhaseColor()} transition-colors duration-500`}>
                  {countdown}
                </p>
                <p className={`text-sm font-medium mt-1 ${getPhaseColor()} transition-colors duration-500`}>
                  {getPhaseLabel()}
                </p>
              </div>
            </div>

            {/* Pattern info */}
            <div className="mt-8 flex items-center gap-4">
              {['inhale', 'hold', 'exhale'].map((p) => (
                <div
                  key={p}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    phase === p
                      ? 'bg-white/10 text-white'
                      : 'text-slate-600'
                  }`}
                >
                  {p === 'inhale' ? 'In' : p === 'hold' ? 'Hold' : 'Out'} {getPhaseTime(p as Phase)}s
                </div>
              ))}
            </div>

            {/* Stop button */}
            <button
              onClick={() => {
                setIsActive(false);
                setIsComplete(false);
              }}
              className="mt-8 px-8 py-3 rounded-xl border border-slate-700 text-slate-400 text-sm hover:bg-white/5 transition-all"
            >
              End Session
            </button>
          </div>
        )}

        {isComplete && (
          <div className="text-center animate-fade-in px-8">
            <div className="w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-6">
              <span className="text-4xl">✨</span>
            </div>
            <h2 className="text-2xl font-bold text-white font-display mb-2">Well Done</h2>
            <p className="text-slate-400 text-sm mb-2">
              You completed {pattern.rounds} rounds of {pattern.name}
            </p>
            <p className="text-slate-500 text-xs mb-8">
              {Math.ceil(totalTime / 60)} minute{Math.ceil(totalTime / 60) > 1 ? 's' : ''} of calm added to your day
            </p>
            <div className="flex gap-3">
              <button
                onClick={startSession}
                className="flex-1 py-3 rounded-xl border border-emerald-500/30 text-emerald-400 font-medium text-sm hover:bg-emerald-500/10 transition-all"
              >
                Again
              </button>
              <button
                onClick={() => setActiveScreen('main')}
                className="flex-1 py-3 rounded-xl bg-emerald-500 text-white font-medium text-sm hover:bg-emerald-600 transition-all"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
