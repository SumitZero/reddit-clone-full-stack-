import { useEffect, useMemo, useState } from 'react';
import { X, CheckCircle2, Crown, Sparkles, ShieldCheck, RefreshCw, MoonStar, BellRing, Download, BarChart3, Palette, Wind, Music4, Check, AlertCircle, ReceiptText, CircleDollarSign, Ban, ExternalLink } from 'lucide-react';
import { useAppStore, type BillingProvider, type SubscriptionPlan } from '../store/appStore';
import { detectPricingRegion, type PlanId } from '../lib/pricing';
import { cancelSubscriptionNow, createCheckoutIntent, getSubscriptionSnapshot, listTransactions, markTransactionStatus, seedPendingTransaction, verifyCheckout } from '../lib/backend';

const features = [
  { icon: Wind, title: 'All Breathing Programs', desc: '10+ premium patterns for stress, sleep, focus, and calm' },
  { icon: Music4, title: 'Full Sound Library', desc: 'Unlock all nature sounds, ambient tones, and sleep audio' },
  { icon: BarChart3, title: 'Advanced Analytics', desc: 'See deeper insights into streaks, calm minutes, and mood trends' },
  { icon: BellRing, title: 'Custom Reminders', desc: 'Set unlimited reminders for reset breaks, sleep, and focus' },
  { icon: Palette, title: 'Premium Themes', desc: 'Use elegant themes, colors, and premium visual styles' },
  { icon: Download, title: 'Offline Access', desc: 'Keep favorite sessions and sounds ready even without internet' },
  { icon: MoonStar, title: 'Sleep Programs', desc: 'Extended bedtime content, sleep sounds, and wind-down flows' },
  { icon: Sparkles, title: 'New Content Monthly', desc: 'Fresh sessions, sound packs, and guided resets every month' },
];

export default function PremiumPage() {
  const {
    setActiveScreen,
    isPremium,
    subscriptionPlan,
    paymentState,
    paymentVerified,
    billingProvider,
    cancelAtPeriodEnd,
    transactionHistory,
    startPaymentFlow,
    completeVerifiedPayment,
    failPaymentFlow,
    resetPaymentState,
    setTransactionHistory,
    addTransactionRecord,
    markCancelAtPeriodEnd,
  } = useAppStore();

  const [selectedPlan, setSelectedPlan] = useState<PlanId>('yearly');
  const [selectedProvider, setSelectedProvider] = useState<BillingProvider>('paypal');
  const [message, setMessage] = useState('');
  const pricing = useMemo(() => detectPricingRegion(navigator.language, Intl.DateTimeFormat().resolvedOptions().timeZone), []);
  const plans = [pricing.monthly, pricing.yearly, pricing.lifetime];

  useEffect(() => {
    listTransactions().then((items) => setTransactionHistory(items.map((item) => ({
      ...item,
      plan: item.plan as SubscriptionPlan,
      createdAt: item.createdAt ?? Date.now(),
    })))).catch(() => undefined);
    getSubscriptionSnapshot()
      .then((snapshot) => {
        if (!snapshot) return;
        if (snapshot.status === 'active' || snapshot.status === 'cancelled') {
          completeVerifiedPayment(
            snapshot.plan as SubscriptionPlan,
            snapshot.region || pricing.region,
            snapshot.transactionReference || '',
            snapshot.provider,
            snapshot.expiryDate ?? null
          );
          markCancelAtPeriodEnd(!!snapshot.cancelAtPeriodEnd);
        }
      })
      .catch(() => undefined);
  }, [setTransactionHistory, completeVerifiedPayment, markCancelAtPeriodEnd, pricing.region]);

  const close = () => {
    if (paymentState === 'pending') return;
    resetPaymentState();
    setActiveScreen('main');
  };

  const startCheckout = async () => {
    try {
      const chosenPlan = selectedPlan as SubscriptionPlan;
      const planMeta = plans.find((item) => item.id === selectedPlan);
      if (!planMeta) return;

      startPaymentFlow(selectedProvider);
      const intent = await createCheckoutIntent({
        provider: selectedProvider,
        plan: chosenPlan as 'monthly' | 'yearly' | 'lifetime',
        region: pricing.region,
        priceLabel: planMeta.price,
      });

      await seedPendingTransaction({
        provider: selectedProvider,
        plan: chosenPlan as 'monthly' | 'yearly' | 'lifetime',
        amountLabel: planMeta.price,
        currency: planMeta.price.replace(/[0-9.,/ ]/g, '') || 'USD',
        reference: intent.reference,
        region: pricing.region,
      });

      addTransactionRecord({
        id: intent.reference,
        provider: selectedProvider,
        plan: chosenPlan,
        amountLabel: planMeta.price,
        currency: planMeta.price.replace(/[0-9.,/ ]/g, '') || 'USD',
        status: 'pending',
        transactionReference: intent.reference,
        createdAt: Date.now(),
        cancellationScheduled: false,
      });

      setMessage(selectedProvider === 'paypal'
        ? 'PayPal intent created. Connect your live PayPal plan IDs and render the PayPal subscription button in production.'
        : 'Razorpay intent created. Connect your live Razorpay checkout modal and pass the verification fields in production.');

      if (selectedProvider === 'paypal') {
        failPaymentFlow('cancelled');
        return;
      }

      failPaymentFlow('cancelled');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Unable to start checkout right now.');
      failPaymentFlow('failed');
    }
  };

  const verifyDemoSuccess = async () => {
    const latest = transactionHistory[0];
    if (!latest) return;
    try {
      startPaymentFlow(latest.provider);
      const result = await verifyCheckout({
        provider: latest.provider,
        reference: latest.transactionReference,
        paypalSubscriptionId: latest.provider === 'paypal' ? 'demo_paypal_sub_id' : undefined,
        razorpayPaymentId: latest.provider === 'razorpay' ? 'pay_demo' : undefined,
        razorpaySignature: latest.provider === 'razorpay' ? 'invalid-demo-signature' : undefined,
        razorpaySubscriptionId: latest.provider === 'razorpay' ? 'sub_demo' : undefined,
      });

      if (result.verified) {
        await markTransactionStatus(result.transactionReference, 'active', {
          expiryDate: result.expiryDate ?? null,
        });
        completeVerifiedPayment(
          result.plan as SubscriptionPlan,
          result.region,
          result.transactionReference,
          result.provider,
          result.expiryDate ?? null
        );
        setMessage('Subscription verified. Pro access is now unlocked.');
      }
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Verification failed.');
      failPaymentFlow('failed');
    }
  };

  const cancelMembership = async () => {
    try {
      const result = await cancelSubscriptionNow();
      markCancelAtPeriodEnd(result.cancelAtPeriodEnd);
      setMessage('Your subscription will stay active until the current billing period ends, then it will stop renewing.');
    } catch (error) {
      setMessage(error instanceof Error ? error.message : 'Unable to cancel right now.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-sm">
      <button className="absolute inset-0" onClick={close} aria-label="Close paywall" />
      <div className="absolute inset-x-0 bottom-0 mx-auto max-h-[94vh] w-full max-w-lg overflow-y-auto rounded-t-[2rem] border border-white/10 bg-[radial-gradient(circle_at_top,_rgba(20,184,166,0.14),_transparent_24%),radial-gradient(circle_at_top_right,_rgba(99,102,241,0.18),_transparent_28%),linear-gradient(180deg,#07101c_0%,#0c1422_50%,#101827_100%)] px-4 pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))] shadow-2xl shadow-black/50 sm:inset-6 sm:rounded-[2rem]">
        <div className="mx-auto mb-4 h-1.5 w-14 rounded-full bg-white/10 sm:hidden" />

        <div className="sticky top-0 z-10 -mx-4 mb-4 flex items-center justify-between border-b border-white/5 bg-[#0b1321]/90 px-4 pb-4 pt-1 backdrop-blur-xl">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/20 bg-amber-400/10 px-3 py-1 text-[11px] font-semibold text-amber-200">
              <Crown size={12} />
              Pro Member
            </div>
            <p className="mt-2 text-sm text-slate-400">Take control of your calm</p>
          </div>
          <button
            onClick={close}
            className="rounded-full border border-white/10 bg-white/5 p-2 text-slate-300 transition hover:bg-white/10 hover:text-white"
            aria-label="Close premium"
          >
            <X size={18} />
          </button>
        </div>

        {paymentState === 'pending' && (
          <div className="animate-fade-in rounded-[1.75rem] border border-cyan-400/20 bg-cyan-400/8 p-6 text-center">
            <RefreshCw size={34} className="mx-auto mb-4 animate-spin text-cyan-300" />
            <h2 className="text-xl font-bold text-white">Processing your payment…</h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              Verifying subscription with secure backend checks. Pro access will unlock only after successful verification.
            </p>
          </div>
        )}

        {paymentState === 'success' && paymentVerified && (
          <div className="animate-fade-in rounded-[1.75rem] border border-emerald-400/20 bg-emerald-400/8 p-6 text-center">
            <CheckCircle2 size={36} className="mx-auto mb-4 text-emerald-300" />
            <h2 className="text-xl font-bold text-white">You’re now a Pro Member</h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              Premium features are unlocked after successful payment verification.
            </p>
            <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300">
              <ShieldCheck size={14} className="text-emerald-300" />
              Active plan: {subscriptionPlan}
            </div>
            <button
              onClick={close}
              className="mt-5 w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 py-3.5 text-sm font-semibold text-white"
            >
              Continue to MindReset
            </button>
          </div>
        )}

        {(paymentState === 'failed' || paymentState === 'cancelled') && (
          <div className="animate-fade-in rounded-[1.75rem] border border-rose-400/20 bg-rose-400/8 p-6 text-center">
            <AlertCircle size={34} className="mx-auto mb-4 text-rose-300" />
            <h2 className="text-xl font-bold text-white">Payment not completed</h2>
            <p className="mt-2 text-sm leading-relaxed text-slate-400">
              No Pro features were activated. You can retry anytime when you’re ready.
            </p>
            <div className="mt-5 grid grid-cols-2 gap-3">
              <button onClick={close} className="rounded-2xl border border-white/10 py-3 text-sm text-slate-300">Maybe later</button>
              <button onClick={() => resetPaymentState()} className="rounded-2xl bg-white text-sm font-semibold text-slate-900">Try again</button>
            </div>
          </div>
        )}

        {(paymentState === 'idle' || (isPremium && paymentState !== 'success')) && (
          <div className="animate-fade-in">
            <div className="rounded-[1.75rem] border border-white/10 bg-gradient-to-br from-white/8 to-white/4 p-6 shadow-xl shadow-black/20">
              <h1 className="max-w-xs text-3xl font-bold leading-tight text-white">Unlock your calm, sleep, and focus</h1>
              <p className="mt-3 text-sm leading-relaxed text-slate-400">
                A few minutes a day can make a real difference. Upgrade when you’re ready.
              </p>
              <div className="mt-4 flex flex-wrap gap-2">
                <span className="rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[11px] font-medium text-emerald-200">Cancel anytime</span>
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-medium text-slate-300">Secure payment</span>
                <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[11px] font-medium text-slate-300">Access after verification</span>
              </div>
            </div>

            <div className="mt-5 space-y-3">
              {features.map(({ icon: Icon, title, desc }) => (
                <div key={title} className="flex items-center gap-3 rounded-2xl border border-white/8 bg-white/5 p-4">
                  <div className="rounded-2xl bg-white/7 p-2.5 text-cyan-200">
                    <Icon size={18} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-white">{title}</p>
                    <p className="mt-0.5 text-xs leading-relaxed text-slate-400">{desc}</p>
                  </div>
                  <Check size={18} className="text-emerald-300" />
                </div>
              ))}
            </div>

            <div className="mt-6 rounded-[1.75rem] border border-white/10 bg-white/4 p-4">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <h2 className="text-base font-semibold text-white">Choose your plan</h2>
                  <p className="text-xs text-slate-400">{pricing.currencyNote}</p>
                </div>
                <div className="text-right text-[11px] text-slate-500">
                  {pricing.exampleCountries.slice(0, 3).join(' · ')}
                </div>
              </div>

              <div className="mb-4 grid grid-cols-2 gap-3">
                <button
                  onClick={() => setSelectedProvider('paypal')}
                  className={`rounded-2xl border px-4 py-3 text-left ${selectedProvider === 'paypal' ? 'border-emerald-400/40 bg-emerald-400/10 text-white' : 'border-white/10 bg-white/5 text-slate-300'}`}
                >
                  <div className="flex items-center gap-2 text-sm font-semibold"><CircleDollarSign size={16} /> PayPal</div>
                  <p className="mt-1 text-[11px] text-slate-400">Use PayPal / cards for verified subscription checkout</p>
                </button>
                <button
                  onClick={() => setSelectedProvider('razorpay')}
                  className={`rounded-2xl border px-4 py-3 text-left ${selectedProvider === 'razorpay' ? 'border-emerald-400/40 bg-emerald-400/10 text-white' : 'border-white/10 bg-white/5 text-slate-300'}`}
                >
                  <div className="flex items-center gap-2 text-sm font-semibold"><CircleDollarSign size={16} /> Razorpay</div>
                  <p className="mt-1 text-[11px] text-slate-400">Use UPI / cards for verified subscription checkout</p>
                </button>
              </div>

              <div className="mb-4 rounded-2xl border border-white/10 bg-white/5 p-4 text-xs leading-relaxed text-slate-400">
                Users can choose either PayPal or Razorpay before paying. Pro access is granted only after backend verification. If a monthly plan is cancelled, access stays active until the end of that month. If a yearly plan is cancelled, access stays active until the end of that year. Refund requests are reviewed and, when approved, returned to the original payment method according to provider policy.
              </div>

              <div className="space-y-3">
                <div className="rounded-2xl border border-slate-700/70 bg-slate-900/35 p-4 opacity-80">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-sm font-semibold text-white">Free Plan</p>
                      <p className="mt-1 text-xs text-slate-400">Limited breathing, limited sounds, basic reminders and analytics</p>
                    </div>
                    <span className="rounded-full border border-white/10 px-2.5 py-1 text-[11px] text-slate-300">Current</span>
                  </div>
                </div>

                {plans.map((plan) => {
                  const selected = selectedPlan === plan.id;
                  return (
                    <button
                      key={plan.id}
                      onClick={() => setSelectedPlan(plan.id)}
                      className={`relative w-full rounded-2xl border p-4 text-left transition ${selected ? 'border-emerald-400/40 bg-emerald-400/8 shadow-lg shadow-emerald-500/10' : 'border-white/10 bg-white/5'}`}
                    >
                      {plan.badge && (
                        <span className="absolute right-4 top-0 -translate-y-1/2 rounded-full bg-emerald-500 px-3 py-1 text-[11px] font-semibold text-white">
                          {plan.badge}
                        </span>
                      )}
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <p className="text-sm font-semibold text-white">{plan.label}</p>
                          <p className="mt-1 text-xs text-slate-400">{plan.sublabel}</p>
                          {plan.savings && <p className="mt-1 text-xs font-medium text-emerald-300">{plan.savings}</p>}
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-white">{plan.price}</p>
                          <p className="text-[11px] text-slate-500">Instant access after verification</p>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 rounded-2xl border border-white/8 bg-white/4 p-4 text-xs leading-relaxed text-slate-400">
              <div className="mb-2 flex items-center gap-2 text-slate-300">
                <ShieldCheck size={14} className="text-emerald-300" />
                Only successful verified payments unlock Pro
              </div>
              Tapping the button starts checkout. Pro features stay locked until payment succeeds, backend verification passes, and your subscription status is updated securely.
            </div>

            {message && (
              <div className="mt-4 rounded-2xl border border-cyan-400/15 bg-cyan-400/8 p-4 text-sm text-cyan-100">
                {message}
              </div>
            )}

            {(isPremium || transactionHistory.length > 0) && (
              <div className="mt-6 space-y-4">
                <div className="rounded-[1.5rem] border border-white/10 bg-white/4 p-4">
                  <div className="flex items-center gap-2 text-white">
                    <Ban size={16} className="text-amber-300" />
                    <h3 className="text-sm font-semibold">Manage subscription</h3>
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-slate-400">
                    {cancelAtPeriodEnd
                      ? 'Cancellation is scheduled. Your Pro access stays active until the end of the current billing period.'
                      : 'Cancel anytime. If you cancel before month-end, Pro stays active until your current paid period ends.'}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2 text-[11px] text-slate-300">
                    {billingProvider && <span className="rounded-full border border-white/10 px-3 py-1">Provider: {billingProvider}</span>}
                    {cancelAtPeriodEnd && <span className="rounded-full border border-amber-400/20 bg-amber-400/10 px-3 py-1 text-amber-200">Cancels at period end</span>}
                  </div>
                  {isPremium && !cancelAtPeriodEnd && (
                    <button
                      onClick={cancelMembership}
                      className="mt-4 w-full rounded-2xl border border-rose-400/20 bg-rose-400/10 py-3 text-sm font-semibold text-rose-100"
                    >
                      Cancel anytime
                    </button>
                  )}
                </div>

                <div className="rounded-[1.5rem] border border-white/10 bg-white/4 p-4">
                  <div className="mb-3 flex items-center gap-2 text-white">
                    <ReceiptText size={16} className="text-cyan-200" />
                    <h3 className="text-sm font-semibold">Transaction history</h3>
                  </div>
                  <div className="space-y-3">
                    {transactionHistory.length === 0 && (
                      <div className="rounded-2xl border border-dashed border-white/10 p-4 text-xs text-slate-500">
                        No transactions yet. Your successful payments will appear here.
                      </div>
                    )}
                    {transactionHistory.map((item) => (
                      <div key={item.id} className="rounded-2xl border border-white/8 bg-slate-900/30 p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className="text-sm font-semibold text-white">{item.plan} · {item.provider}</p>
                            <p className="mt-1 text-xs text-slate-400">{item.amountLabel} · Ref {item.transactionReference}</p>
                            <p className="mt-1 text-[11px] text-slate-500">{new Date(item.createdAt).toLocaleString()}</p>
                          </div>
                          <span className="rounded-full border border-white/10 px-2.5 py-1 text-[11px] text-slate-300">{item.status}</span>
                        </div>
                        <div className="mt-3 flex flex-wrap gap-2">
                          {item.status === 'pending' && (
                            <button onClick={verifyDemoSuccess} className="rounded-xl bg-white px-3 py-2 text-xs font-semibold text-slate-900">
                              Verify payment result
                            </button>
                          )}
                          {item.status === 'active' && !item.cancellationScheduled && (
                            <button onClick={cancelMembership} className="rounded-xl border border-white/10 px-3 py-2 text-xs text-slate-200">
                              Cancel at period end
                            </button>
                          )}
                          <a href="#" className="inline-flex items-center gap-1 rounded-xl border border-white/10 px-3 py-2 text-xs text-slate-300">
                            Open invoice <ExternalLink size={12} />
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="sticky bottom-0 mt-6 -mx-4 border-t border-white/5 bg-[#0b1321]/95 px-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-4 backdrop-blur-xl">
              <button
                onClick={startCheckout}
                className="w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 py-4 text-sm font-semibold text-white shadow-lg shadow-emerald-500/20 transition active:scale-[0.99]"
              >
                Become Pro Member
              </button>
              <div className="mt-3 flex items-center justify-center gap-4 text-xs">
                <button onClick={close} className="text-slate-400 transition hover:text-white">Not now</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
