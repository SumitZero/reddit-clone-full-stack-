import { ArrowLeft, Download, Share2, Sparkles } from 'lucide-react';
import { getReferralMessage } from '../lib/referral';
import { useAppStore } from '../store/appStore';

export default function DownloadPage() {
  const setActiveScreen = useAppStore((s) => s.setActiveScreen);
  const params = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const referralCode = params.get('ref');
  const shareMessage = getReferralMessage(undefined, undefined);
  const landingLink = typeof window !== 'undefined' ? window.location.href : 'https://mindreset.app/download';

  return (
    <div className="fixed inset-0 z-[95] overflow-y-auto bg-[#07101d]/95 backdrop-blur-xl">
      <div className="mx-auto min-h-screen max-w-lg px-4 pb-8 pt-[max(1rem,env(safe-area-inset-top))] text-white">
        <button
          onClick={() => setActiveScreen('main')}
          className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-200"
        >
          <ArrowLeft size={16} /> Back to app
        </button>

        <div className="rounded-[2rem] border border-white/10 bg-[radial-gradient(circle_at_top,_rgba(52,211,153,0.16),_transparent_35%),linear-gradient(180deg,rgba(15,23,42,0.96),rgba(15,23,42,0.86))] p-6 shadow-2xl shadow-black/30">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-4 py-2 text-sm font-medium text-emerald-200">
            <Sparkles size={15} /> You were invited to MindReset
          </div>

          <h1 className="mt-5 text-4xl font-bold leading-tight">Find your calm in minutes</h1>
          <p className="mt-4 text-base leading-relaxed text-slate-300">
            Quick breathing resets, calming sounds, stress relief sessions, journaling, reminders, and daily wellness support — all in one premium-feel app.
          </p>

          {referralCode && (
            <div className="mt-5 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-slate-200">
              Invited by referral ID: <span className="font-semibold text-white">{referralCode}</span>
            </div>
          )}

          <div className="mt-6 grid gap-3">
            <button
              onClick={() => setActiveScreen('main')}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 px-5 py-4 text-base font-semibold text-white shadow-lg shadow-emerald-900/30"
            >
              <Download size={18} /> Open MindReset
            </button>
            <button
              onClick={async () => {
                if (navigator.share) {
                  await navigator.share({ title: 'MindReset', text: shareMessage, url: landingLink }).catch(() => undefined);
                  return;
                }
                await navigator.clipboard.writeText(landingLink).catch(() => undefined);
              }}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-base font-medium text-white"
            >
              <Share2 size={18} /> Share this link
            </button>
            <button
              onClick={async () => {
                await navigator.clipboard.writeText(landingLink).catch(() => undefined);
              }}
              className="rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-sm font-medium text-slate-200"
            >
              Copy referral link
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
