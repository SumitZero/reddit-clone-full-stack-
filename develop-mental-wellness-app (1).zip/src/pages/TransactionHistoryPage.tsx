import { ArrowLeft, Download, ReceiptText, RotateCcw, Search, Share2, ShieldCheck } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { getSubscriptionSnapshot, listTransactions, requestSubscriptionRefund, type TransactionItem } from '../lib/backend';
import { downloadAllInvoices, exportTransactionPdf, exportTransactionsCsv, getInvoiceNumber, getReceiptNumber, shareTransactionInvoice } from '../lib/invoice';
import { useAppStore } from '../store/appStore';

function formatDate(value?: number | null) {
  if (!value) return '—';
  return new Date(value).toLocaleString();
}

function statusClasses(status: string, refundStatus?: string) {
  if (refundStatus === 'approved') return 'bg-cyan-500/15 text-cyan-300';
  if (status === 'active') return 'bg-emerald-500/15 text-emerald-300';
  if (status === 'cancelled') return 'bg-amber-500/15 text-amber-300';
  if (status === 'failed') return 'bg-rose-500/15 text-rose-300';
  return 'bg-slate-700/60 text-slate-300';
}

type HistoryFilter = 'all' | 'active' | 'cancelled' | 'refunded';

export default function TransactionHistoryPage() {
  const { setActiveScreen, isLoggedIn, userEmail } = useAppStore();
  const [transactions, setTransactions] = useState<TransactionItem[]>([]);
  const [subscriptionMessage, setSubscriptionMessage] = useState('');
  const [subscriptionPolicy, setSubscriptionPolicy] = useState('');
  const [filter, setFilter] = useState<HistoryFilter>('all');
  const [search, setSearch] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  useEffect(() => {
    if (!isLoggedIn) {
      setTransactions([]);
      return;
    }

    listTransactions().then(setTransactions).catch(() => undefined);
    getSubscriptionSnapshot()
      .then((snapshot) => {
        if (!snapshot) return;
        setSubscriptionPolicy(snapshot.refundPolicy || '');
      })
      .catch(() => undefined);
  }, [isLoggedIn]);

  const latest = useMemo(() => transactions[0] ?? null, [transactions]);

  const filteredTransactions = useMemo(() => {
    const start = startDate ? new Date(`${startDate}T00:00:00`).getTime() : null;
    const end = endDate ? new Date(`${endDate}T23:59:59`).getTime() : null;

    return transactions.filter((item) => {
      const byFilter =
        filter === 'all'
          ? true
          : filter === 'refunded'
            ? item.refundStatus === 'approved'
            : item.status === filter;

      const needle = search.trim().toLowerCase();
      const bySearch = !needle || item.transactionReference.toLowerCase().includes(needle);
      const createdAt = item.purchaseDate ?? item.createdAt ?? 0;
      const byDate = (!start || createdAt >= start) && (!end || createdAt <= end);
      return byFilter && bySearch && byDate;
    });
  }, [transactions, filter, search, startDate, endDate]);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-surface">
      <div className="mx-auto max-w-lg px-4 pb-8 pt-[max(1rem,env(safe-area-inset-top))]">
        <div className="flex items-center gap-3 pb-4 pt-4">
          <button onClick={() => setActiveScreen('main')} className="rounded-xl p-2 hover:bg-white/5">
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="font-display text-xl font-bold text-white">Transaction History</h1>
        </div>

        <div className="rounded-3xl border border-white/5 bg-white/5 p-4">
          <div className="flex items-start gap-3">
            <div className="rounded-2xl bg-cyan-400/10 p-2 text-cyan-300">
              <ReceiptText size={18} />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">Verified Pro billing history</p>
              <p className="mt-1 text-xs leading-relaxed text-slate-400">
                Every successful, cancelled, failed, or refunded Pro payment appears here after backend verification.
              </p>
            </div>
          </div>
        </div>

        {latest && (
          <div className="mt-4 rounded-3xl border border-emerald-400/10 bg-emerald-400/5 p-4">
            <div className="flex items-start gap-3">
              <div className="rounded-2xl bg-emerald-500/10 p-2 text-emerald-300">
                <ShieldCheck size={18} />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">Latest verified transaction</p>
                <p className="mt-1 text-xs text-slate-400">
                  {latest.plan} • {latest.amountLabel} • {latest.provider}
                </p>
                <p className="mt-2 text-[11px] text-slate-500">Reference: {latest.transactionReference}</p>
              </div>
            </div>
          </div>
        )}

        <div className="mt-4 rounded-3xl border border-white/5 bg-white/5 p-4">
          <div className="relative">
            <Search size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by transaction reference"
              className="w-full rounded-2xl border border-white/10 bg-slate-950/30 py-3 pl-11 pr-4 text-sm text-white outline-none placeholder:text-slate-500"
            />
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {(['all', 'active', 'cancelled', 'refunded'] as HistoryFilter[]).map((item) => (
              <button
                key={item}
                onClick={() => setFilter(item)}
                className={`rounded-2xl px-3 py-2 text-xs font-semibold capitalize transition ${
                  filter === item ? 'bg-cyan-400 text-slate-950' : 'bg-white/5 text-slate-300'
                }`}
              >
                {item}
              </button>
            ))}
          </div>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="rounded-2xl border border-white/10 bg-slate-950/30 px-4 py-3 text-sm text-white outline-none"
            />
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="rounded-2xl border border-white/10 bg-slate-950/30 px-4 py-3 text-sm text-white outline-none"
            />
          </div>
          <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
            <button
              onClick={() => downloadAllInvoices(filteredTransactions, userEmail)}
              className="inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-white"
            >
              <Download size={16} /> Download all invoices
            </button>
            <button
              onClick={() => exportTransactionsCsv(filteredTransactions)}
              className="inline-flex w-full items-center justify-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-semibold text-white"
            >
              <ReceiptText size={16} /> Export CSV
            </button>
          </div>
        </div>

        {subscriptionPolicy && (
          <div className="mt-4 rounded-2xl border border-white/5 bg-white/5 p-4 text-xs leading-relaxed text-slate-400">
            <span className="font-semibold text-white">Refund policy:</span> {subscriptionPolicy}
          </div>
        )}

        {subscriptionMessage && (
          <div className="mt-4 rounded-2xl border border-cyan-400/15 bg-cyan-400/5 p-4 text-xs text-cyan-100">
            {subscriptionMessage}
          </div>
        )}

        <div className="mt-5 space-y-3">
          {filteredTransactions.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-white/10 px-4 py-8 text-center text-sm text-slate-500">
              No transactions match your search or filter.
            </div>
          ) : (
            filteredTransactions.map((item) => (
              <div key={item.id} className="rounded-3xl border border-white/8 bg-white/5 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-semibold text-white">{item.plan} • {item.amountLabel}</p>
                    <p className="mt-1 text-xs text-slate-400">{item.provider} • {item.transactionReference}</p>
                  </div>
                  <span className={`rounded-full px-2.5 py-1 text-[11px] font-medium ${statusClasses(item.status, item.refundStatus)}`}>
                    {item.refundStatus === 'approved' ? 'refunded' : item.status}
                  </span>
                </div>

                <div className="mt-4 rounded-2xl border border-white/6 bg-slate-950/20 p-3 text-[11px] text-slate-400">
                  <p>Invoice no: <span className="text-slate-200">{getInvoiceNumber(item)}</span></p>
                  <p className="mt-1">Receipt no: <span className="text-slate-200">{getReceiptNumber(item)}</span></p>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-2 text-[11px] text-slate-400">
                  <p>Purchased: {formatDate(item.purchaseDate ?? item.createdAt)}</p>
                  <p>Access until: {formatDate(item.expiryDate)}</p>
                  <p>Cancellation: {item.cancellationScheduled ? 'Scheduled' : 'Active renewal'}</p>
                  <p>Refund: {item.refundStatus || 'none'}</p>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() => exportTransactionPdf(item, userEmail)}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-white"
                  >
                    <Download size={14} /> PDF invoice
                  </button>
                  <button
                    onClick={() => shareTransactionInvoice(item, userEmail)}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-medium text-white"
                  >
                    <Share2 size={14} /> Share invoice
                  </button>
                  {(item.status === 'active' || item.status === 'cancelled') && item.refundStatus !== 'requested' && item.refundStatus !== 'processing' && (
                    <button
                      onClick={async () => {
                        const response = await requestSubscriptionRefund({
                          reference: item.transactionReference,
                          reason: 'Requested from transaction history.',
                        }).catch(() => null);
                        setSubscriptionMessage(response?.message || 'Unable to send refund request right now.');
                        const refreshed = await listTransactions().catch(() => []);
                        setTransactions(refreshed);
                      }}
                      className="inline-flex items-center gap-2 rounded-xl border border-cyan-400/20 bg-cyan-400/10 px-3 py-2 text-xs font-medium text-cyan-200"
                    >
                      <RotateCcw size={14} /> Request refund
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
