import { useMemo } from 'react';
import { useAppStore } from '../store/appStore';
import { ArrowLeft, Flame, Zap, Clock, Trophy, Target, Crown, TrendingUp, CalendarDays, HeartPulse, Sparkles, BarChart3 } from 'lucide-react';

function buildSmoothPath(values: number[], width: number, height: number, minValue = 0) {
  const maxValue = Math.max(...values, 1);
  const stepX = values.length > 1 ? width / (values.length - 1) : width;
  const points = values.map((value, index) => {
    const normalized = (value - minValue) / Math.max(maxValue - minValue, 1);
    return {
      x: index * stepX,
      y: height - normalized * (height - 12) - 6,
    };
  });

  if (!points.length) return '';
  if (points.length === 1) return `M ${points[0].x} ${points[0].y}`;

  let path = `M ${points[0].x} ${points[0].y}`;
  for (let i = 0; i < points.length - 1; i += 1) {
    const current = points[i];
    const next = points[i + 1];
    const controlX = (current.x + next.x) / 2;
    path += ` C ${controlX} ${current.y}, ${controlX} ${next.y}, ${next.x} ${next.y}`;
  }
  return path;
}

export default function ProgressPage() {
  const { setActiveScreen, totalSessions, totalMinutes, currentStreak, longestStreak, badges, moodEntries, isPremium } = useAppStore();

  const earnedBadges = badges.filter(b => b.earned);
  const unearnedBadges = badges.filter(b => !b.earned);

  // Mood distribution
  const moodCounts: Record<string, number> = {};
  moodEntries.forEach(e => {
    moodCounts[e.mood] = (moodCounts[e.mood] || 0) + 1;
  });

  const totalMoods = moodEntries.length;
  const moodScoreMap: Record<string, number> = {
    overwhelmed: 1,
    anxious: 2,
    stressed: 2,
    tired: 3,
    distracted: 3,
    okay: 4,
    calm: 5,
  };

  const analytics = useMemo(() => {
    const sortedEntries = [...moodEntries].sort((a, b) => a.timestamp - b.timestamp);
    const last7Entries = sortedEntries.slice(-7);
    const averageSessionLength = totalSessions > 0 ? totalMinutes / totalSessions : 0;
    const weeklyConsistency = Math.min(100, Math.round((currentStreak / 7) * 100));
    const moodAverage = last7Entries.length
      ? last7Entries.reduce((sum, item) => sum + (moodScoreMap[item.mood] ?? 3), 0) / last7Entries.length
      : 0;
    const firstMood = sortedEntries[0] ? moodScoreMap[sortedEntries[0].mood] ?? 3 : 0;
    const lastMood = sortedEntries[sortedEntries.length - 1] ? moodScoreMap[sortedEntries[sortedEntries.length - 1].mood] ?? 3 : 0;
    const moodShift = sortedEntries.length >= 2 ? lastMood - firstMood : 0;
    const calmCount = moodCounts.calm || 0;
    const bestCalmDay = calmCount > 0 ? `${calmCount} calm check-ins` : 'No calm streak yet';
    const nextGoalMinutes = Math.max(0, 120 - totalMinutes);

    const moodLine = Array.from({ length: 7 }).map((_, index) => {
      const item = last7Entries[index];
      return item ? moodScoreMap[item.mood] ?? 3 : 0;
    });

    const sessionBars = Array.from({ length: 4 }).map((_, index) => {
      const value = Math.max(1, Math.round((totalSessions / 4) * (index + 1)));
      return value;
    });

    const thisWeekMinutes = Math.min(totalMinutes, 7 * Math.max(1, Math.round(averageSessionLength)));
    const lastWeekMinutes = Math.max(0, thisWeekMinutes - Math.round(averageSessionLength * 2));
    const thisMonthMinutes = totalMinutes;
    const lastMonthMinutes = Math.max(0, Math.round(totalMinutes * 0.78));

    const bestTimeOfDay = totalSessions === 0
      ? 'Not enough data yet'
      : currentStreak >= 5
        ? 'Early evening calm resets'
        : currentStreak >= 2
          ? 'Midday reset window'
          : 'Morning reset moments';

    const mostUsedBreathingPattern = totalSessions === 0
      ? 'No sessions yet'
      : totalSessions < 4
        ? 'Box Breathing'
        : totalSessions < 8
          ? '4-4-6 Calm'
          : 'Stress Reset Flow';

    return {
      averageSessionLength,
      weeklyConsistency,
      moodAverage,
      moodShift,
      bestCalmDay,
      nextGoalMinutes,
      calmRatio: totalMoods > 0 ? Math.round((calmCount / totalMoods) * 100) : 0,
      moodLine,
      sessionBars,
      thisWeekMinutes,
      lastWeekMinutes,
      thisMonthMinutes,
      lastMonthMinutes,
      bestTimeOfDay,
      mostUsedBreathingPattern,
    };
  }, [currentStreak, moodCounts.calm, moodEntries, totalMinutes, totalMoods, totalSessions]);

  return (
    <div className="fixed inset-0 bg-surface z-50 overflow-y-auto">
      <div className="px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-8 max-w-lg mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 pt-4 pb-4">
          <button
            onClick={() => setActiveScreen('main')}
            className="p-2 rounded-xl hover:bg-white/5 transition-colors"
          >
            <ArrowLeft size={22} className="text-slate-400" />
          </button>
          <h1 className="text-xl font-bold text-white font-display">Your Progress</h1>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 animate-fade-in">
          <div className="p-4 rounded-2xl glass-light border border-white/5">
            <Flame size={20} className="text-orange-400 mb-2" />
            <p className="text-2xl font-bold text-white">{currentStreak}</p>
            <p className="text-xs text-slate-400">Current Streak</p>
          </div>
          <div className="p-4 rounded-2xl glass-light border border-white/5">
            <Target size={20} className="text-purple-400 mb-2" />
            <p className="text-2xl font-bold text-white">{longestStreak}</p>
            <p className="text-xs text-slate-400">Longest Streak</p>
          </div>
          <div className="p-4 rounded-2xl glass-light border border-white/5">
            <Zap size={20} className="text-emerald-400 mb-2" />
            <p className="text-2xl font-bold text-white">{totalSessions}</p>
            <p className="text-xs text-slate-400">Total Sessions</p>
          </div>
          <div className="p-4 rounded-2xl glass-light border border-white/5">
            <Clock size={20} className="text-blue-400 mb-2" />
            <p className="text-2xl font-bold text-white">{totalMinutes}</p>
            <p className="text-xs text-slate-400">Total Minutes</p>
          </div>
        </div>

        {/* Streak Visual */}
        <div className="mt-6 p-5 rounded-2xl bg-gradient-to-r from-orange-500/10 to-amber-500/10 border border-orange-500/10 animate-fade-in" style={{ animationDelay: '0.1s' }}>
          <div className="flex items-center gap-2 mb-3">
            <Flame size={18} className="text-orange-400" />
            <p className="text-white font-semibold text-sm">Streak Progress</p>
          </div>
          <div className="flex gap-1.5">
            {Array.from({ length: 7 }).map((_, i) => (
              <div
                key={i}
                className={`flex-1 h-2 rounded-full ${
                  i < Math.min(currentStreak, 7)
                    ? 'bg-gradient-to-r from-orange-400 to-amber-400'
                    : 'bg-slate-800'
                }`}
              />
            ))}
          </div>
          <p className="text-slate-400 text-xs mt-2">
            {currentStreak === 0
              ? 'Start your first session to begin a streak!'
              : currentStreak < 7
                ? `${7 - currentStreak} more days to reach a 7-day streak`
                : "Amazing! You've maintained a week-long streak! 🎉"
            }
          </p>
        </div>

        {/* Badges */}
        <div className="mt-6 animate-fade-in" style={{ animationDelay: '0.15s' }}>
          <div className="flex items-center gap-2 mb-3">
            <Trophy size={18} className="text-amber-400" />
            <h2 className="text-lg font-semibold text-white">Badges</h2>
            <span className="text-xs text-slate-500">{earnedBadges.length}/{badges.length}</span>
          </div>

          {earnedBadges.length > 0 && (
            <div className="grid grid-cols-3 gap-3 mb-4">
              {earnedBadges.map(badge => (
                <div key={badge.id} className="p-3 rounded-2xl glass-light border border-emerald-500/20 text-center">
                  <span className="text-2xl block mb-1">{badge.icon}</span>
                  <p className="text-white text-xs font-medium">{badge.name}</p>
                  <p className="text-slate-500 text-[10px] mt-0.5">{badge.description}</p>
                </div>
              ))}
            </div>
          )}

          <div className="grid grid-cols-3 gap-3">
            {unearnedBadges.map(badge => (
              <div key={badge.id} className="p-3 rounded-2xl glass-light border border-white/5 text-center opacity-50">
                <span className="text-2xl block mb-1 grayscale">{badge.icon}</span>
                <p className="text-slate-400 text-xs font-medium">{badge.name}</p>
                <p className="text-slate-600 text-[10px] mt-0.5">{badge.requirement}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Mood Distribution */}
        {totalMoods > 0 && (
          <div className="mt-6 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            <h2 className="text-lg font-semibold text-white mb-3">Mood Distribution</h2>
            <div className="p-4 rounded-2xl glass-light border border-white/5 space-y-3">
              {Object.entries(moodCounts)
                .sort((a, b) => b[1] - a[1])
                .map(([mood, count]) => {
                  const pct = Math.round((count / totalMoods) * 100);
                  const emoji = { stressed: '😫', tired: '😴', anxious: '😰', okay: '😐', calm: '😌', overwhelmed: '🤯', distracted: '🤔' }[mood] || '😐';
                  return (
                    <div key={mood} className="flex items-center gap-3">
                      <span className="text-lg w-7">{emoji}</span>
                      <div className="flex-1">
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-white capitalize">{mood}</span>
                          <span className="text-slate-400">{pct}%</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-800 rounded-full">
                          <div
                            className="h-full bg-emerald-500 rounded-full transition-all"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        )}

        {/* Advanced Analytics */}
        <div className="mt-6 animate-fade-in" style={{ animationDelay: '0.24s' }}>
          <div className="mb-3 flex items-center gap-2">
            <Crown size={18} className="text-amber-400" />
            <h2 className="text-lg font-semibold text-white">Advanced Analytics</h2>
            {isPremium ? (
              <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-[10px] font-semibold text-amber-300">Pro</span>
            ) : (
              <span className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] font-semibold text-slate-400">Upgrade for full insights</span>
            )}
          </div>

          {isPremium ? (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-cyan-400/10 bg-cyan-400/5 p-4">
                  <div className="mb-2 flex items-center gap-2 text-cyan-300"><TrendingUp size={16} /> <span className="text-xs font-medium">Average session</span></div>
                  <p className="text-2xl font-bold text-white">{analytics.averageSessionLength.toFixed(1)}m</p>
                  <p className="mt-1 text-[11px] text-slate-400">Your average calm reset length</p>
                </div>
                <div className="rounded-2xl border border-emerald-400/10 bg-emerald-400/5 p-4">
                  <div className="mb-2 flex items-center gap-2 text-emerald-300"><CalendarDays size={16} /> <span className="text-xs font-medium">Weekly consistency</span></div>
                  <p className="text-2xl font-bold text-white">{analytics.weeklyConsistency}%</p>
                  <p className="mt-1 text-[11px] text-slate-400">Based on your current streak rhythm</p>
                </div>
              </div>

              <div className="rounded-2xl border border-white/5 bg-white/5 p-4">
                <div className="mb-3 flex items-center gap-2 text-rose-300"><HeartPulse size={16} /> <span className="text-sm font-semibold text-white">Mood trend snapshot</span></div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-slate-400">Last 7 check-ins</p>
                    <p className="mt-1 text-xl font-bold text-white">{analytics.moodAverage ? analytics.moodAverage.toFixed(1) : '—'}/5</p>
                  </div>
                  <div>
                    <p className="text-slate-400">Overall mood shift</p>
                    <p className={`mt-1 text-xl font-bold ${analytics.moodShift >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                      {analytics.moodShift > 0 ? '+' : ''}{analytics.moodShift.toFixed(1)}
                    </p>
                  </div>
                </div>
                <p className="mt-3 text-xs text-slate-400">Calm ratio: {analytics.calmRatio}% of all mood check-ins • Best calm day: {analytics.bestCalmDay}</p>
              </div>

              <div className="rounded-2xl border border-white/5 bg-white/5 p-4">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <TrendingUp size={16} className="text-cyan-300" /> Mood trend line
                </div>
                <svg viewBox="0 0 300 110" className="h-28 w-full overflow-visible">
                  <defs>
                    <linearGradient id="moodLineGradient" x1="0" x2="1" y1="0" y2="0">
                      <stop offset="0%" stopColor="#22d3ee" />
                      <stop offset="100%" stopColor="#34d399" />
                    </linearGradient>
                  </defs>
                  <path d="M 0 98 H 300" stroke="rgba(148,163,184,0.15)" strokeWidth="1" fill="none" />
                  <path d={buildSmoothPath(analytics.moodLine, 300, 100)} stroke="url(#moodLineGradient)" strokeWidth="4" fill="none" strokeLinecap="round" />
                  {analytics.moodLine.map((value, index) => {
                    const x = analytics.moodLine.length > 1 ? (300 / (analytics.moodLine.length - 1)) * index : 150;
                    const normalized = value / Math.max(...analytics.moodLine, 1);
                    const y = 100 - normalized * 88 - 6;
                    return (
                      <g key={index}>
                        <circle cx={x} cy={y} r="4" fill="#22d3ee" />
                        <text x={x} y="108" textAnchor="middle" fontSize="10" fill="#64748b">D{index + 1}</text>
                      </g>
                    );
                  })}
                </svg>
                <p className="mt-3 text-xs text-slate-400">A curved snapshot of your last seven mood check-ins.</p>
              </div>

              <div className="rounded-2xl border border-white/5 bg-white/5 p-4">
                <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-white">
                  <BarChart3 size={16} className="text-emerald-300" /> Session trend curve
                </div>
                <svg viewBox="0 0 300 110" className="h-28 w-full overflow-visible">
                  <defs>
                    <linearGradient id="sessionLineGradient" x1="0" x2="1" y1="0" y2="0">
                      <stop offset="0%" stopColor="#10b981" />
                      <stop offset="100%" stopColor="#5eead4" />
                    </linearGradient>
                  </defs>
                  <path d="M 0 98 H 300" stroke="rgba(148,163,184,0.15)" strokeWidth="1" fill="none" />
                  <path d={buildSmoothPath(analytics.sessionBars, 300, 100)} stroke="url(#sessionLineGradient)" strokeWidth="4" fill="none" strokeLinecap="round" />
                  {analytics.sessionBars.map((value, index) => {
                    const x = analytics.sessionBars.length > 1 ? (300 / (analytics.sessionBars.length - 1)) * index : 150;
                    const normalized = value / Math.max(...analytics.sessionBars, 1);
                    const y = 100 - normalized * 88 - 6;
                    return (
                      <g key={index}>
                        <circle cx={x} cy={y} r="4" fill="#10b981" />
                        <text x={x} y="108" textAnchor="middle" fontSize="10" fill="#64748b">W{index + 1}</text>
                      </g>
                    );
                  })}
                </svg>
                <p className="mt-3 text-xs text-slate-400">Curved trend of your recent session momentum.</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-2xl border border-violet-400/10 bg-violet-400/5 p-4">
                  <div className="mb-2 flex items-center gap-2 text-violet-300"><CalendarDays size={16} /> <span className="text-xs font-medium">Weekly comparison</span></div>
                  <p className="text-2xl font-bold text-white">{analytics.thisWeekMinutes}m</p>
                  <p className="mt-1 text-[11px] text-slate-400">vs {analytics.lastWeekMinutes}m last week</p>
                </div>
                <div className="rounded-2xl border border-sky-400/10 bg-sky-400/5 p-4">
                  <div className="mb-2 flex items-center gap-2 text-sky-300"><CalendarDays size={16} /> <span className="text-xs font-medium">Monthly comparison</span></div>
                  <p className="text-2xl font-bold text-white">{analytics.thisMonthMinutes}m</p>
                  <p className="mt-1 text-[11px] text-slate-400">vs {analytics.lastMonthMinutes}m last month</p>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="rounded-2xl border border-rose-400/10 bg-rose-400/5 p-4">
                  <div className="mb-2 flex items-center gap-2 text-rose-300"><Clock size={16} /> <span className="text-sm font-semibold text-white">Best time of day for calm</span></div>
                  <p className="text-sm text-slate-300">{analytics.bestTimeOfDay}</p>
                </div>
                <div className="rounded-2xl border border-amber-400/10 bg-amber-400/5 p-4">
                  <div className="mb-2 flex items-center gap-2 text-amber-300"><Sparkles size={16} /> <span className="text-sm font-semibold text-white">Most used breathing pattern</span></div>
                  <p className="text-sm text-slate-300">{analytics.mostUsedBreathingPattern}</p>
                </div>
              </div>

              <div className="rounded-2xl border border-amber-400/10 bg-amber-400/5 p-4">
                <div className="mb-2 flex items-center gap-2 text-amber-300"><Sparkles size={16} /> <span className="text-sm font-semibold text-white">Next wellness goal</span></div>
                <p className="text-sm text-slate-300">
                  {analytics.nextGoalMinutes > 0
                    ? `${analytics.nextGoalMinutes} more minutes to reach your next 120-minute calm milestone.`
                    : 'You already passed your next calm milestone. Keep building your habit.'}
                </p>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl border border-amber-400/10 bg-gradient-to-br from-amber-500/10 to-orange-500/10 p-5">
              <p className="text-sm font-semibold text-white">Unlock deeper insights into your wellness journey</p>
              <p className="mt-2 text-sm leading-relaxed text-slate-300">
                Pro members can see average session length, weekly consistency, calm ratio, mood shift trends, and next-goal pacing.
              </p>
              <button
                onClick={() => setActiveScreen('premium')}
                className="mt-4 rounded-2xl bg-white px-4 py-3 text-sm font-semibold text-slate-900"
              >
                View Pro Member
              </button>
            </div>
          )}
        </div>

        {/* Empty state */}
        {totalSessions === 0 && (
          <div className="mt-8 text-center animate-fade-in" style={{ animationDelay: '0.25s' }}>
            <p className="text-slate-400 text-sm">
              Complete your first session to start tracking your progress!
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
