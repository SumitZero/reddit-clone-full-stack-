import type { BreathingPattern, SoundTrack, QuickSession } from '../store/appStore';

export const breathingPatterns: BreathingPattern[] = [
  {
    id: 'box-breathing',
    name: 'Box Breathing',
    description: 'Equal inhale, hold, exhale, and hold. Used by Navy SEALs to stay calm under pressure.',
    inhale: 4, hold: 4, exhale: 4, holdAfter: 4, rounds: 4,
    category: 'focus', icon: '◻️', isPremium: false,
  },
  {
    id: '4-4-6',
    name: '4-4-6 Calm',
    description: 'Extended exhale activates your parasympathetic nervous system for deep relaxation.',
    inhale: 4, hold: 4, exhale: 6, rounds: 5,
    category: 'calm', icon: '🌊', isPremium: false,
  },
  {
    id: 'stress-reset',
    name: 'Stress Reset',
    description: 'Quick pattern designed for immediate stress relief. Perfect for tense moments.',
    inhale: 3, hold: 2, exhale: 5, rounds: 6,
    category: 'stress', icon: '🔄', isPremium: false,
  },
  {
    id: 'sleep-breathing',
    name: 'Sleep Breathing',
    description: 'Slow, deep pattern that naturally slows your heart rate and prepares you for sleep.',
    inhale: 4, hold: 7, exhale: 8, rounds: 4,
    category: 'sleep', icon: '🌙', isPremium: false,
  },
  {
    id: 'focus-breathing',
    name: 'Focus Boost',
    description: 'Energizing pattern that sharpens concentration and clears mental fog.',
    inhale: 4, hold: 4, exhale: 4, rounds: 6,
    category: 'focus', icon: '🎯', isPremium: false,
  },
  {
    id: 'anxiety-relief',
    name: 'Anxiety Relief',
    description: 'Gentle, slow breathing to ease anxious thoughts and bring you back to center.',
    inhale: 5, hold: 3, exhale: 7, rounds: 5,
    category: 'calm', icon: '🦋', isPremium: true,
  },
  {
    id: 'energize',
    name: 'Morning Energize',
    description: 'Shorter, rhythmic pattern to wake up your body and mind naturally.',
    inhale: 3, hold: 3, exhale: 3, rounds: 8,
    category: 'focus', icon: '☀️', isPremium: true,
  },
  {
    id: 'deep-calm',
    name: 'Deep Calm',
    description: 'Extended breathing cycle for profound relaxation and inner peace.',
    inhale: 6, hold: 6, exhale: 8, rounds: 4,
    category: 'calm', icon: '🧘', isPremium: true,
  },
  {
    id: 'quick-reset',
    name: 'Quick 30s Reset',
    description: 'Ultra-fast breathing reset when you only have 30 seconds.',
    inhale: 3, hold: 1, exhale: 3, rounds: 3,
    category: 'stress', icon: '⚡', isPremium: false,
  },
  {
    id: 'mindful-breath',
    name: 'Mindful Breath',
    description: 'Balanced, mindful breathing for awareness and presence.',
    inhale: 5, hold: 5, exhale: 5, holdAfter: 2, rounds: 5,
    category: 'calm', icon: '🍃', isPremium: true,
  },
];

export const soundTracks: SoundTrack[] = [
  { id: 'rain', name: 'Gentle Rain', category: 'nature', icon: '🌧️', color: '#60a5fa', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/1248/1248-preview.mp3', description: 'Soft rain for instant relaxation.' },
  { id: 'ocean', name: 'Ocean Waves', category: 'water', icon: '🌊', color: '#22d3ee', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/1196/1196-preview.mp3', description: 'Rolling sea waves to slow the mind.' },
  { id: 'forest', name: 'Forest Ambience', category: 'nature', icon: '🌲', color: '#4ade80', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/2515/2515-preview.mp3', description: 'Woodland atmosphere with natural calm.' },
  { id: 'birdsong', name: 'Birdsong Garden', category: 'birds', icon: '🐤', color: '#84cc16', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/2514/2514-preview.mp3', description: 'Bright bird sounds people love in the morning.' },
  { id: 'morning-birds', name: 'Morning Birds', category: 'birds', icon: '🐦', color: '#a3e635', isPremium: true, src: 'https://assets.mixkit.co/active_storage/sfx/2534/2534-preview.mp3', description: 'A richer sunrise birds ambience.' },
  { id: 'river-stream', name: 'River Stream', category: 'water', icon: '💧', color: '#38bdf8', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/1286/1286-preview.mp3', description: 'Flowing water for mental reset.' },
  { id: 'thunderstorm', name: 'Thunderstorm', category: 'nature', icon: '⛈️', color: '#64748b', isPremium: true, src: 'https://assets.mixkit.co/active_storage/sfx/1260/1260-preview.mp3', description: 'Deep storm ambience for intense calm.' },
  { id: 'night-crickets', name: 'Night Crickets', category: 'sleep', icon: '🦗', color: '#34d399', isPremium: true, src: 'https://assets.mixkit.co/active_storage/sfx/1214/1214-preview.mp3', description: 'Gentle night insects for bedtime.' },
  { id: 'white-noise', name: 'White Noise', category: 'sleep', icon: '📻', color: '#94a3b8', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/2516/2516-preview.mp3', description: 'Mask distractions and drift easier.' },
  { id: 'brown-noise', name: 'Brown Noise', category: 'sleep', icon: '🟤', color: '#a8a29e', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/2521/2521-preview.mp3', description: 'Deeper noise texture for focus and sleep.' },
  { id: 'soft-piano', name: 'Soft Piano', category: 'music', icon: '🎹', color: '#c084fc', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/2427/2427-preview.mp3', description: 'Light piano for peace and breathing.' },
  { id: 'ambient-tones', name: 'Ambient Tones', category: 'focus', icon: '🔮', color: '#a78bfa', isPremium: false, src: 'https://assets.mixkit.co/active_storage/sfx/2401/2401-preview.mp3', description: 'Soft tones to reduce inner noise.' },
  { id: 'lo-fi-beats', name: 'Lo-Fi Beats', category: 'focus', icon: '🎵', color: '#f472b6', isPremium: true, src: 'https://assets.mixkit.co/active_storage/sfx/2425/2425-preview.mp3', description: 'Gentle beats for work or study.' },
  { id: 'fireplace', name: 'Cozy Fireplace', category: 'ambient', icon: '🔥', color: '#f97316', isPremium: true, src: 'https://assets.mixkit.co/active_storage/sfx/2008/2008-preview.mp3', description: 'Warm crackling comfort for evenings.' },
  { id: 'wind-chimes', name: 'Wind Chimes', category: 'ambient', icon: '🎐', color: '#67e8f9', isPremium: true, src: 'https://assets.mixkit.co/active_storage/sfx/2482/2482-preview.mp3', description: 'Light airy chimes for gentle calm.' },
  { id: 'singing-bowls', name: 'Singing Bowls', category: 'music', icon: '🔔', color: '#fbbf24', isPremium: true, src: 'https://assets.mixkit.co/active_storage/sfx/2439/2439-preview.mp3', description: 'Meditative resonance for deeper stillness.' },
  { id: 'deep-space', name: 'Deep Space', category: 'ambient', icon: '🌌', color: '#818cf8', isPremium: true, src: 'https://assets.mixkit.co/active_storage/sfx/2400/2400-preview.mp3', description: 'Cinematic drifting ambience for total unwind.' },
];

export const quickSessions: QuickSession[] = [
  {
    id: 'pause-30s', name: '30s Pause', duration: '30 sec', type: 'pause',
    description: 'Close your eyes. Take one deep breath. Let go.', icon: '⏸️', color: 'from-blue-500/20 to-cyan-500/20',
  },
  {
    id: 'breath-1min', name: '1-Min Breathing', duration: '1 min', type: 'breathing',
    description: 'A quick breathing reset to calm your nervous system.', icon: '🌬️', color: 'from-emerald-500/20 to-teal-500/20',
  },
  {
    id: 'ground-2min', name: '2-Min Grounding', duration: '2 min', type: 'grounding',
    description: 'Use the 5-4-3-2-1 technique to ground yourself in the present.', icon: '🌍', color: 'from-amber-500/20 to-orange-500/20',
  },
  {
    id: 'affirmation', name: 'Quick Affirmation', duration: '30 sec', type: 'affirmation',
    description: "Read and repeat a calming affirmation to reset your mindset.", icon: '💚', color: 'from-violet-500/20 to-purple-500/20',
  },
  {
    id: 'focus-reset', name: 'Focus Reset', duration: '1 min', type: 'focus',
    description: 'Clear mental fog and refocus your energy with this quick exercise.', icon: '🎯', color: 'from-rose-500/20 to-pink-500/20',
  },
  {
    id: 'body-scan', name: 'Quick Body Scan', duration: '2 min', type: 'grounding',
    description: 'Scan your body from head to toe, releasing tension as you go.', icon: '🧘', color: 'from-sky-500/20 to-indigo-500/20',
  },
];

export const calmingQuotes = [
  { id: '1', text: "You don't have to control your thoughts. You just have to stop letting them control you.", author: 'Dan Millman' },
  { id: '2', text: "Almost everything will work again if you unplug it for a few minutes, including you.", author: 'Anne Lamott' },
  { id: '3', text: "Breathe. Let go. And remind yourself that this very moment is the only one you know you have for sure.", author: 'Oprah Winfrey' },
  { id: '4', text: "You are allowed to take up space. You are allowed to take a break.", author: 'Unknown' },
  { id: '5', text: "The greatest weapon against stress is our ability to choose one thought over another.", author: 'William James' },
  { id: '6', text: "Within you, there is a stillness and a sanctuary to which you can retreat at any time.", author: 'Hermann Hesse' },
  { id: '7', text: "Rest is not idleness. It is the repair shop of the soul.", author: 'Unknown' },
  { id: '8', text: "You can't pour from an empty cup. Take care of yourself first.", author: 'Unknown' },
  { id: '9', text: "Be gentle with yourself. You're doing the best you can.", author: 'Unknown' },
  { id: '10', text: "This too shall pass. And when it does, you'll be stronger.", author: 'Unknown' },
  { id: '11', text: "Your calm mind is the ultimate weapon against your challenges.", author: 'Bryant McGill' },
  { id: '12', text: "Nothing diminishes anxiety faster than action.", author: 'Walter Anderson' },
  { id: '13', text: "Not everything that weighs you down is yours to carry.", author: 'Unknown' },
  { id: '14', text: "Feelings are just visitors. Let them come and go.", author: 'Mooji' },
  { id: '15', text: "You are not your thoughts. You are the observer of your thoughts.", author: 'Eckhart Tolle' },
  { id: '16', text: "Slow down. Calm down. Don't worry. Don't hurry. Trust the process.", author: 'Alexandra Stoddard' },
  { id: '17', text: "One small positive thought in the morning can change your whole day.", author: 'Dalai Lama' },
  { id: '18', text: "Surrender to what is. Let go of what was. Have faith in what will be.", author: 'Sonia Ricotti' },
  { id: '19', text: "In the middle of difficulty lies opportunity.", author: 'Albert Einstein' },
  { id: '20', text: "Your present circumstances don't determine where you can go; they merely determine where you start.", author: 'Nido Qubein' },
];

export const moodSuggestions: Record<string, { message: string; suggestion: string; breathingId: string }> = {
  stressed: {
    message: "I see you're feeling stressed. Let's take a moment together.",
    suggestion: "Try the Stress Reset breathing — it's designed exactly for moments like this.",
    breathingId: 'stress-reset',
  },
  tired: {
    message: "Feeling tired is your body asking for rest. Let's honor that.",
    suggestion: "Try the Sleep Breathing pattern to deeply relax, or simply close your eyes for 30 seconds.",
    breathingId: 'sleep-breathing',
  },
  anxious: {
    message: "Anxiety can feel overwhelming, but you're safe right now.",
    suggestion: "The 4-4-6 Calm breathing will help activate your body's relaxation response.",
    breathingId: '4-4-6',
  },
  okay: {
    message: "You're doing okay — and that's perfectly fine!",
    suggestion: "How about a Focus Boost breathing session to sharpen your day?",
    breathingId: 'focus-breathing',
  },
  calm: {
    message: "Wonderful! You're in a calm state. Let's maintain it.",
    suggestion: "Try the Box Breathing to deepen your sense of peace.",
    breathingId: 'box-breathing',
  },
  overwhelmed: {
    message: "Feeling overwhelmed means you care. But let's lighten the load.",
    suggestion: "Start with the Quick 30s Reset — just one breath at a time.",
    breathingId: 'quick-reset',
  },
  distracted: {
    message: "A wandering mind is normal. Let's bring it back gently.",
    suggestion: "Try the Focus Boost pattern to clear mental fog.",
    breathingId: 'focus-breathing',
  },
};

export const groundingSteps = [
  { sense: 'See', count: 5, instruction: 'Look around and name 5 things you can see right now.', icon: '👁️' },
  { sense: 'Touch', count: 4, instruction: 'Notice 4 things you can physically feel right now.', icon: '✋' },
  { sense: 'Hear', count: 3, instruction: 'Listen for 3 sounds you can hear right now.', icon: '👂' },
  { sense: 'Smell', count: 2, instruction: 'Notice 2 things you can smell right now.', icon: '👃' },
  { sense: 'Taste', count: 1, instruction: 'Notice 1 thing you can taste right now.', icon: '👅' },
];

export const affirmations = [
  "I am calm. I am at peace. I am enough.",
  "This moment of stress is temporary. I will get through it.",
  "I choose to let go of what I cannot control.",
  "My mind is clear. My body is relaxed. I am present.",
  "I deserve rest. I deserve peace. I deserve kindness.",
  "I am stronger than my stress. I am bigger than my worries.",
  "Right now, in this moment, I am safe.",
  "I release tension with every exhale.",
  "I trust myself to handle whatever comes my way.",
  "I am doing my best, and my best is enough.",
];

export const crisisResources = [
  { country: 'United States', name: 'National Suicide Prevention Lifeline', number: '988', description: 'Free, confidential support 24/7' },
  { country: 'United States', name: 'Crisis Text Line', number: 'Text HOME to 741741', description: 'Text-based crisis support' },
  { country: 'United Kingdom', name: 'Samaritans', number: '116 123', description: 'Free emotional support 24/7' },
  { country: 'Canada', name: 'Talk Suicide Canada', number: '1-833-456-4566', description: '24/7 crisis support' },
  { country: 'Australia', name: 'Lifeline Australia', number: '13 11 14', description: '24/7 crisis support and prevention' },
  { country: 'India', name: 'iCall', number: '9152987821', description: 'Psychosocial helpline' },
  { country: 'International', name: 'International Association for Suicide Prevention', number: 'https://www.iasp.info/resources/Crisis_Centres/', description: 'Find help in your country' },
];
