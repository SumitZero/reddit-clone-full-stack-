import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Types
export type MoodType = 'stressed' | 'tired' | 'anxious' | 'okay' | 'calm' | 'overwhelmed' | 'distracted';
export type TabType = 'home' | 'breathe' | 'sounds' | 'journal' | 'profile';
export type AuthMode = 'welcome' | 'signin' | 'signup';
export type SubscriptionPlan = 'free' | 'monthly' | 'yearly' | 'lifetime';
export type PaymentState = 'idle' | 'pending' | 'success' | 'failed' | 'cancelled';
export type ClockFormat = '12h' | '24h';
export type DayCode = 'Sun' | 'Mon' | 'Tue' | 'Wed' | 'Thu' | 'Fri' | 'Sat';
export type AlarmRingtoneType = 'default' | 'url' | 'file';
export type BillingProvider = 'paypal' | 'razorpay';

export interface TransactionRecord {
  id: string;
  provider: BillingProvider;
  plan: SubscriptionPlan;
  amountLabel: string;
  currency: string;
  status: 'pending' | 'active' | 'cancelled' | 'expired' | 'failed';
  transactionReference: string;
  createdAt: number;
  expiryDate?: number | null;
  cancellationScheduled?: boolean;
}

export interface MoodEntry {
  id: string;
  mood: MoodType;
  timestamp: number;
  note?: string;
}

export interface JournalEntry {
  id: string;
  content: string;
  timestamp: number;
  title?: string;
}

export interface BreathingPattern {
  id: string;
  name: string;
  description: string;
  inhale: number;
  hold: number;
  exhale: number;
  holdAfter?: number;
  rounds: number;
  category: string;
  icon: string;
  isPremium: boolean;
}

export interface SoundTrack {
  id: string;
  name: string;
  category: string;
  icon: string;
  color: string;
  isPremium: boolean;
  src: string;
  description?: string;
}

export interface QuickSession {
  id: string;
  name: string;
  duration: string;
  description: string;
  type: 'breathing' | 'grounding' | 'affirmation' | 'pause' | 'focus';
  icon: string;
  color: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedDate?: number;
  requirement: string;
}

export interface Reminder {
  id: string;
  title: string;
  time: string;
  enabled: boolean;
  days: DayCode[];
  nextTriggerAt?: number | null;
  createdAt: number;
  lastTriggeredAt?: number | null;
}

export interface Alarm {
  id: string;
  title: string;
  time: string;
  enabled: boolean;
  days: DayCode[];
  ringtoneType: AlarmRingtoneType;
  ringtoneLabel: string;
  ringtoneUrl?: string;
  nextTriggerAt?: number | null;
  createdAt: number;
  lastTriggeredAt?: number | null;
}

export interface AppState {
  // Navigation
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;

  // Onboarding
  hasSeenOnboarding: boolean;
  completeOnboarding: () => void;

  // Auth (simplified for web)
  isLoggedIn: boolean;
  userName: string;
  userEmail: string;
  userPhoto: string;
  authProvider: 'email' | 'google' | null;
  authModalOpen: boolean;
  authMode: AuthMode;
  openAuthModal: (mode?: AuthMode) => void;
  closeAuthModal: () => void;
  setAuthMode: (mode: AuthMode) => void;
  login: (name: string, email: string, provider?: 'email' | 'google', photo?: string) => void;
  logout: () => void;

  // Mood
  moodEntries: MoodEntry[];
  addMoodEntry: (mood: MoodType, note?: string) => void;

  // Journal
  journalEntries: JournalEntry[];
  addJournalEntry: (title: string, content: string) => void;
  deleteJournalEntry: (id: string) => void;

  // Favorites
  favoriteBreathing: string[];
  favoriteSounds: string[];
  favoriteQuotes: string[];
  toggleFavoriteBreathing: (id: string) => void;
  toggleFavoriteSound: (id: string) => void;
  toggleFavoriteQuote: (id: string) => void;

  // Progress
  totalSessions: number;
  totalMinutes: number;
  currentStreak: number;
  longestStreak: number;
  lastSessionDate: string | null;
  addSession: (minutes: number) => void;

  // Badges
  badges: Badge[];
  checkBadges: () => void;

  // Reminders
  reminders: Reminder[];
  clockFormat: ClockFormat;
  setClockFormat: (format: ClockFormat) => void;
  toggleReminder: (id: string) => void;
  addReminder: (title: string, time: string, days?: DayCode[]) => void;
  updateReminder: (id: string, updates: Partial<Reminder>) => void;
  deleteReminder: (id: string) => void;

  // Alarms
  alarms: Alarm[];
  toggleAlarm: (id: string) => void;
  addAlarm: (alarm: Omit<Alarm, 'id' | 'createdAt' | 'nextTriggerAt' | 'lastTriggeredAt'>) => void;
  updateAlarm: (id: string, updates: Partial<Alarm>) => void;
  deleteAlarm: (id: string) => void;
  ringingAlarmId: string | null;
  dismissAlarm: () => void;
  snoozeAlarm: (minutes?: number) => void;

  // Premium
  isPremium: boolean;
  subscriptionPlan: SubscriptionPlan;
  paymentState: PaymentState;
  subscriptionRegion: string;
  transactionReference: string;
  purchaseDate: number | null;
  expiryDate: number | null;
  paymentVerified: boolean;
  billingProvider: BillingProvider | null;
  cancelAtPeriodEnd: boolean;
  transactionHistory: TransactionRecord[];
  setPremium: (val: boolean) => void;
  startPaymentFlow: (provider?: BillingProvider) => void;
  completeVerifiedPayment: (plan: SubscriptionPlan, region: string, transactionReference: string, provider?: BillingProvider, expiryDate?: number | null) => void;
  failPaymentFlow: (state: 'failed' | 'cancelled') => void;
  resetPaymentState: () => void;
  setTransactionHistory: (items: TransactionRecord[]) => void;
  addTransactionRecord: (item: TransactionRecord) => void;
  markCancelAtPeriodEnd: (value: boolean) => void;

  // Settings
  darkMode: boolean;
  toggleDarkMode: () => void;
  notificationsEnabled: boolean;
  toggleNotifications: () => void;

  // Active screens
  activeScreen: string;
  setActiveScreen: (screen: string) => void;

  // Playing sound
  playingSound: string | null;
  setPlayingSound: (id: string | null) => void;
  downloadedSounds: Record<string, string>;
  saveDownloadedSound: (id: string, dataUrl: string) => void;
  removeDownloadedSound: (id: string) => void;

  // Sound timer
  soundTimer: number | null;
  setSoundTimer: (minutes: number | null) => void;
}

const getToday = () => new Date().toISOString().split('T')[0];
const dayCodes: DayCode[] = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const getNextTriggerAt = (time: string, days: DayCode[]) => {
  const [hours, minutes] = time.split(':').map(Number);
  const now = new Date();

  for (let offset = 0; offset < 8; offset += 1) {
    const candidate = new Date(now);
    candidate.setDate(now.getDate() + offset);
    candidate.setHours(hours, minutes, 0, 0);
    const dayCode = dayCodes[candidate.getDay()];

    if (days.includes(dayCode) && candidate.getTime() > now.getTime()) {
      return candidate.getTime();
    }
  }

  const fallback = new Date(now);
  fallback.setDate(now.getDate() + 1);
  fallback.setHours(hours, minutes, 0, 0);
  return fallback.getTime();
};

const defaultBadges: Badge[] = [
  { id: 'first-reset', name: 'First Reset', description: 'Complete your first calm session', icon: '🌱', earned: false, requirement: '1 session' },
  { id: '3-day-streak', name: '3-Day Calm', description: 'Maintain a 3-day streak', icon: '🔥', earned: false, requirement: '3-day streak' },
  { id: '7-day-streak', name: '7-Day Focus', description: 'Maintain a 7-day streak', icon: '⭐', earned: false, requirement: '7-day streak' },
  { id: 'mood-tracker', name: 'Self-Aware', description: 'Log 5 mood check-ins', icon: '🧠', earned: false, requirement: '5 mood entries' },
  { id: 'journal-writer', name: 'Thought Keeper', description: 'Write 3 journal entries', icon: '📝', earned: false, requirement: '3 journal entries' },
  { id: 'breath-master', name: 'Breath Master', description: 'Complete 10 breathing sessions', icon: '🌬️', earned: false, requirement: '10 sessions' },
  { id: 'sleep-helper', name: 'Sleep Helper', description: 'Use a sleep session 5 times', icon: '🌙', earned: false, requirement: '5 sleep sessions' },
  { id: 'stress-survivor', name: 'Stress Survivor', description: 'Complete 20 sessions total', icon: '💪', earned: false, requirement: '20 sessions' },
  { id: '30-day-warrior', name: '30-Day Warrior', description: 'Maintain a 30-day streak', icon: '👑', earned: false, requirement: '30-day streak' },
  { id: 'calm-hour', name: 'Calm Hour', description: 'Accumulate 60 minutes of calm', icon: '🕐', earned: false, requirement: '60 total minutes' },
];

const defaultReminders: Reminder[] = [
  { id: 'morning', title: 'Morning Breath', time: '08:00', enabled: false, days: ['Mon','Tue','Wed','Thu','Fri'], createdAt: Date.now(), nextTriggerAt: getNextTriggerAt('08:00', ['Mon','Tue','Wed','Thu','Fri']) },
  { id: 'midday', title: 'Midday Reset', time: '12:30', enabled: false, days: ['Mon','Tue','Wed','Thu','Fri'], createdAt: Date.now(), nextTriggerAt: getNextTriggerAt('12:30', ['Mon','Tue','Wed','Thu','Fri']) },
  { id: 'evening', title: 'Evening Calm', time: '20:00', enabled: false, days: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], createdAt: Date.now(), nextTriggerAt: getNextTriggerAt('20:00', ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']) },
  { id: 'bedtime', title: 'Bedtime Wind-Down', time: '22:00', enabled: false, days: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], createdAt: Date.now(), nextTriggerAt: getNextTriggerAt('22:00', ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']) },
];

const defaultAlarms: Alarm[] = [
  {
    id: 'wake-soft',
    title: 'Soft Wake Up',
    time: '07:00',
    enabled: false,
    days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
    ringtoneType: 'default',
    ringtoneLabel: 'MindReset Bell',
    createdAt: Date.now(),
    nextTriggerAt: getNextTriggerAt('07:00', ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']),
  },
];

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Navigation
      activeTab: 'home',
      setActiveTab: (tab) => set({ activeTab: tab, activeScreen: 'main' }),

      // Onboarding
      hasSeenOnboarding: false,
      completeOnboarding: () => set({ hasSeenOnboarding: true }),

      // Auth
      isLoggedIn: false,
      userName: '',
      userEmail: '',
      userPhoto: '',
      authProvider: null,
      authModalOpen: false,
      authMode: 'welcome',
      openAuthModal: (mode = 'welcome') => set({ authModalOpen: true, authMode: mode }),
      closeAuthModal: () => set({ authModalOpen: false }),
      setAuthMode: (mode) => set({ authMode: mode }),
      login: (name, email, provider = 'email', photo = '') => set({
        isLoggedIn: true,
        userName: name,
        userEmail: email,
        userPhoto: photo,
        authProvider: provider,
        authModalOpen: false,
      }),
      logout: () => set({
        isLoggedIn: false,
        userName: '',
        userEmail: '',
        userPhoto: '',
        authProvider: null,
      }),

      // Mood
      moodEntries: [],
      addMoodEntry: (mood, note) => {
        const entry: MoodEntry = { id: Date.now().toString(), mood, timestamp: Date.now(), note };
        set((s) => ({ moodEntries: [entry, ...s.moodEntries] }));
        get().checkBadges();
      },

      // Journal
      journalEntries: [],
      addJournalEntry: (title, content) => {
        const entry: JournalEntry = { id: Date.now().toString(), title, content, timestamp: Date.now() };
        set((s) => ({ journalEntries: [entry, ...s.journalEntries] }));
        get().checkBadges();
      },
      deleteJournalEntry: (id) => set((s) => ({ journalEntries: s.journalEntries.filter(e => e.id !== id) })),

      // Favorites
      favoriteBreathing: [],
      favoriteSounds: [],
      favoriteQuotes: [],
      toggleFavoriteBreathing: (id) => set((s) => ({
        favoriteBreathing: s.favoriteBreathing.includes(id)
          ? s.favoriteBreathing.filter(f => f !== id)
          : [...s.favoriteBreathing, id]
      })),
      toggleFavoriteSound: (id) => set((s) => ({
        favoriteSounds: s.favoriteSounds.includes(id)
          ? s.favoriteSounds.filter(f => f !== id)
          : [...s.favoriteSounds, id]
      })),
      toggleFavoriteQuote: (id) => set((s) => ({
        favoriteQuotes: s.favoriteQuotes.includes(id)
          ? s.favoriteQuotes.filter(f => f !== id)
          : [...s.favoriteQuotes, id]
      })),

      // Progress
      totalSessions: 0,
      totalMinutes: 0,
      currentStreak: 0,
      longestStreak: 0,
      lastSessionDate: null,
      addSession: (minutes) => {
        const today = getToday();
        const state = get();
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split('T')[0];

        let newStreak = state.currentStreak;
        if (state.lastSessionDate === today) {
          // Already counted today
        } else if (state.lastSessionDate === yesterdayStr) {
          newStreak += 1;
        } else {
          newStreak = 1;
        }

        const newLongest = Math.max(state.longestStreak, newStreak);

        set({
          totalSessions: state.totalSessions + 1,
          totalMinutes: state.totalMinutes + minutes,
          currentStreak: newStreak,
          longestStreak: newLongest,
          lastSessionDate: today,
        });
        get().checkBadges();
      },

      // Badges
      badges: defaultBadges,
      checkBadges: () => {
        const state = get();
        const updatedBadges = state.badges.map(b => {
          if (b.earned) return b;
          let earned = false;
          switch (b.id) {
            case 'first-reset': earned = state.totalSessions >= 1; break;
            case '3-day-streak': earned = state.currentStreak >= 3; break;
            case '7-day-streak': earned = state.currentStreak >= 7; break;
            case 'mood-tracker': earned = state.moodEntries.length >= 5; break;
            case 'journal-writer': earned = state.journalEntries.length >= 3; break;
            case 'breath-master': earned = state.totalSessions >= 10; break;
            case 'stress-survivor': earned = state.totalSessions >= 20; break;
            case '30-day-warrior': earned = state.currentStreak >= 30; break;
            case 'calm-hour': earned = state.totalMinutes >= 60; break;
          }
          if (earned) return { ...b, earned: true, earnedDate: Date.now() };
          return b;
        });
        set({ badges: updatedBadges });
      },

      // Reminders
      reminders: defaultReminders,
      clockFormat: '24h',
      setClockFormat: (format) => set({ clockFormat: format }),
      toggleReminder: (id) => set((s) => ({
        reminders: s.reminders.map((r) => r.id === id ? { ...r, enabled: !r.enabled, nextTriggerAt: getNextTriggerAt(r.time, r.days) } : r)
      })),
      addReminder: (title, time, days = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']) => set((s) => ({
        reminders: [...s.reminders, {
          id: Date.now().toString(),
          title,
          time,
          enabled: true,
          days,
          createdAt: Date.now(),
          nextTriggerAt: getNextTriggerAt(time, days),
          lastTriggeredAt: null,
        }]
      })),
      updateReminder: (id, updates) => set((s) => ({
        reminders: s.reminders.map((r) => r.id === id ? {
          ...r,
          ...updates,
          nextTriggerAt: getNextTriggerAt(updates.time ?? r.time, (updates.days as DayCode[] | undefined) ?? r.days),
        } : r)
      })),
      deleteReminder: (id) => set((s) => ({ reminders: s.reminders.filter((r) => r.id !== id) })),

      // Alarms
      alarms: defaultAlarms,
      toggleAlarm: (id) => set((s) => ({
        alarms: s.alarms.map((a) => a.id === id ? { ...a, enabled: !a.enabled, nextTriggerAt: getNextTriggerAt(a.time, a.days) } : a)
      })),
      addAlarm: (alarm) => set((s) => ({
        alarms: [...s.alarms, {
          ...alarm,
          id: `alarm-${Date.now()}`,
          createdAt: Date.now(),
          nextTriggerAt: getNextTriggerAt(alarm.time, alarm.days),
          lastTriggeredAt: null,
        }]
      })),
      updateAlarm: (id, updates) => set((s) => ({
        alarms: s.alarms.map((a) => a.id === id ? {
          ...a,
          ...updates,
          nextTriggerAt: getNextTriggerAt(updates.time ?? a.time, (updates.days as DayCode[] | undefined) ?? a.days),
        } : a)
      })),
      deleteAlarm: (id) => set((s) => ({ alarms: s.alarms.filter((a) => a.id !== id) })),
      ringingAlarmId: null,
      dismissAlarm: () => set({ ringingAlarmId: null }),
      snoozeAlarm: (minutes = 10) => set((s) => {
        if (!s.ringingAlarmId) return {};
        return {
          ringingAlarmId: null,
          alarms: s.alarms.map((a) => a.id === s.ringingAlarmId ? { ...a, nextTriggerAt: Date.now() + minutes * 60 * 1000 } : a),
        };
      }),

      // Premium
      isPremium: false,
      subscriptionPlan: 'free',
      paymentState: 'idle',
      subscriptionRegion: 'global',
      transactionReference: '',
      purchaseDate: null,
      expiryDate: null,
      paymentVerified: false,
      billingProvider: null,
      cancelAtPeriodEnd: false,
      transactionHistory: [],
      setPremium: (val) => set({ isPremium: val }),
      startPaymentFlow: (provider) => set({ paymentState: 'pending', paymentVerified: false, billingProvider: provider ?? null }),
      completeVerifiedPayment: (plan, region, transactionReference, provider, verifiedExpiryDate) => {
        const now = Date.now();
        const expiryDate = verifiedExpiryDate ?? (plan === 'monthly'
          ? now + 1000 * 60 * 60 * 24 * 30
          : plan === 'yearly'
            ? now + 1000 * 60 * 60 * 24 * 365
            : null);

        set((state) => ({
          isPremium: plan !== 'free',
          subscriptionPlan: plan,
          paymentState: 'success',
          subscriptionRegion: region,
          transactionReference,
          purchaseDate: now,
          expiryDate,
          paymentVerified: true,
          billingProvider: provider,
          cancelAtPeriodEnd: false,
          transactionHistory: state.transactionHistory.map((item) =>
            item.transactionReference === transactionReference
              ? { ...item, status: 'active', expiryDate: expiryDate ?? null, cancellationScheduled: false }
              : item
          ),
        }));
      },
      failPaymentFlow: (state) => set({ paymentState: state, paymentVerified: false }),
      resetPaymentState: () => set({ paymentState: 'idle' }),
      setTransactionHistory: (items) => set({ transactionHistory: items }),
      addTransactionRecord: (item) => set((state) => ({ transactionHistory: [item, ...state.transactionHistory] })),
      markCancelAtPeriodEnd: (value) => set((state) => ({
        cancelAtPeriodEnd: value,
        transactionHistory: state.transactionHistory.map((item, index) =>
          index === 0 ? { ...item, cancellationScheduled: value, status: value ? 'cancelled' : item.status } : item
        ),
      })),

      // Settings
      darkMode: true,
      toggleDarkMode: () => set((s) => ({ darkMode: !s.darkMode })),
      notificationsEnabled: false,
      toggleNotifications: () => set((s) => ({ notificationsEnabled: !s.notificationsEnabled })),

      // Active screens
      activeScreen: 'main',
      setActiveScreen: (screen) => set({ activeScreen: screen }),

      // Playing sound
      playingSound: null,
      setPlayingSound: (id) => set({ playingSound: id }),
      downloadedSounds: {},
      saveDownloadedSound: (id, dataUrl) => set((s) => ({ downloadedSounds: { ...s.downloadedSounds, [id]: dataUrl } })),
      removeDownloadedSound: (id) => set((s) => {
        const next = { ...s.downloadedSounds };
        delete next[id];
        return { downloadedSounds: next };
      }),

      // Sound timer
      soundTimer: null,
      setSoundTimer: (minutes) => set({ soundTimer: minutes }),
    }),
    {
      name: 'mindreset-storage',
      partialize: (state) => ({
        hasSeenOnboarding: state.hasSeenOnboarding,
        isLoggedIn: state.isLoggedIn,
        userName: state.userName,
        userEmail: state.userEmail,
        authProvider: state.authProvider,
        moodEntries: state.moodEntries,
        journalEntries: state.journalEntries,
        favoriteBreathing: state.favoriteBreathing,
        favoriteSounds: state.favoriteSounds,
        favoriteQuotes: state.favoriteQuotes,
        totalSessions: state.totalSessions,
        totalMinutes: state.totalMinutes,
        currentStreak: state.currentStreak,
        longestStreak: state.longestStreak,
        lastSessionDate: state.lastSessionDate,
        badges: state.badges,
        reminders: state.reminders,
        clockFormat: state.clockFormat,
        alarms: state.alarms,
        downloadedSounds: state.downloadedSounds,
        isPremium: state.isPremium,
        subscriptionPlan: state.subscriptionPlan,
        subscriptionRegion: state.subscriptionRegion,
        transactionReference: state.transactionReference,
        purchaseDate: state.purchaseDate,
        expiryDate: state.expiryDate,
        paymentVerified: state.paymentVerified,
        billingProvider: state.billingProvider,
        cancelAtPeriodEnd: state.cancelAtPeriodEnd,
        transactionHistory: state.transactionHistory,
        darkMode: state.darkMode,
        notificationsEnabled: state.notificationsEnabled,
      }),
    }
  )
);
