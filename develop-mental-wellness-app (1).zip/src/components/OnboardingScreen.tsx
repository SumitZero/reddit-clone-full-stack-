import { useState } from 'react';
import { useAppStore } from '../store/appStore';
import { ChevronRight } from 'lucide-react';

const slides = [
  {
    emoji: '🧠',
    title: 'Your Mind Deserves a Reset',
    subtitle: 'Too much pressure? Too many thoughts? MindReset helps you calm down in 1–2 minutes.',
    gradient: 'from-emerald-500/30 to-teal-600/30',
  },
  {
    emoji: '🌬️',
    title: 'Breathe With Purpose',
    subtitle: 'Guided breathing exercises designed for stress, focus, sleep, and anxiety relief.',
    gradient: 'from-blue-500/30 to-cyan-600/30',
  },
  {
    emoji: '🎵',
    title: 'Calming Sounds',
    subtitle: 'Rain, ocean waves, forest ambience, and more. Create your perfect calm environment.',
    gradient: 'from-purple-500/30 to-violet-600/30',
  },
  {
    emoji: '📊',
    title: 'Track Your Progress',
    subtitle: 'Build a daily wellness habit with streaks, mood tracking, and achievements.',
    gradient: 'from-amber-500/30 to-orange-600/30',
  },
  {
    emoji: '💚',
    title: "You're Ready",
    subtitle: "Let's start your journey to a calmer mind. It only takes a minute.",
    gradient: 'from-emerald-500/30 to-green-600/30',
  },
];

export default function OnboardingScreen() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const { completeOnboarding, openAuthModal } = useAppStore();
  const slide = slides[currentSlide];
  const isLast = currentSlide === slides.length - 1;

  return (
    <div className="fixed inset-0 bg-surface flex flex-col items-center justify-between z-[100]">
      {/* Skip button */}
      <div className="w-full flex justify-end p-4 pt-[max(1rem,env(safe-area-inset-top))]">
        <button
          onClick={completeOnboarding}
          className="text-slate-400 text-sm font-medium px-4 py-2 rounded-lg hover:bg-white/5 transition-colors"
        >
          Skip
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 max-w-md mx-auto animate-fade-in" key={currentSlide}>
        <div className={`w-32 h-32 rounded-full bg-gradient-to-br ${slide.gradient} flex items-center justify-center mb-8 animate-float`}>
          <span className="text-5xl">{slide.emoji}</span>
        </div>

        <h1 className="text-2xl font-bold text-white text-center mb-4 font-display">
          {slide.title}
        </h1>

        <p className="text-slate-400 text-center text-base leading-relaxed">
          {slide.subtitle}
        </p>
      </div>

      {/* Bottom */}
      <div className="w-full px-8 pb-12 max-w-md mx-auto">
        {/* Dots */}
        <div className="flex justify-center gap-2 mb-8">
          {slides.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === currentSlide ? 'w-8 bg-emerald-400' : 'w-1.5 bg-slate-700'
              }`}
            />
          ))}
        </div>

        {/* Button */}
        <button
          onClick={() => {
            if (isLast) {
              openAuthModal('welcome');
            } else {
              setCurrentSlide(currentSlide + 1);
            }
          }}
          className="w-full py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-white font-semibold text-lg flex items-center justify-center gap-2 transition-all active:scale-[0.98] shadow-lg shadow-emerald-500/20"
        >
          {isLast ? "Let's Begin" : 'Continue'}
          <ChevronRight size={20} />
        </button>
      </div>
    </div>
  );
}
