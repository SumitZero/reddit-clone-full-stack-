import { useEffect, useMemo, useState } from 'react';
import { X, Mail, Globe, ShieldCheck, Sparkles } from 'lucide-react';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signInWithPopup,
  signInWithRedirect,
  updateProfile,
} from 'firebase/auth';
import { useAppStore } from '../store/appStore';
import { firebaseAuth, googleProvider } from '../lib/firebase';

type AuthMode = 'welcome' | 'signin' | 'signup';

export default function AuthModal() {
  const {
    authModalOpen,
    authMode,
    closeAuthModal,
    setAuthMode,
    login,
    completeOnboarding,
  } = useAppStore();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loadingProvider, setLoadingProvider] = useState<string | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!authModalOpen) {
      setName('');
      setEmail('');
      setPassword('');
      setLoadingProvider(null);
      setError('');
    }
  }, [authModalOpen]);

  const mode: AuthMode = authMode as AuthMode;
  const isWelcome = mode === 'welcome';
  const title = useMemo(() => {
    if (mode === 'signup') return 'Create your calm account';
    if (mode === 'signin') return 'Welcome back';
    return 'Save your calm journey';
  }, [mode]);

  if (!authModalOpen) return null;

  const getFriendlyError = (message: string) => {
    if (message.includes('auth/popup-closed-by-user')) return 'Google sign-in was closed before completion.';
    if (message.includes('auth/popup-blocked')) return 'Your browser blocked the Google popup. We will try redirect sign-in instead.';
    if (message.includes('auth/email-already-in-use')) return 'This Gmail is already in use. Try signing in instead.';
    if (message.includes('auth/invalid-email')) return 'Please enter a valid Gmail address.';
    if (message.includes('auth/weak-password')) return 'Use a stronger password with at least 6 characters.';
    if (message.includes('auth/invalid-credential')) return 'Wrong email or password. Please try again.';
    if (message.includes('auth/user-not-found')) return 'No account found for this Gmail address.';
    return 'Something went wrong. Please try again.';
  };

  const applyUser = (
    user: { displayName: string | null; email: string | null; photoURL: string | null },
    provider: 'email' | 'google' = 'email'
  ) => {
    const finalName = user.displayName?.trim() || user.email?.split('@')[0] || 'MindReset User';
    const finalEmail = user.email?.trim() || '';
    login(finalName, finalEmail, provider, user.photoURL || '');
    completeOnboarding();
    closeAuthModal();
  };

  const handleGoogle = async () => {
    setLoadingProvider('google');
    setError('');
    try {
      const result = await signInWithPopup(firebaseAuth, googleProvider);
      login(
        result.user.displayName?.trim() || result.user.email?.split('@')[0] || 'Google User',
        result.user.email || '',
        'google',
        result.user.photoURL || ''
      );
      completeOnboarding();
      closeAuthModal();
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      if (message.includes('auth/popup-blocked')) {
        try {
          await signInWithRedirect(firebaseAuth, googleProvider);
          return;
        } catch (redirectErr) {
          const redirectMessage = redirectErr instanceof Error ? redirectErr.message : String(redirectErr);
          setError(getFriendlyError(redirectMessage));
        }
      } else {
        setError(getFriendlyError(message));
      }
    } finally {
      setLoadingProvider(null);
    }
  };

  const handleEmailAuth = async () => {
    setLoadingProvider('email');
    setError('');
    try {
      if (mode === 'signup') {
        const result = await createUserWithEmailAndPassword(firebaseAuth, email.trim(), password);
        if (name.trim()) {
          await updateProfile(result.user, { displayName: name.trim() });
        }
        applyUser(
          {
            displayName: name.trim() || result.user.displayName,
            email: result.user.email,
            photoURL: result.user.photoURL,
          },
          'email'
        );
      } else {
        const result = await signInWithEmailAndPassword(firebaseAuth, email.trim(), password);
        applyUser(result.user, 'email');
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      setError(getFriendlyError(message));
    } finally {
      setLoadingProvider(null);
    }
  };

  return (
    <div className="fixed inset-0 z-[130] flex items-end justify-center bg-slate-950/70 backdrop-blur-md sm:items-center">
      <button className="absolute inset-0" aria-label="Close" onClick={closeAuthModal} />
      <div className="relative w-full max-w-md animate-slide-up rounded-t-[2rem] border border-white/10 bg-[radial-gradient(circle_at_top,_rgba(16,185,129,0.18),_transparent_28%),radial-gradient(circle_at_bottom_right,_rgba(99,102,241,0.18),_transparent_30%),linear-gradient(180deg,#07111f_0%,#0c1424_45%,#101827_100%)] p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] shadow-2xl shadow-black/40 sm:rounded-[2rem]">
        <div className="mx-auto mb-4 h-1.5 w-14 rounded-full bg-white/10 sm:hidden" />
        <button
          onClick={closeAuthModal}
          className="absolute right-4 top-4 rounded-full border border-white/10 bg-white/5 p-2 text-slate-300 transition hover:bg-white/10 hover:text-white"
          aria-label="Close auth"
        >
          <X size={18} />
        </button>

        <div className="mb-5 pr-12">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-emerald-400/20 bg-emerald-400/10 px-3 py-1 text-[11px] font-medium text-emerald-300">
            <Sparkles size={12} />
            Secure sign in
          </div>
          <h2 className="text-2xl font-bold text-white">{title}</h2>
          <p className="mt-2 text-sm leading-relaxed text-slate-400">
            Save moods, journal entries, streaks, reminders, and Pro access across your devices.
          </p>
        </div>

        <div className="mb-4 grid gap-3">
          <button
            onClick={handleGoogle}
            disabled={!!loadingProvider}
            className="flex min-h-14 w-full items-center justify-center gap-3 rounded-2xl border border-white/10 bg-white px-4 text-sm font-semibold text-slate-900 shadow-lg shadow-white/10 transition active:scale-[0.99] disabled:opacity-70"
          >
            <Globe size={18} />
            {loadingProvider === 'google' ? 'Connecting Google...' : 'Continue with Google'}
          </button>

          {!isWelcome && (
            <>
              {mode === 'signup' && (
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400/40 focus:outline-none"
                />
              )}
              <input
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Gmail address"
                type="email"
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400/40 focus:outline-none"
              />
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={mode === 'signup' ? 'Create password' : 'Enter password'}
                type="password"
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5 text-sm text-white placeholder:text-slate-500 focus:border-emerald-400/40 focus:outline-none"
              />
              <button
                onClick={handleEmailAuth}
                disabled={!!loadingProvider || !email.trim() || !password.trim() || (mode === 'signup' && !name.trim())}
                className="flex min-h-14 w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 px-4 text-sm font-semibold text-white shadow-lg shadow-emerald-500/20 transition active:scale-[0.99] disabled:opacity-50"
              >
                <Mail size={18} />
                {loadingProvider === 'email' ? 'Securing your account...' : mode === 'signup' ? 'Sign up with Gmail' : 'Sign in with Gmail'}
              </button>
            </>
          )}
        </div>

        {error && (
          <div className="mb-4 rounded-2xl border border-rose-400/20 bg-rose-400/10 px-4 py-3 text-sm text-rose-200">
            {error}
          </div>
        )}

        {isWelcome && (
          <div className="mb-4 rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="mb-3 flex items-start gap-3">
              <div className="rounded-2xl bg-emerald-400/10 p-2 text-emerald-300">
                <ShieldCheck size={18} />
              </div>
              <div>
                <p className="text-sm font-semibold text-white">Your data stays yours</p>
                <p className="mt-1 text-xs leading-relaxed text-slate-400">
                  Sign in to sync your streaks and journal. Or skip for now and keep exploring MindReset.
                </p>
              </div>
            </div>
            <div className="grid gap-2">
              <button
                onClick={() => setAuthMode('signup')}
                className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-white transition hover:bg-white/10"
              >
                Sign up with Gmail
              </button>
              <button
                onClick={() => setAuthMode('signin')}
                className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-300 transition hover:bg-white/10 hover:text-white"
              >
                I already have an account
              </button>
            </div>
          </div>
        )}

        <div className="text-center">
          {isWelcome ? (
            <button
              onClick={() => {
                completeOnboarding();
                closeAuthModal();
              }}
              className="text-sm font-medium text-slate-400 underline-offset-4 transition hover:text-white hover:underline"
            >
              Skip for now
            </button>
          ) : (
            <button
              onClick={() => setAuthMode(mode === 'signup' ? 'signin' : 'signup')}
              className="text-sm text-slate-400 transition hover:text-white"
            >
              {mode === 'signup' ? 'Already have an account? Sign in' : 'New here? Create an account'}
            </button>
          )}
          <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
            By continuing, you agree to MindReset’s Terms and Privacy Policy.
          </p>
        </div>
      </div>
    </div>
  );
}
