import { Crown, LogIn, UserCheck } from 'lucide-react';
import { useAppStore } from '../store/appStore';

export default function TopActions() {
  const { isLoggedIn, userName, openAuthModal, setActiveScreen, isPremium } = useAppStore();

  return (
    <div className="absolute right-4 top-[max(1rem,env(safe-area-inset-top))] z-20 flex items-center gap-2">
      <button
        onClick={() => setActiveScreen('premium')}
        className="flex items-center gap-2 rounded-full border border-amber-400/20 bg-gradient-to-r from-amber-400/15 to-yellow-500/10 px-3 py-2 text-xs font-semibold text-amber-200 shadow-lg shadow-amber-500/10 transition active:scale-[0.98]"
      >
        <Crown size={14} />
        {isPremium ? 'Pro Member' : 'Go Pro'}
      </button>

      <button
        onClick={() => openAuthModal(isLoggedIn ? 'signin' : 'welcome')}
        className="flex items-center gap-2 rounded-full border border-white/10 bg-white/6 px-3 py-2 text-xs font-medium text-white transition active:scale-[0.98]"
      >
        {isLoggedIn ? <UserCheck size={14} className="text-emerald-300" /> : <LogIn size={14} className="text-sky-300" />}
        <span className="max-w-[96px] truncate">{isLoggedIn ? userName || 'Account' : 'Sign in'}</span>
      </button>
    </div>
  );
}
